import os
import json

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from idegeo.GeonodeModels.models import Document

@login_required
def documents_home(request):
    documents = Document.objects.all().order_by('title')

    documents_dict = []
    for d in documents:
        documents_dict.append({
            'id': d.id,
            'link': f'{os.getenv("GEONODE_API_ROOT")}api/v2/documents/{d.id}',
            'title': d.title,
            'name': d.title_en,
            'edition': d.edition,
            'thumbnail_url': d.thumbnail_url,
            'extension': d.extension,
            'date': d.date.isoformat(),
            'href': f'{os.getenv("GEONODE_API_ROOT")}documents/{d.id}/link',
            'gn_description':d.category.gn_description if d.category else None,
            'keywords': [{
                'name': k.name,
                'slug': k.slug
            } for k in d.keywords.all()]
        })

    return render(request, "documents_base.html", { 'documents': json.dumps(documents_dict) })
