from django.apps import AppConfig

class IdegeoDocumentsConfig(AppConfig):
    name = "idegeo.documents"
    label = "idegeo_documents"