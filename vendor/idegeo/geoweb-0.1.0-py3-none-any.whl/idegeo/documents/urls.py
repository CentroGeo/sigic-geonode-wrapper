from django.urls import path

from . import views

urlpatterns = [

    # base urls
    path('', views.documents_home, name="documents_home"),


]