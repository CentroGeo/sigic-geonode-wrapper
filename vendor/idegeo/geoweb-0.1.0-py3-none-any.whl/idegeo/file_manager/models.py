"""
ARCHIVO: models.py

PROPÓSITO: Este archivo contiene todos los modelos Django que representan las tablas en la base de datos.
Define la estructura de datos para categorías y recursos (archivos), incluyendo relaciones,
validaciones y comportamientos personalizados.

MODELOS PRINCIPALES:
1. Category: Modelo para categorizar recursos
2. Resource: Modelo principal para almacenar metadatos de archivos
"""

from django.db import models
from django.conf import settings
import os

# Obtener el modelo de usuario configurado en settings
User = settings.AUTH_USER_MODEL

def get_upload_path(instance, filename):
    """
    Función para generar la ruta de upload de archivos
    Estructura: geoweb_files/{username}/{filename}
    Args:
        instance: Instancia del modelo Resource
        filename (str): Nombre original del archivo 
    """
    return os.path.join(
        "geoweb_files", instance.owner.username, filename)

class Category(models.Model):
    """
    Modelo para categorizar recursos del sistema
    CARACTERÍSTICAS:
    - Nombres únicos en todo el sistema
    - Categorías compartidas entre usuarios
    - Soporte para categorías públicas/privadas
    - Timestamps automáticos
    """
    
    name = models.CharField(max_length=100, unique=True)
    is_public = models.BooleanField(default=False)
    owner = models.ForeignKey(
        User,
        verbose_name="Propietario",
        on_delete=models.CASCADE,
        related_name='owned_categories'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        """Configuración metaclas del modelo Category"""
        verbose_name_plural = "Categories"  # Nombre plural en admin
        ordering = ['name']  # Ordenamiento por defecto por nombre
    
    def __str__(self):
        """Representación en string del modelo"""
        return self.name
    


class Resource(models.Model):
    """
    Modelo principal para almacenar recursos (archivos) del sistema
    CARACTERÍSTICAS:
    - Borrado lógico con estados: activo, eliminado, archivado
    - Metadatos completos del archivo
    - Gestión automática de archivos físicos
    - Sistema de categorización múltiple
    - Control de visibilidad (público/privado)
    """
    
    # un borrado lógico por si es necesario en un futuro
    STATUS_CHOICES = (
        ('active', 'Activo'),
        ('deleted', 'Eliminado'),
        ('archived', 'Archivado'),
    )
    
    owner = models.ForeignKey(
        User,
        verbose_name="Propietario",
        on_delete=models.CASCADE,
        related_name='owned_files'
    )

    # si estas guardando el nombre original, entonces creo que
    # seria bueno dejar al usuario renombrar el archivo
    original_name = models.CharField(max_length=255)

    name = models.CharField(max_length=255)

    resource = models.FileField(upload_to=get_upload_path)

    # no necesitamos que se seleccione el tipo de archivo, mas bien
    # se debe guardar la extension del mismo
    extension = models.CharField(max_length=250)

    categories = models.ManyToManyField(Category, blank=True, related_name='resource_categories')
    size = models.BigIntegerField(help_text="Tamaño en bytes")
    is_public = models.BooleanField(default=False)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active')
    created_at = models.DateTimeField(auto_now_add=True) 
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        """Configuración metaclas del modelo Resource"""
        ordering = ['-created_at']  # Ordenamiento por fecha de creación descendente
    
    def __str__(self):
        """Representación en string: 'Nombre personalizado (Nombre original)'"""
        return f"{self.name} ({self.original_name})"
    
    def delete(self, *args, **kwargs):
        """
        Sobrescribe el método delete para eliminar el archivo físico
        Comportamiento:
        1. Intenta eliminar el archivo físico del filesystem
        2. Ejecuta el delete normal del modelo (elimina registro de BD)
        3. Si falla la eliminación física, continúa con la eliminación lógica
        
        Args:
            *args: Argumentos posicionales
            **kwargs: Argumentos nombrados
        """
        if self.resource and os.path.isfile(self.resource.path):
            os.remove(self.resource.path)
        super().delete(*args, **kwargs)