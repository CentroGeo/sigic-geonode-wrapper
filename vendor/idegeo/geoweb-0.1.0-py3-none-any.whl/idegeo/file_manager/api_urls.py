from django.urls import path
from . import views

urlpatterns = [
    # TODAS las rutas API bajo /api/
    path('list_resources/', views.list_resources, name='api_list_resources'),
    path('create_resource/', views.create_resource, name='api_create_resource'),
    path('categories/', views.get_categories, name='api_categories'),
    path('create_category/', views.create_category, name='api_create_category'),
    path('download_resource/<int:resource_id>/', views.download_resource, name='api_download_resource'),
    path('delete_resource/<int:resource_id>/', views.delete_resource, name='api_delete_resource'), 
    path('toggle_visibility/<int:resource_id>/', views.toggle_visibility, name='api_toggle_visibility'),  
    path('files/<int:resource_id>/', views.serve_resource, name='api_serve_resource'),
]