# urls.py - TEMPORAL para ver si carga la app
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='file_manager'),
    # Agregar manualmente UNA ruta API para probar
    path('api/list_resources/', views.list_resources, name='api_list_resources'),
]