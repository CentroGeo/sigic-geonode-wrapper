"""
ARCHIVO: views.py

PROPÓSITO: Controlador principal que maneja todas las vistas y endpoints de la aplicación File Manager
Este archivo contiene todas las vistas (views) de Django que manejan las solicitudes HTTP
Incluye tanto la vista principal que sirve el template HTML como todas las APIs REST que el frontend React consume.

ARQUITECTURA:
- Vistas basadas en funciones con decoradores para control de acceso
- APIs JSON para comunicación con el frontend React
- Manejo de autenticación, permisos y operaciones CRUD completas
- Gestión de archivos físicos y metadatos en base de datos

ENDPOINTS PRINCIPALES:
┌─────────────────┬──────────────────────────┬────────────────────┐
│   MÉTODO HTTP   │         ENDPOINT         │      FUNCIÓN       │
├─────────────────┼──────────────────────────┼────────────────────┤
│ GET             │ /                        │ index              │
│ GET             │ /api/list_resources/     │ list_resources     │
│ GET             │ /api/categories/         │ get_categories     │
│ POST            │ /api/create_resource/    │ create_resource    │
│ POST            │ /api/create_category/    │ create_category    │
│ POST/DELETE     │ /api/delete_resource/    │ delete_resource    │
│ POST            │ /api/toggle_visibility/  │ toggle_visibility  │
│ GET             │ /api/files/<id>/         │ serve_resource     │
│ GET             │ /api/download_resource/  │ download_resource  │
└─────────────────┴──────────────────────────┴────────────────────┘

SEGURIDAD:
- @login_required: Protege endpoints que requieren autenticación
- Verificación de propiedad: Usuarios solo pueden modificar sus recursos
- Validación de permisos: Control de acceso a archivos públicos/privados
"""

import os
import unicodedata
import re
import json
from django.http import JsonResponse, FileResponse
from django.http import HttpResponseForbidden
from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_GET, require_POST
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Count, Q
from django.contrib.auth.decorators import user_passes_test


# Zerifica que el usuario sea superusuario
def superuser_required(view_func=None, login_url=None):

    actual_decorator = user_passes_test(
        lambda u: u.is_active and u.is_superuser,
        login_url=login_url,
        redirect_field_name=None
    )
    if view_func:
        return actual_decorator(view_func)
    return actual_decorator



# Importar el modelo
from .models import Resource, Category

@superuser_required
def index(request):

    user = request.user
    is_auth = ""
    userSerialize = {}

    if user.is_authenticated and not user.is_anonymous:
        userSerialize["id"] = user.id
        userSerialize["username"] = user.username
        userSerialize["is_superuser"] = user.is_superuser
        userSerialize["is_staff"] = user.is_staff
        is_auth = "True"

    template = "file_manager.html"

    return render(
        request,
        template,
        {"user_isauth": is_auth, "user": json.dumps(userSerialize)},
    )


## LIMPIAR ENTRADA DE ARCHIVO JSON
def clean_filename(filename):

    name, ext = os.path.splitext(filename)
    name = unicodedata.normalize('NFKD', name).encode('ascii', 'ignore').decode('ascii')
    name = re.sub(r'[^a-zA-Z0-9_-]', '_', name)
    return f"{name}{ext}"

@require_GET
@login_required
def list_resources(request):
    """
    API para listar recursos con paginación, filtros y búsqueda
    Endpoint: GET /api/list_resources/
    Parámetros de consulta:
        - page: Número de página (default: 1)
        - page_size: Tamaño de página (default: 10)
        - filter_type: 'my-files' (solo del usuario) o 'all-files' (públicos + del usuario)
        - category: ID de categoría para filtrar
        - search: Término de búsqueda en nombre, nombre original o extensión
        
    Returns:
        JsonResponse: Lista paginada de recursos con metadatos
    """
    page = int(request.GET.get("page", "1"))
    page_size = int(request.GET.get("page_size", "10"))
    
    # Parámetros de filtro 'my-files' o 'all-files'
    filter_type = request.GET.get("filter_type", "my-files")  
    category_id = request.GET.get("category")
    search_term = request.GET.get("search", "")
    
    # Base queryset - solo recursos activos
    qs = Resource.objects.filter(status='active')
    
    # Filtrar por propietario
    if filter_type == 'my-files':
        qs = qs.filter(owner=request.user)
    # Si es 'all-files', mostrar todos los activos (públicos + del usuario)
    elif filter_type == 'all-files':
        qs = qs.filter(Q(is_public=True) | Q(owner=request.user))
    
    # Filtrar por categoría
    if category_id:
        qs = qs.filter(categories__id=category_id)
    
    # Filtrar por búsqueda
    if search_term:
        qs = qs.filter(
            Q(name__icontains=search_term) | 
            Q(original_name__icontains=search_term) |
            Q(extension__icontains=search_term)
        )

    # Paginate results
    paginator = Paginator(qs, page_size)
    try:
        resources = paginator.page(page)
    except PageNotAnInteger:
        resources = paginator.page(1)
    except EmptyPage:
        resources = []

    data = [
        {
            "id": resource.id,
            "name": resource.name,
            "extension": resource.extension,
            "owner": resource.owner.username,
            "created_at": resource.created_at.strftime("%B %d, %Y, %I:%M %p"),
            "updated_at": resource.updated_at.strftime("%B %d, %Y, %I:%M %p"),
            "size": resource.size,
            "is_public": resource.is_public,
            "owner_id": resource.owner.id,
            "categories": list(resource.categories.values_list('name', flat=True)) if resource.categories.exists() else []
        }
        for resource in resources
    ]

    return JsonResponse(
        {
            "total_pages": paginator.num_pages,
            "current_page": page,
            "total_items": paginator.count,
            "results": data,
        },
        safe=False,
    )


@require_http_methods(["GET"])
def get_categories(request):
    """
    API para obtener lista de categorías únicas utilizadas por archivos activos
    Endpoint: GET /api/categories/
    Returns:
        JsonResponse: Lista alfabética de categorías únicas con "Sin categoría" al inicio
    """
    try:
        # Obtener categorías únicas que están siendo usadas por archivos ACTIVOS
        categories = Category.objects.filter(
            resource_categories__status='active'
        ).values_list('name', flat=True).distinct()
        
        # Filtrar valores nulos/vacíos y capitalizar solo primera letra
        category_list = []
        seen_categories = set()
        
        for category in categories:
            if category and category.strip():
                # SOLO capitalizar la primera letra, mantener el resto intacto
                category_normalized = category[0].upper() + category[1:] if category else category
                if category_normalized not in seen_categories:
                    category_list.append(category_normalized)
                    seen_categories.add(category_normalized)
        
        # Oordenar alfabéticamente (case-insensitive)
        category_list_sorted = sorted(category_list, key=lambda x: x.lower())
        
        # Agregar "Sin categoría" al principio
        default_category = 'Sin categoría'
        all_categories = []
        
        if default_category in seen_categories:
            category_list_sorted = [cat for cat in category_list_sorted if cat != default_category]
            all_categories = [default_category] + category_list_sorted
        else:
            all_categories = [default_category] + category_list_sorted
        
        return JsonResponse(all_categories, safe=False)
        
    except Exception as e:
        default_categories = ['Sin categoría']
        return JsonResponse(default_categories, safe=False)



@require_POST
@login_required
def create_resource(request):
    """
    API para crear un nuevo recurso (subir archivo)
    Endpoint: POST /api/create_resource/
    Parámetros (multipart/form-data):
        - name: Nombre del recurso
        - original_name: Nombre original del archivo
        - extension: Extensión del archivo
        - size: Tamaño en bytes
        - is_public: Booleano indicando si es público
        - resource: Archivo físico (FileField)
        - categories: Lista de categorías asociadas
        
    Returns:
        JsonResponse: Resultado de la operación con ID del recurso creado
    """
    try:
        required_fields = [
            "name",
            "original_name",
            "extension",
            "size",
        ]

        resource_data = {}
        for field in required_fields:
            value = request.POST.get(field)
            if value is not None:
                resource_data[field] = value
        
        is_public = request.POST.get("is_public")
        if is_public is not None:
            resource_data["is_public"] = str(is_public).lower() in ["true", "1", "yes", "on"]
        else:
            resource_data["is_public"] = False  

        resource_file = request.FILES.get("resource")
        if resource_file:
            resource_data["resource"] = resource_file

        resource_data["owner"] = request.user
        new_resource = Resource.objects.create(**resource_data)

         # ASIGNAR CATEGORÍAS
        categories = request.POST.getlist('categories')
        for category_name in categories:
            if category_name and category_name.strip():
                # Buscar o crear la categoría
                category, created = Category.objects.get_or_create(
                    name=category_name.strip(),
                    defaults={'owner': request.user, 'is_public': True}
                )
                new_resource.categories.add(category)

        return JsonResponse(
            {
                "success": True,
                "message": "Resource uploaded successfully",
                "id": new_resource.id,
            }
        )
    except Exception as e:
        return JsonResponse(
            {"success": False, "message": f"Error uploading resource: {str(e)}"}
        )

@require_POST
@login_required
def toggle_visibility(request, resource_id):
    """
    API para cambiar la visibilidad (público/privado) de un recurso
    Endpoint: POST /api/toggle_visibility/<resource_id>/
    Args:
        resource_id (int): ID del recurso a modificar
    Body (JSON):
        - is_public: Nuevo estado de visibilidad (opcional)
    Returns:
        JsonResponse: Nuevo estado de visibilidad y resultado de la operación
    """
    try:
        # Solo el propietario puede cambiar la visibilidad
        resource = Resource.objects.get(id=resource_id, owner=request.user)
        
        # Obtener el nuevo estado desde el body JSON
        data = json.loads(request.body)
        new_visibility = data.get('is_public', not resource.is_public)
        
        # Actualizar la visibilidad
        resource.is_public = new_visibility
        resource.save()
        
        return JsonResponse({
            "success": True, 
            "new_visibility": new_visibility
        })
        
    except Resource.DoesNotExist:
        return JsonResponse({
            "success": False, 
            "message": "No eres el Propietario, no tienes permisos para modificarlo"
        }, status=404)
    except Exception as e:
        return JsonResponse({
            "success": False, 
            "message": f"Error al cambiar la visibilidad: {str(e)}"
        }, status=500)


@require_GET
def serve_resource(request, resource_id):
    """
    Servir archivo por ID con verificación de permisos
    POLÍTICA DE ACCESO:
    - Archivos públicos: Todos pueden ver (logueados o no, cualquier nivel)
    - Archivos privados: Solo superusuarios pueden ver
    """
    try:
        # Obtener el recurso
        resource = get_object_or_404(Resource, id=resource_id, status='active')
        
        # VERIFICAR PERMISOS SEGÚN POLÍTICA DEFINIDA:
        if resource.is_public:
            # ARCHIVO PÚBLICO: Acceso para TODOS (logueados o no, cualquier nivel)
            # No se requiere verificación adicional
            pass
        else:
            # ARCHIVO PRIVADO: Solo superusuarios pueden ver
            if not request.user.is_authenticated:
                return JsonResponse(
                    {
                        "success": False, 
                        "message": "Este archivo es privado. Se requiere autenticación."
                    },
                    status=401
                )
            
            # Verificar si es superusuario
            if not request.user.is_superuser:
                return JsonResponse(
                    {
                        "success": False, 
                        "message": "Este archivo es privado. Solo superusuarios pueden acceder."
                    },
                    status=403
                )
        
        # Verificar que el archivo físico existe
        if not resource.resource or not os.path.isfile(resource.resource.path):
            return JsonResponse(
                {"success": False, "message": "El archivo físico no existe"},
                status=404
            )
        
        # Servir el archivo
        response = FileResponse(
            resource.resource.open(), 
            filename=resource.original_name,
            as_attachment=False
        )
        
        # Configurar headers apropiados para el tipo de archivo
        if resource.extension.lower() in ['png', 'jpg', 'jpeg', 'gif', 'svg']:
            response['Content-Type'] = f'image/{resource.extension.lower()}'
        elif resource.extension.lower() == 'json':
            response['Content-Type'] = 'application/json'
            # IMPORTANTE: Agregar headers CORS para acceso desde iframes
            response['Access-Control-Allow-Origin'] = '*'
        else:
            response['Content-Type'] = 'application/octet-stream'
            
        return response
        
    except Resource.DoesNotExist:
        return JsonResponse(
            {"success": False, "message": "Archivo no encontrado"},
            status=404
        )
    except Exception as e:
        return JsonResponse(
            {"success": False, "message": f"Error al servir el archivo: {str(e)}"},
            status=500
        )


@require_GET
@login_required
def download_resource(request, resource_id):
    """
    API para descargar un archivo (descarga forzada)
    Endpoint: GET /api/download_resource/<resource_id>/
    Args:
        resource_id (int): ID del recurso a descargar
    Returns:
        FileResponse: Archivo físico con header de descarga
    """
    try:
        resource = Resource.objects.get(id=resource_id, status='active')
        
        # Verificar permisos: el usuario puede descargar si es el propietario o si es público
        if resource.owner != request.user and not resource.is_public:
            return JsonResponse(
                {"success": False, "message": "No tienes permisos para descargar este archivo"},
                status=403
            )
        
        # Servir el archivo
        response = FileResponse(resource.resource.open(), as_attachment=True, filename=resource.original_name)
        return response
        
    except Resource.DoesNotExist:
        return JsonResponse(
            {"success": False, "message": "Archivo no encontrado"},
            status=404
        )
    except Exception as e:
        return JsonResponse(
            {"success": False, "message": f"Error al descargar el archivo: {str(e)}"},
            status=500
        )


# ELIMINAR ARCHIVOS - BORRADO FÍSICO
@require_http_methods(["DELETE", "POST"])
@login_required
def delete_resource(request, resource_id):
    """
    API para eliminar un recurso (borrado físico y lógico)
    Endpoint: DELETE/POST /api/delete_resource/<resource_id>/
    Args:
        resource_id (int): ID del recurso a eliminar 
    Returns:
        JsonResponse: Resultado de la operación y limpieza de categorías huérfanas
    """
    try:
        #  Verificar que el recurso existe y el usuario es propietario
        resource = Resource.objects.get(id=resource_id, owner=request.user)
        
        # Intentar eliminar el archivo físico
        file_deleted = False
        try:
            if resource.resource and hasattr(resource.resource, 'path'):
                file_path = resource.resource.path
                if os.path.isfile(file_path):
                    os.remove(file_path)
                    file_deleted = True
        except Exception as file_error:
            # Registrar error pero continuar con eliminación lógica
            pass
        
        # Guardar las categorías asociadas antes de eliminar
        categories_before_delete = list(resource.categories.all())
        
        # Eliminar el registro de la base de datos
        resource.delete()
        
        # LIMPIAR CATEGORÍAS HUÉRFANAS después de eliminar el archivo
        cleaned_count = clean_unused_categories()
        
        message = "Archivo eliminado correctamente"
        if not file_deleted:
            message += " (pero el archivo físico no pudo ser eliminado)"
            
        return JsonResponse({
            "success": True, 
            "message": message
        })
        
    except Resource.DoesNotExist:
        return JsonResponse({
            "success": False, 
            "message": "No eres el propietario, no tienes permisos para eliminarlo"
        }, status=404)
    except Exception as e:
        return JsonResponse({
            "success": False, 
            "message": f"Error al eliminar el archivo: {str(e)}"
        }, status=500)



def clean_unused_categories():
    """
    Función utilitaria para eliminar categorías que no están siendo utilizadas
    Returns:
        int: Número de categorías eliminadas
    """
    try:
        unused_categories = Category.objects.annotate(
            resource_count=Count('resource_categories')
        ).filter(resource_count=0)
        
        count = unused_categories.count()
        if count > 0:
            unused_categories.delete()
        
        return count
    except Exception as e:
        return 0



@require_POST
@login_required
def create_category(request):
    """
    API para crear una nueva categoría o reutilizar una existente inactiva
    Endpoint: POST /api/create_category/
    Body (JSON):
        - name: Nombre de la categoría a crear 
    Returns:
        JsonResponse: Categoría creada o reutilizada con información completa
    """
    try:
        data = json.loads(request.body)
        category_name = data.get('name', '').strip()
        
        if not category_name:
            return JsonResponse(
                {"success": False, "message": "El nombre de la categoría es requerido"},
                status=400
            )
        
        # SOLO capitalizar la primera letra, mantener el resto intacto
        category_name_normalized = category_name[0].upper() + category_name[1:] if category_name else category_name
        
        # Buscar categoría existente (case-sensitive)
        existing_category = Category.objects.filter(
            name=category_name_normalized  # Case-sensitive
        ).first()
        
        if existing_category:
            # Verificar si la categoría tiene archivos activos
            has_active_resources = existing_category.resource_categories.filter(
                status='active'
            ).exists()
            
            if has_active_resources:
                return JsonResponse(
                    {"success": False, "message": "Esta categoría ya existe"},
                    status=400
                )
            else:
                # Reutilizar categoría inactiva
                return JsonResponse({
                    "success": True,
                    "message": "Categoría reutilizada exitosamente",
                    "category": {
                        "id": existing_category.id,
                        "name": existing_category.name
                    }
                })
        else:
            # Crear nueva categoría
            category = Category.objects.create(
                name=category_name_normalized,
                owner=request.user,
                is_public=True
            )
            
            return JsonResponse({
                "success": True,
                "message": "Categoría creada exitosamente", 
                "category": {
                    "id": category.id,
                    "name": category.name
                }
            })
        
    except Exception as e:
        return JsonResponse(
            {"success": False, "message": f"Error creando categoría: {str(e)}"},
            status=500
        )