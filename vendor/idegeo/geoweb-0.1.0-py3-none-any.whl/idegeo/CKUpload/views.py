import os
from django.conf import settings
from django.http import JsonResponse

def upload_file(request):
    if request.method == 'POST' and request.FILES.get('upload'):
        uploaded_file = request.FILES['upload']

        # Define the destination directory where you want to save the uploaded file.
        destination_dir = os.path.join(settings.MEDIA_ROOT, 'react-ckeditor')  # Assuming you have a 'uploads' directory in your MEDIA_ROOT.
        
        if not os.path.exists(destination_dir):
            os.makedirs(destination_dir)
        
        # Construct the file path with a unique filename.
        file_path = os.path.join(destination_dir, uploaded_file.name)
        
        # Save the uploaded file to the specified path.
        with open(file_path, 'wb+') as destination:
            for chunk in uploaded_file.chunks():
                destination.write(chunk)

        # Respond with a JSON object containing the URL where the file is saved.
        file_url = os.path.join(settings.MEDIA_URL, 'react-ckeditor', uploaded_file.name)
        return JsonResponse({
            "url": file_url
        })
    
    else:
        return JsonResponse({'error': 'No file uploaded'}, status=400) 