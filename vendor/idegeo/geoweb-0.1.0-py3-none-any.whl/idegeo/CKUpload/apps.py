from django.apps import AppConfig


class CkuploadConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'idegeo.CKUpload'
