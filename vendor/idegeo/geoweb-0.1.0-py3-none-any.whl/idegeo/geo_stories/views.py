import json
from django.shortcuts import render


def index(request):
  user = request.user
  is_auth = ''
  userSerialize = {};

  if user.is_authenticated and not user.is_anonymous:
    userSerialize['id'] = user.id
    userSerialize['token'] = user.token
    userSerialize['username'] = user.username
    userSerialize['is_superuser'] = user.is_superuser
    userSerialize['is_staff'] = user.is_staff
    userSerialize['cms_access'] = user.cms_access
    userSerialize['geostories_access'] = getattr(user, 'geostories_access', False) 
    is_auth = 'True'

  is_public_route = "/historia/" in request.path

  if is_public_route:
      template = "public_geostory.html"
  else:
      template = "geostories_index.html"

  return render(
    request, 
    template,
    {
      'user_isauth': is_auth,
      'user': json.dumps(userSerialize)
    }
  )