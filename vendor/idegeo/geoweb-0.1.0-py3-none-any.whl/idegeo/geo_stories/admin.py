from django.contrib import admin
from idegeo.geo_stories.models import *


admin.site.register(GeoStory)
admin.site.register(GeoStoryLayer)
admin.site.register(Scene)
admin.site.register(MapOption)