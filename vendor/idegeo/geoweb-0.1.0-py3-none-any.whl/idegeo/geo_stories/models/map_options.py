# encoding:utf-8

from django.db import models
from .base import IdegeoBaseModel
from django_choices_field import TextChoicesField

def base_map_default_value():
    return {
        "name": "OpenStreetMap",
        "layer": "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
        "attribution": '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
    }

class MapType(models.TextChoices):
    REGULAR = "regular", "Regular"
    SWIPE = "swipe", "Swipe"
    DUAL = "dual", "Dual"

class MapOption(IdegeoBaseModel):
    base_map = models.JSONField(
        verbose_name='Mapa base',
        blank=False,
        null=False,
        default=base_map_default_value)

    map_center_lat = models.FloatField(
        null=True,
        blank=True)

    map_center_long = models.FloatField(
        null=True,
        blank=True)

    zoom = models.IntegerField(
        null=True,
        blank=True)

    show_legend = models.BooleanField(
        verbose_name="Mostrar leyenda",
        default=True
    )

    map_type = TextChoicesField(
        verbose_name="Tipo de mapa",
        choices_enum=MapType,
        default=MapType.REGULAR,
    )

    def __str__(self):
        return str(self.pk)
    
    class Meta:
        db_table = "MapOptions"

        verbose_name = "Map Option"

        verbose_name_plural = "MapOptions"