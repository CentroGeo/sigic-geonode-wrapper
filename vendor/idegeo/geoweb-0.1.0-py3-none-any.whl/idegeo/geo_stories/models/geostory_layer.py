# encoding:utf-8

from django.db import models
from .base import IdegeoBaseModel

class GeoStoryLayer(IdegeoBaseModel):
    layer_url = models.CharField(
        max_length=256,
        verbose_name='Url de la capa',
        blank=False)
    
    layer_style = models.CharField(
        max_length=256,
        verbose_name='Estilo de la capa',
        blank=True
    )

    layer_name = models.CharField(
        max_length=256,
        verbose_name='Nombre de la capa en Geoserver',
        blank=False
    )

    layer_display_name = models.CharField(
        max_length=256,
        verbose_name='Nombre de la capa',
        blank=True
    )

    layer_type = models.CharField(
        max_length=256,
        verbose_name='Tipo de la capa',
        blank=True,
        null=True
    )

    layer_extent = models.JSONField(
        verbose_name='Extent de la capa',
        blank=True,
        null=True
    )

    geonode_id = models.CharField(
        max_length=256,
        verbose_name='Id de la capa en Geonode',
        blank=True,
        null=True
    )

    scene = models.ForeignKey(
        "Scene",
        related_name='layers',
        on_delete=models.CASCADE,
        null=True
    )

    stack_order = models.IntegerField(default=0, blank=False)

    def __str__(self):
        return str(self.layer_display_name + ", estilo: " + self.layer_style)
    
    class Meta:
        db_table = "GeoStoryLayers"

        verbose_name = "Geo Story Layer"

        verbose_name_plural = "GeoStoryLayers"

        ordering = ['stack_order']

    def save(self, *args, **kwargs):
        if self._state.adding:
            layers = GeoStoryLayer.objects.filter(scene=self.scene).order_by('-stack_order')
            if layers.exists():
                self.stack_order = layers[0].stack_order + 1
            else:
                self.stack_order = 1

        super().save(*args, **kwargs)