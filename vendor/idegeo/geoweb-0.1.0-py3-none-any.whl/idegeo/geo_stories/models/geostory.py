# encoding:utf-8
import os

from django.db import models
from django.conf import settings
from .base import IdegeoBaseModel

def get_upload_path(instance, filename):
    return os.path.join(
        "geohistorias", filename)

class GeoStory(IdegeoBaseModel):
    name = models.CharField(
        max_length=256,
        verbose_name='Nombre',
        help_text='Nombre del schema',
        unique=True,
        blank=False
    )

    slug = models.CharField(
        max_length=256,
        verbose_name='URL del geo story',
        unique=True,
        blank=True,
    )
    
    description = models.TextField(
        blank=True,
        verbose_name='Descripcion',
        help_text='Descripcion del schema'
    )

    card_image = models.ImageField(
        verbose_name="Imagen de muestra",
        upload_to=get_upload_path,
        null=True,
        blank=True
    )

    is_public = models.BooleanField(
        verbose_name="hacer pública la geohistoria?",
        default=False
    )
    
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name="Propietario",
        on_delete=models.CASCADE
    )


    def __str__(self):
        return self.name
    
    class Meta:
        db_table = "GeoStories"

        verbose_name = "GeoStory"

        verbose_name_plural = "GeoStories"
    
    def save(self, *args, **kwargs):

        self.slug = self.name.replace(" ","-")
        super(GeoStory, self).save(*args, **kwargs)