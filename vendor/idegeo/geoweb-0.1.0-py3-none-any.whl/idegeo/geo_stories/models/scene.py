# encoding:utf-8
import os

from django.db import models
from django.db.models.fields.files import FieldFile
from django_choices_field import TextChoicesField

from .base import IdegeoBaseModel

def get_upload_path(instance, filename):
    return os.path.join(
        "geohistorias", filename)

FieldFile._require_file = lambda self: None  # type:ignore[attr-defined]

class SceneContentType(models.TextChoices):
    MAP = "map", "Mapa"
    MAP_GROUP = "map-group", "Grupo de mapas"
    CONTENT = "content", "Contenido"

class Scene(IdegeoBaseModel):

    name = models.CharField(
        max_length=256,
        verbose_name='Nombre',
        help_text='Nombre del componente',
        blank=False)
    
    scene_type = TextChoicesField(
        verbose_name="Tipo",
        choices_enum=SceneContentType,
        default=SceneContentType.CONTENT,
        help_text="Tipo del componente"
    )

    dimensions = models.JSONField(
        verbose_name='Dimensions',
        help_text='Dimensiones del componente',
        blank=True,
        null=True)

    content = models.TextField(
        blank=True,
        null=True,
        verbose_name="Contenido",
        help_text="Contenido del componente"
    )

    is_slider = models.BooleanField(
        verbose_name='Habilitar slider',
        default=False
    )

    background_image = models.ImageField(
        verbose_name="Imagen de fondo para slider",
        upload_to=get_upload_path,
        null=True,
        blank=True
    )

    styles = models.JSONField(
        verbose_name="Style of the scene",
        null=True,
        blank=True
    )

    position = models.CharField(
        max_length=256,
        verbose_name="Posicion del componente dentro de una escena",
        blank=True,
        null=True
    )

    stack_order = models.IntegerField(default=0, blank=False)

    map_options = models.OneToOneField(
        "MapOption",
        blank=True,
        null=True,
        on_delete=models.CASCADE
    )

    visibility = models.BooleanField(
        verbose_name="Visibilidad del elemento",
        default=True,
        null=False
    )

    map_center_lat = models.FloatField(
        null=True,
        blank=True)

    map_center_long = models.FloatField(
        null=True,
        blank=True)

    zoom = models.IntegerField(
        null=True,
        blank=True)

    parent_component = models.ForeignKey(
        'self',
        blank=True,
        null=True,
        related_name='children',
        on_delete=models.CASCADE
    )

    geostory = models.ForeignKey(
        'GeoStory',
        blank=False,
        null=False,
        on_delete=models.CASCADE
    )

    def __str__(self):
        return str(self.name)
    
    class Meta:
        db_table = "Scenes"

        verbose_name = "Scene"

        verbose_name_plural = "Scenes"

    def save(self, *args, **kwargs):
        if self._state.adding:
            # Check if there's a parent, and if so, set stack_order based on siblings
            if self.parent_component:
                siblings = Scene.objects.filter(parent_component=self.parent_component).order_by('-stack_order')
                if siblings.exists():
                    self.stack_order = siblings[0].stack_order + 1
                else:
                    self.stack_order = 1
            else:
                # No parent, set stack_order based on other top-level items
                top_level_items = Scene.objects.filter(geostory=self.geostory,parent_component__isnull=True).order_by('-stack_order')
                if top_level_items.exists():
                    self.stack_order = top_level_items[0].stack_order + 1
                else:
                    self.stack_order = 1

            if self.scene_type == SceneContentType.MAP:
                from .map_options import MapOption
                mp = MapOption.objects.create()
                self.map_options = mp

        super().save(*args, **kwargs)
