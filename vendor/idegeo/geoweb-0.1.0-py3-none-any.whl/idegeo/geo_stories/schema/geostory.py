from ninja import ModelSchema
from idegeo.geo_stories.models import GeoStory
from idegeo.people.schema import DefaultUserSchema

class GeostorySchema(ModelSchema):
    owner: DefaultUserSchema

    class Meta:
        model = GeoStory
        fields = ['id', 'name', 'slug', 'description', 'is_public', 'card_image']

class InputGeostorySchema(ModelSchema):
    class Meta:
        model = GeoStory
        fields = ['name', 'description', 'is_public']
    
    class Config:
        arbitrary_types_allowed = True