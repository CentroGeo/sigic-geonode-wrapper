from uuid import UUID
from typing import Optional
from ninja import ModelSchema, Schema
from idegeo.geo_stories.models import GeoStoryLayer

class GeoStoryLayerSchema(ModelSchema):
    class Meta:
        model = GeoStoryLayer
        fields  = "__all__"

class InputGeoStoryLayerSchema(ModelSchema):
    class Meta:
        model = GeoStoryLayer
        exclude  = ['id', 'created_at', 'updated_at', 'scene', 'stack_order']
        
    class Config:
        arbitrary_types_allowed = True


class InputUpdateGeoStoryLayerSchema(ModelSchema):
    layer_url: Optional[str] = None
    layer_name: Optional[str] = None
    class Meta:
        model = GeoStoryLayer
        exclude  = ['id', 'created_at', 'updated_at', 'scene', 'stack_order']
        
    class Config:
        arbitrary_types_allowed = True


class InputDeleteGeoStoryLayerSchema(Schema):
    id: UUID