import json
from typing import TYPE_CHECKING, Optional, List, Any
from ninja import ModelSchema, Schema
from pydantic import validator
from idegeo.geo_stories.models import Scene

if TYPE_CHECKING:
    from idegeo.geo_stories.schema import MapOptionSchema
    from idegeo.geo_stories.schema import GeoStoryLayerSchema


class ChildSceneSchema(ModelSchema):
    map_options: Optional['MapOptionSchema'] = None
    styles: Optional[str | dict] = None
    layers: list['GeoStoryLayerSchema'] = []
    class Meta:
        model = Scene
        fields = "__all__"
        
    @staticmethod
    def resolve_layers(obj):
        return list(obj.layers.all().order_by('stack_order'))



class SceneSchema(ModelSchema):
    map_options: Optional['MapOptionSchema'] = None
    children: list['ChildSceneSchema'] = []
    layers: list['GeoStoryLayerSchema'] = []
    styles: Optional[str | dict] = None
    class Meta:
        model = Scene
        fields = "__all__"
    
    @staticmethod
    def resolve_styles(obj):
        if isinstance(obj.styles,str):
            return json.loads(obj.styles)
        else:
            return obj.styles

    @staticmethod
    def resolve_children(obj):
        return list(obj.children.all().order_by('stack_order'))

    @staticmethod
    def resolve_layers(obj):
        return list(obj.layers.all().order_by('stack_order'))


class InputCreateSceneSchema(ModelSchema):
    geostory: str
    parent_component: Optional[str] = None
    class Meta:
        model = Scene
        fields = ['name','scene_type']

    class Config:
        arbitrary_types_allowed = True
    
    @staticmethod
    def resolve_styles(obj):
        return json.loads(obj.styles)


class InputUpdateSceneSchema(ModelSchema):
    name: Optional[str] = None
    styles_str: Optional[str] = None
    class Meta:
        model = Scene
        exclude = ['id', 'geostory', 'map_options', 'updated_at', 'created_at']
        
    class Config:
        arbitrary_types_allowed = True
    
    @staticmethod
    def resolve_styles(obj):
        if isinstance(obj.styles,str):
            return json.loads(obj.styles)
        else:
            return obj.styles


class InputUpdateSceneOrderSchema(Schema):
    id: str
    stack_order: int
