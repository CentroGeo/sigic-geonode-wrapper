from ninja import ModelSchema
from idegeo.geo_stories.models import MapOption

class MapOptionSchema(ModelSchema):
    class Meta:
        model = MapOption
        fields = [
            'id',
            'base_map',
            'map_center_lat',
            'map_center_long',
            'zoom',
            'show_legend',
            'map_type',
        ]


class InputOptionSchema(ModelSchema):
    class Meta:
        model = MapOption
        fields = [
            'base_map',
            'map_center_lat',
            'map_center_long',
            'zoom',
            'show_legend',
            'map_type',
        ]