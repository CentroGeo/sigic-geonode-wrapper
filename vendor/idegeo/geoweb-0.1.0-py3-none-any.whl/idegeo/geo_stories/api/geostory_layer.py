from typing import List

from ninja import Router, Path, Form
from django.shortcuts import get_object_or_404

from idegeo.geo_stories.models import Scene, GeoStoryLayer
from idegeo.geo_stories.schema import (
    GeoStoryLayerSchema,
    InputGeoStoryLayerSchema,
    InputUpdateGeoStoryLayerSchema,
    SceneSchema,
    InputDeleteGeoStoryLayerSchema
)

router = Router(tags=["Geostories"])


@router.get('/{layer_id}', response=GeoStoryLayerSchema)
def get_layer(request, layer_id: str):
    obj = get_object_or_404(GeoStoryLayer, id=layer_id)
    return obj

@router.post('/add/', response=GeoStoryLayerSchema)
def create_scene_layer(request, payload: Form[InputGeoStoryLayerSchema]):
    payload_dict = payload.dict()
    scene_id = payload_dict.pop('scene')
    scene_obj = get_object_or_404(Scene, id=scene_id)
    obj = GeoStoryLayer(**payload_dict, scene=scene_obj)
    
    obj.save()
    return obj


@router.post('/bulk/add/{scene_id}', response=SceneSchema)
def create_bulk_scene_layers(request, scene_id: str, payload: List[InputGeoStoryLayerSchema]):
    scene_obj = get_object_or_404(Scene, id=scene_id)

    for item in payload:
        obj = GeoStoryLayer(**item.dict(), scene=scene_obj)
        obj.save()

    return scene_obj

@router.put('/update/{layer_id}', response=GeoStoryLayerSchema)
def update_scene_layer(request, layer_id: str, payload: Form[InputUpdateGeoStoryLayerSchema]):
    obj = get_object_or_404(GeoStoryLayer, id=layer_id)
    for attr, value in payload.dict(exclude_unset=True).items():
        setattr(obj, attr, value)

    obj.save()

    return obj


@router.put('/bulk/update/{scene_id}', response=SceneSchema)
def update_bulk_scene_layers(request, scene_id: str, payload: List[InputUpdateGeoStoryLayerSchema]):
    scene_obj = get_object_or_404(Scene, id=scene_id)
    for item in payload:
        try:
            layer_item = item.dict(exclude_unset=True)
            layer_id = layer_item.pop('id')
            obj = GeoStoryLayer.objects.get(id=layer_id)
            for attr, value in layer_item.items():
                setattr(obj, attr, value)

            obj.save()
        except:
            pass

    return scene_obj

@router.delete("/delete/{scene_layer_id}")
def delete_scene_layer(request, scene_layer_id: str):
    obj = get_object_or_404(GeoStoryLayer, id=scene_layer_id)
    obj.delete()
    return {"success": True}


@router.delete("/bulk/delete/{scene_id}", response=SceneSchema)
def bulk_delete_scene_layers(request, scene_id: str, payload: List[InputDeleteGeoStoryLayerSchema]):
    scene_obj = get_object_or_404(Scene, id=scene_id)
    for item in payload:
        try:
            layer = item.dict(exclude_unset=True)
            obj = GeoStoryLayer.objects.get(id=layer["id"])
            obj.delete()
        except:
            pass
    return scene_obj