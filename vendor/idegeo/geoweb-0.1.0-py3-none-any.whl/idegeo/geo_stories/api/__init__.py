from .geostory import router
from .scene import router as scenes_router
from .geostory_layer import router as geostory_layer_router

router.add_router("/scenes/", scenes_router)
scenes_router.add_router("/layers/", geostory_layer_router)