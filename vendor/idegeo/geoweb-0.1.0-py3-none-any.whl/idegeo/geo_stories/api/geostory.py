from uuid import UUID
from typing import List, Optional
from ninja import Router, UploadedFile, File, Form
from ninja.pagination import paginate, PageNumberPagination
from django.shortcuts import get_object_or_404

from idegeo.geo_stories.models import GeoStory, Scene
from idegeo.geo_stories.schema import GeostorySchema, InputGeostorySchema, SceneSchema

router = Router(tags=["Geostories"])


@router.get('/{identifier}', response=GeostorySchema, auth=None)
def get_geostory(request, identifier: str):
    obj = GeoStory.objects.none()
    try:
        uuid_val = UUID(identifier)
        obj = obj.get(id=uuid_val)
    except ValueError:
        obj = get_object_or_404(GeoStory, slug=identifier)
    return obj

@router.get('/', response=List[GeostorySchema], auth=None)
@paginate(PageNumberPagination, page_size=10)
def list_geostories(
    request, 
    user: Optional[str] = None,
    is_public: Optional[bool] = None
):
    queryset = GeoStory.objects.select_related("owner").order_by("-created_at")

    if user:
        queryset = queryset.filter(owner__id=user)

    if is_public is not None:
        queryset = queryset.filter(is_public=is_public)

    return list(queryset)

@router.post('/add/', response=GeostorySchema)
def create_geostory(request, payload: Form[InputGeostorySchema], card_image: File[UploadedFile] = None):
    payload_dict = payload.dict()
    obj = GeoStory(**payload_dict, owner=request.user)

    if not card_image:
        obj.save()
    else:
        obj.card_image.save(card_image.name, card_image) 

    return obj


@router.put('/update/{geostory_id}', response=GeostorySchema)
def update_geostory(request, geostory_id: str, payload: Form[InputGeostorySchema], card_image: File[UploadedFile] = None):
    obj = get_object_or_404(GeoStory, id=geostory_id)
    for attr, value in payload.dict(exclude_unset=True).items():
        setattr(obj, attr, value)

    if not card_image:
        obj.save()
    else:
        obj.card_image.save(card_image.name, card_image)

    return obj

@router.delete('/delete/{geostory_id}')
def delete_geostory(request, geostory_id: str):
    obj = get_object_or_404(GeoStory, id=geostory_id)
    obj.delete()
    return {"success": True}


# related scenes of the geostory
@router.get('/{identifier}/scenes/', response=List[SceneSchema], auth=None)
def list_scenes(request, identifier: str):
    queryset = Scene.objects.none()
    try:
        uuid_val = UUID(identifier)
        queryset = Scene.objects.filter(geostory__id=uuid_val)
    except ValueError:
        queryset = Scene.objects.filter(geostory__slug=identifier)
    queryset = queryset.filter(parent_component__isnull=True)
    
    return list(queryset.order_by("stack_order"))
