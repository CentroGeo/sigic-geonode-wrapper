import json
from typing import List

from ninja import Router, Path, Form, UploadedFile, File
from django.shortcuts import get_object_or_404

from idegeo.geo_stories.models import GeoStory, Scene, GeoStoryLayer, MapOption
from idegeo.geo_stories.schema import (
    SceneSchema,
    GeoStoryLayerSchema,
    InputCreateSceneSchema,
    InputUpdateSceneSchema,
    InputUpdateSceneOrderSchema,
    InputOptionSchema
)

router = Router(tags=["Geostories"])

@router.get('/{scene_id}', response=SceneSchema)
def get_scene(request, scene_id: str):
    obj = get_object_or_404(Scene, id=scene_id)
    return obj

@router.post('/add/', response=SceneSchema)
def create_scene(request, payload: Form[InputCreateSceneSchema]):
    payload_dict = payload.dict()
    geostory_id = payload_dict.pop('geostory')
    parent_scene_id = payload_dict.pop('parent_component')
    geostory_obj = get_object_or_404(GeoStory, id=geostory_id)

    if parent_scene_id:
        parent_scene = get_object_or_404(Scene, id=parent_scene_id)
        obj = Scene(**payload_dict, geostory=geostory_obj, parent_component=parent_scene)
    else:
        obj = Scene(**payload_dict, geostory=geostory_obj)
    obj.save()

    return obj

@router.put('/bulk/reorder', response=List[SceneSchema])
def update_scene_order(request, payload: List[InputUpdateSceneOrderSchema]):
    scenes = []
    for obj in payload:
        scene_obj = get_object_or_404(Scene, id=obj.id)
        scene_obj.stack_order = obj.stack_order
        scene_obj.save()
        scenes.append(scene_obj)

    return scenes

@router.put('/update/{scene_id}', response=SceneSchema)
def update_scene(request, scene_id: str, payload: Form[InputUpdateSceneSchema], background_image: File[UploadedFile] = None):
    obj = get_object_or_404(Scene, id=scene_id)
    for attr, value in payload.dict(exclude_unset=True).items():
        if attr == "styles_str":
            setattr(obj, "styles", json.loads(value))
        else:
            setattr(obj, attr, value)

    if not background_image:
        obj.save()
    else:
        obj.background_image.save(background_image.name, background_image)

    return obj

@router.delete('/delete/{scene_id}')
def delete_scene(request, scene_id: str):
    obj = get_object_or_404(Scene, id=scene_id)
    obj.delete()
    return {"success": True}


@router.put('/map-options/update/{map_options_id}', response=SceneSchema)
def update_scene_map_options(request, map_options_id: str, payload: Form[InputOptionSchema]):
    obj = get_object_or_404(MapOption, id=map_options_id)
    for attr, value in payload.dict(exclude_unset=True).items():
        if attr == "base_map":
            setattr(obj, attr, json.loads(value))
        else:
            setattr(obj, attr, value)
    obj.save()

    scene = get_object_or_404(Scene, map_options=map_options_id)
    return scene


# related layer to a scene
@router.get('/{scene_id}/layers', response=List[GeoStoryLayerSchema])
def list_layers(request, scene_id: str):
    queryset = GeoStoryLayer.objects.filter(scene__id=scene_id)
    return list(queryset)