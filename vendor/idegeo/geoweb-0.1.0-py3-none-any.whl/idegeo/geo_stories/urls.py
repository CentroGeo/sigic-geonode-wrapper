from django.urls import path
from . import views

urlpatterns = [
  path('', views.index, name='geohistorias'),
  path('historia/<path:rest>', views.index, name='public_geostory'),
]