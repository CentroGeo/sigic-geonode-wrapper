import os
import re
import json
import requests
from weasyprint import HTML

from django.db.models import Q
from django.template.loader import render_to_string
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, JsonResponse
from owslib.wms import WebMapService
from idegeo.GeonodeModels.utils import get_visible_resources
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_GET, require_POST

from idegeo.geovisor.models import UserMaps
from idegeo.GeonodeModels.models import Region, TopicCategory, HierarchicalKeyword, ResourceBase, Layers


def geovisor(request):
    user = request.user
    is_auth = ""
    userSerialize = {}

    if user.is_authenticated and not user.is_anonymous:
        userSerialize["id"] = user.id
        userSerialize["token"] = user.token
        userSerialize["username"] = user.username
        userSerialize["is_superuser"] = user.is_superuser
        userSerialize["is_staff"] = user.is_staff
        userSerialize["geostories_access"] = user.geostories_access
        is_auth = "True"

    return render(
        request,
        "geovisor.html",
        {
            'user_isauth': is_auth,
            'user': json.dumps(userSerialize)
        },
    )


def generar_pdf(html):
    pdf = HTML(string=html).write_pdf()

    if pdf:
        return HttpResponse(pdf, content_type="application/pdf")

    return HttpResponse("Error al generar el PDF")


def pdf_metadata_layer(request, layer_pk):

    response = requests.get(
        os.getenv("GEONODE_API_ROOT") + "api/v2/datasets/" + layer_pk
    )

    layer_info = response.json()

    layer = layer_info["dataset"]

    rendered = render_to_string(
        "pdf_metadata_layer.html", {"pagesize": "A4", "resource": layer}
    )

    return generar_pdf(rendered)


def external_wms(request):
    if request.method == "POST":
        # Get the raw bytes of the request payload
        payload = request.body

        # Parse the payload as JSON
        data = json.loads(payload)

        # Get the value of the wmsUrl variable from the JSON data
        wms_url = data.get("wmsUrl")
        name_search = data.get("nameSearch")
        layers_dict = {}

        wms = WebMapService(wms_url)

        layers = list(wms.contents)

        if name_search:
            if name_search in layers:
                layers_dict[name_search] = {
                    "title": wms.contents[name_search].title,
                    "styles": wms.contents[name_search].styles,
                    "abstract": wms.contents[name_search].abstract,
                    "bbox": wms.contents[name_search].boundingBox,
                }
        else:
            for layer in layers:
                layers_dict[layer] = {
                    "title": wms.contents[layer].title,
                    "styles": wms.contents[layer].styles,
                    "abstract": wms.contents[layer].abstract,
                    "bbox": wms.contents[layer].boundingBox,
                }
        return JsonResponse(layers_dict)

    else:
        return HttpResponse("Not ajax request")


# API endpoints
def get_regions(request):

    regions = Region.objects.all().order_by("name")

    regions_dict = []
    notAllowedNames = ["Americas", "North America", "Global", "Central America"]
    for r in regions:
        if r.count > 0 and r.name not in notAllowedNames:
            regions_dict.append(
                {
                    "id": r.id,
                    "bbox_x0": (
                        float(r.bbox_x0)
                        if r.bbox_x0 is not None
                        else -118.867171999999997
                    ),
                    "bbox_x1": (
                        float(r.bbox_x1)
                        if r.bbox_x1 is not None
                        else -86.703391999999994
                    ),
                    "bbox_y0": (
                        float(r.bbox_y0)
                        if r.bbox_y0 is not None
                        else 14.532850000000000
                    ),
                    "bbox_y1": (
                        float(r.bbox_y1)
                        if r.bbox_y1 is not None
                        else 32.718620000000001
                    ),
                    "code": r.code,
                    "count": get_visible_resources(
                        request.user, r.layers_set.all()
                    ).count(),
                    "link": f'{os.getenv("GEONODE_API_ROOT")}api/v2/regions/{r.id}',
                    "name": r.name,
                    "name_en": r.name_en,
                    "parent": r.parent.id if r.parent else None,
                    "srid": r.srid,
                }
            )

    return JsonResponse({"regions": regions_dict})


def get_categories(request):

    categories = TopicCategory.objects.all().order_by('gn_description')

    categories_dict = []
    for c in categories:

        q = Q(resource_type="dataset")
        
        if 'region' in request.GET: 
            q &= Q(layers__regions__name=request.GET['region'])

        resources_count = get_visible_resources(
            request.user, c.resourcebase_set.filter(q)
        ).count()
        
        if resources_count > 0:
            categories_dict.append(
                {
                    "id": c.id,
                    "identifier": c.identifier,
                    "description": c.description,
                    "description_en": c.description_en,
                    "gn_description": c.gn_description,
                    "gn_description_en": c.gn_description_en,
                    "is_choice": c.is_choice,
                    "fa_class": c.fa_class,
                    "link": f'{os.getenv("GEONODE_API_ROOT")}api/v2/categories/{c.id}',
                    "count": resources_count,
                }
            )

    return JsonResponse({"categories": categories_dict})


def get_keywords(request):
    tags = HierarchicalKeyword.objects.all().order_by('name')
    tags_dict = []
    for t in tags:
        if (
            t.keywords.filter(
                content_object__gt=0,
                content_object__resource_type__exact='dataset',
            ) 
            and t.name != 'GEOSERVER'
            and t.name != 'WFS'
            and t.name != 'WMS'
        ):
            tags_dict.append({
                'id': t.id,
                'name': t.name,
                'layers': get_visible_resources(request.user,t.keywords).count(),
            })
            
    return JsonResponse({"keywords": tags_dict})


def get_providers(request):
    
    qs = ResourceBase.objects.filter(
        resource_type="dataset"
    ).exclude(
        edition__isnull=True
    ).values_list(
        "edition", flat=True
    ).order_by('edition').distinct()

    # Remove any editions that contain 4-digit numbers (likely years)
    cleaned = [
        e for e in qs
        if not re.search(r"\b\d{4}\b", e)
    ]
            
    return JsonResponse({"providers": cleaned})


def get_layer(request):
    try:
        layer = Layers.objects.get(
            resourcebase_ptr__id=request.GET['id']
        )

        return JsonResponse({
            'id': layer.resourcebase_ptr.id,
            'pk': layer.resourcebase_ptr.id,
            'uuid': layer.resourcebase_ptr.uuid,
            'workspace': layer.workspace,
            'store': layer.store,
            'name': layer.name,
            'typename': layer.typename,
            'charset': layer.charset,
            'default_style': {
                'id': layer.default_style.id if layer.default_style else None,
                'name': layer.default_style.name if layer.default_style else None,
                'sld_title': layer.default_style.sld_title if layer.default_style else None,
                'workspace': layer.default_style.workspace if layer.default_style else None
            },
            'elevation_regex': layer.elevation_regex,
            'has_elevation': layer.has_elevation,
            'has_time': layer.has_time,
            'subtype': layer.resourcebase_ptr.subtype,
            'title': layer.resourcebase_ptr.title,
            'abstract': layer.resourcebase_ptr.abstract,
            'll_bbox_polygon': layer.resourcebase_ptr.ll_bbox_polygon.geojson,
            'extent': layer.resourcebase_ptr.ll_bbox_polygon.extent,
            'is_mosaic': layer.is_mosaic,
            'time_regex': layer.time_regex,
            'date': layer.resourcebase_ptr.date,
            'remote_service_id': layer.remote_service_id,
            'featureinfo_custom_template': layer.featureinfo_custom_template,
            'use_featureinfo_custom_template': layer.use_featureinfo_custom_template,
            'ptype': layer.ptype,
            'thumbnail_url': layer.resourcebase_ptr.thumbnail_url,
            'ows_url': layer.ows_url,
            'gwc_url': layer.ows_url.replace('ows', 'gwc/service/wms'),
            'direct_wps_download_url': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WPS&version=1.0.0&request=Execute&identifier=gs:Download&datainputs=layerName=geonode:{layer.name};outputFormat=application/zip&RawDataOutput=result',
            'download_url': f'{os.getenv("GEONODE_API_ROOT")}datasets/geonode:{layer.name}/dataset_download',
            'legend': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{layer.name}&STYLE={layer.default_style.name if layer.default_style else ""}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:12;forceLabels:on',
            'attributes': [
                {
                    'attribute': a.attribute, 
                    'visible': a.visible,
                    'label': a.attribute_label
                } for a in layer.attributes
            ],
            'category': {
                'id': layer.resourcebase_ptr.category.id,
                'identifier': layer.resourcebase_ptr.category.identifier,
                'description': layer.resourcebase_ptr.category.description,
                'gn_description': layer.resourcebase_ptr.category.gn_description,
                'fa_class': layer.resourcebase_ptr.category.fa_class,
                'count': 1
            } if layer.resourcebase_ptr.category else None,
            'regions': [
                {
                    'code': r.code,
                    'name': r.name
                } for r in layer.regions.all()
            ]
        })

    except Layers.DoesNotExist:
        return JsonResponse({'message': "the requested layer does not exists"}, status=404)
    except (TypeError, ValueError):
        return JsonResponse({'message': "Bad layer id"}, status=500)
    


@require_POST
@login_required
def create_user_map(request):
    name = request.POST.get("name")
    layers_config = request.POST.get("layers_config")
    mapview_config = request.POST.get("mapview_config")

    map_instance = UserMaps(
        name=name,
        layers_configuration=json.loads(layers_config),
        mapview_configuration=json.loads(mapview_config),
        owner=request.user
    )

    map_instance.save()

    return JsonResponse(
        {"success": True, "mapId": map_instance.id, "mapName": map_instance.name}
    )

@require_POST
@login_required
def update_user_map(request):
    map_id = request.POST.get("mapId")
    name = request.POST.get("name")
    layers_config = request.POST.get("layers_config")
    mapview_config = request.POST.get("mapview_config")

    if not map_id:
        return JsonResponse({"success": False, "error": "Missing mapId"}, status=400)

    map_instance = get_object_or_404(UserMaps, id=map_id, owner=request.user)

    if name is not None:
        map_instance.name = name
    if layers_config is not None:
        map_instance.layers_configuration = json.loads(layers_config)
    if mapview_config is not None:
        map_instance.mapview_configuration = json.loads(mapview_config)

    map_instance.save()

    return JsonResponse(
        {"success": True, "mapId": map_instance.id, "mapName": map_instance.name}
    )


@require_POST
@login_required
def delete_user_map(request, map_id):
    try:
        map_obj = UserMaps.objects.get(id=map_id)

        map_obj.delete()

        return JsonResponse({"success": True, "message": "Map deleted successfully"})
    except UserMaps.DoesNotExist:
        return JsonResponse({"success": False, "message": "404 Map does not exists"})



@require_GET
@login_required
def get_user_maps(request):
    q = Q(owner=request.user)

    if 'name' in request.GET: 
        q &= Q(name__icontains=request.GET['name'])
    
    queryset = UserMaps.objects.filter(q)
    queryset = queryset.order_by('id')

    if 'page_size' in request.GET: 
        page_size = int(request.GET['page_size'])
    else:
        page_size = 10

    if 'page' in request.GET:
        page = int(request.GET['page'])
    else:
        page = 1
        
    start_index = (page - 1) * page_size
    end_index = page * page_size

    objects = queryset[start_index:end_index]

    total_records = queryset.count()
    total_pages = (total_records + page_size - 1) // page_size

    user_maps = []
    for map_obj in objects:
        user_maps.append({
            "id": map_obj.id,
            "name": map_obj.name
        })

    return JsonResponse({
        "maps": user_maps,
        "total": total_records,
        "total_pages": total_pages
    })


@require_GET
def get_user_map_data(request, map_id):
    
    try:
        object = UserMaps.objects.get(id=map_id)

        layers = []
        for layer_dict in object.layers_configuration:
            print(layer_dict)
            try:
                layer = Layers.objects.get(
                    resourcebase_ptr__id=layer_dict['id']
                )
                layers.append({
                    **layer_dict,
                    'workspace': layer.workspace,
                    'store': layer.store,
                    'name': layer.name,
                    'typename': layer.typename,
                    'charset': layer.charset,
                    'elevation_regex': layer.elevation_regex,
                    'has_elevation': layer.has_elevation,
                    'has_time': layer.has_time,
                    'subtype': layer.resourcebase_ptr.subtype,
                    'title': layer.resourcebase_ptr.title,
                    'abstract': layer.resourcebase_ptr.abstract,
                    'll_bbox_polygon': layer.resourcebase_ptr.ll_bbox_polygon.geojson,
                    'extent': layer.resourcebase_ptr.ll_bbox_polygon.extent,
                    'is_mosaic': layer.is_mosaic,
                    'time_regex': layer.time_regex,
                    'date': layer.resourcebase_ptr.date,
                    'remote_service_id': layer.remote_service_id,
                    'featureinfo_custom_template': layer.featureinfo_custom_template,
                    'use_featureinfo_custom_template': layer.use_featureinfo_custom_template,
                    'ptype': layer.ptype,
                    'thumbnail_url': layer.resourcebase_ptr.thumbnail_url,
                    'ows_url': layer.ows_url,
                    'gwc_url': layer.ows_url.replace('ows', 'gwc/service/wms'),
                    'direct_wps_download_url': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WPS&version=1.0.0&request=Execute&identifier=gs:Download&datainputs=layerName=geonode:{layer.name};outputFormat=application/zip&RawDataOutput=result',
                    'download_url': f'{os.getenv("GEONODE_API_ROOT")}datasets/geonode:{layer.name}/dataset_download',
                    'legend': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{layer.name}&STYLE={layer.default_style.name if layer.default_style else ""}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:12;forceLabels:on',
                    'legend_no_style': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{layer.name}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:12;forceLabels:on',
                    'attributes': [
                        {
                            'attribute': a.attribute, 
                            'visible': a.visible,
                            'label': a.attribute_label
                        } for a in layer.attributes
                    ],
                    'styles': [{
                        'id': style.id,
                        'name': style.name,
                        'sld_title': style.sld_title,
                        'workspace': style.workspace
                    } for style in layer.styles.all()],
                })
            except UserMaps.DoesNotExist:
                continue

        return JsonResponse({
            "id": object.id,
            "layers": layers,
            "mapview": object.mapview_configuration,
            "owner": object.owner.id
        })
    except UserMaps.DoesNotExist:
        return JsonResponse({"success": False, "message": "404 Map does not exists"})