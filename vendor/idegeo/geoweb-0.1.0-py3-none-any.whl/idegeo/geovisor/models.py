from django.db import models
from django.conf import settings



class UserMaps(models.Model):
    name = models.CharField(max_length=250,null=False,blank=False)

    layers_configuration = models.JSONField()

    mapview_configuration = models.JSONField()

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name="Propietario",
        on_delete=models.CASCADE
    )

    class Meta:
        db_table = "usermaps"

        verbose_name = "User Map"

        verbose_name_plural = "User Maps"

