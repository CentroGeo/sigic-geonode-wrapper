from django.urls import path, re_path
from . import views

urlpatterns = [
  path("regions/", views.get_regions, name="get_regions"),
  path("categories/", views.get_categories, name="get_categories"),
  path("keywords/", views.get_keywords, name="get_keywords"),
  path("providers/", views.get_providers, name="get_providers"),
  path("layer_info/", views.get_layer, name="get_layer_info"),
  path("create_user_map/", views.create_user_map, name="create_user_map"),
  path("update_user_map/", views.update_user_map, name="update_user_map"),
  re_path(r'^delete_user_map/(?P<map_id>[^/]*)$', views.delete_user_map, name="delete_user_map"),
  path("get_user_maps/", views.get_user_maps, name="get_user_maps"),
  re_path(r'^get_user_map_data/(?P<map_id>[^/]*)$', views.get_user_map_data, name="get_user_map_data"),
  re_path(r'^external_wms/', views.external_wms, name='external_wms'),
  re_path(r'^pdf_metadata_layer/(?P<layer_pk>[^/]*)$', views.pdf_metadata_layer, name="pdf_metadata_layer"),
]