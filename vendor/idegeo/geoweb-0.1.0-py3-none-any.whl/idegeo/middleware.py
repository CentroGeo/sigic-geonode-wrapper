import threading
from datetime import datetime
from django.conf import settings
from django.urls import reverse
from django.shortcuts import redirect
from django.utils.timezone import make_aware
from django.contrib.auth import logout

# Thread-local storage for request user
_user_storage = threading.local()

class GeonodeSessionMiddleware:
    """
    Middleware to check if the user has an OAuth token.
    If not, it logs out the user and clears the session.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Check if the user is authenticated
        if request.user.is_authenticated:
            user = request.user

            # Check if `oauth_token` exists and is not empty
            if not hasattr(user, "oauth_token") or not user.oauth_token:
                self.logout_user(request)

            # Check if `token_expires` exists and is still valid
            elif not hasattr(user, "token_expires") or user.token_expires is None:
                self.logout_user(request)

            else:
                # Ensure `token_expires` is timezone-aware
                token_expiry = user.token_expires
                if not token_expiry.tzinfo:  # If naive, make it timezone-aware
                    token_expiry = make_aware(token_expiry)

                # If the token is expired, log out the user
                if token_expiry < datetime.now(token_expiry.tzinfo):
                    self.logout_user(request)

        response = self.get_response(request)
        return response

    def logout_user(self, request):
        """Helper method to log out the user and clear the session."""
        logout(request)
        request.session.flush()
        return redirect("/accounts/login/?next=" + request.path)


class UserMiddleware:
    """Middleware to store the request user in a thread-local variable."""
    
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        _user_storage.user = request.user  # Store user in thread-local variable
        response = self.get_response(request)
        return response

    @staticmethod
    def get_current_user():
        """Retrieve the stored user from thread-local storage."""
        return getattr(_user_storage, "user", None)
    

class LoginRequiredMiddleware:
    """
    Middleware that redirects unauthenticated users to the login page.
    It can be enabled or disabled via the LOGIN_REQUIRED setting.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Check if middleware is enabled
        if getattr(settings, "LOGIN_REQUIRED", True):
            # Allow access to the login and admin pages without authentication
            allowed_urls = [reverse("login"), reverse("admin:login")]
            
            if not request.user.is_authenticated and request.path not in allowed_urls:
                return redirect(f"{reverse('login')}?next={request.path}")

        return self.get_response(request)