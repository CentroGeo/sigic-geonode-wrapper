from django.urls import re_path
from idegeo.dashboard.views import list_views


urlpatterns = [
    re_path(r'^$', list_views.ListSitesView.as_view(), name='sites'),
    re_path(r'^sitio/(?P<pk>\d+)/grupos/$', list_views.ListGroupsView.as_view(), name='groups'),
    re_path(r'^grupo/(?P<pk>\d+)/subgrupos/$', list_views.ListSubGroupView.as_view(), name='subgroups'),
    re_path(r'^indicadores/(?P<type>[\w\-]+)/(?P<pk>\d+)$', list_views.ListIndicatorView.as_view(), name='indicators'),
]