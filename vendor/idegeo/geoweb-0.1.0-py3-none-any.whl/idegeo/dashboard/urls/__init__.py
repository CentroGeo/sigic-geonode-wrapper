from . import list_views
from . import create_views
from . import detail_views
from . import utils
from . import dashboard

urlpatterns = [
    *list_views.urlpatterns,
    *create_views.urlpatterns,
    *detail_views.urlpatterns,
    *utils.urlpatterns,
    *dashboard.urlpatterns,
]