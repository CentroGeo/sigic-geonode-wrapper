from django.urls import re_path
from idegeo.dashboard.views import create_views


urlpatterns = [
    re_path(r'^crear_sitio/$', create_views.CreateSitesView.as_view(), name='create_site'),
    re_path(r'^sitio/(?P<pk>\d+)/crear_grupo/$', create_views.CreateGroupsView.as_view(), name='create_group'),
    re_path(r'^grupo/(?P<pk>\d+)/crear_subgrupo/$', create_views.CreateSubGroupView.as_view(), name='create_subgroup'),
    re_path(r'^crear_indicador/(?P<type>[\w\-]+)/(?P<pk>\d+)$', create_views.CreateIndicatorView.as_view(), name='create_indicator'),
]