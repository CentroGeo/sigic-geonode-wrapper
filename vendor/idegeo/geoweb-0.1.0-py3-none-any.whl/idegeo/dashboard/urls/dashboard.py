from django.urls import re_path
from idegeo.dashboard import views

urlpatterns = [
    re_path(r'(?P<url>[\w\-]+)$', views.site_dashboard, name='site_dashboard'),
]