from django.urls import re_path
from idegeo.dashboard.views import detail_views


urlpatterns = [
    re_path(r'^sitio/(?P<pk>\d+)$', detail_views.DetailSiteView.as_view(), name='detail_site'),
    re_path(r'^grupo/(?P<pk>\d+)$', detail_views.DetailGroupView.as_view(), name='detail_group'),
    re_path(r'^subgroup/(?P<pk>\d+)$', detail_views.DetailSubGroupView.as_view(), name='detail_subgroup'),
    re_path(r'^indicador/(?P<pk>\d+)$', detail_views.DetailIndicatorView.as_view(), name='detail_indicator'),
]