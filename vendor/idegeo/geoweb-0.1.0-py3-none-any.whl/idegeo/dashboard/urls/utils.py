from django.urls import re_path
from idegeo.dashboard.utils import api_calls


urlpatterns = [
    re_path(r'^build_indicator_data/$', api_calls.build_indicator_data, name='build_indicator_data'),
    re_path(r'^save_indicator_data/$', api_calls.save_indicator_data, name='save_indicator_data'),
    re_path(r'^create_infobox_data/$', api_calls.create_infobox_data, name='create_infobox_data'),
    re_path(r'^update_infobox_data/$', api_calls.update_infobox_data, name='update_infobox_data'),
    re_path(r'^save_styles_data/$', api_calls.save_styles_data, name='save_styles_data'),
    re_path(r'^create_or_update_logo/$', api_calls.create_or_update_logo, name='create_or_update_logo'),
    re_path(r'^view_indicator_data/$', api_calls.view_indicator_data, name='view_indicator_data'),
    re_path(r'^select_group_data/$', api_calls.select_group_data, name='select_group_data'),
    re_path(r'^save_stack_order_data/$', api_calls.save_stack_order_data, name='save_stack_order_data'),
    re_path(r'^clone_indicator/$', api_calls.clone_indicator, name='clone_indicator'),
    re_path(r'^delete_logo/$', api_calls.delete_logo, name='delete_logo'),
    re_path(r'^delete_infobox/$', api_calls.delete_infobox, name='delete_infobox'),
    re_path(r'^get_indicators_data/$', api_calls.get_indicators_data, name='get_indicators_data'),
    re_path(r'^get_info_data/$', api_calls.get_info_data, name='get_info_data'),
]