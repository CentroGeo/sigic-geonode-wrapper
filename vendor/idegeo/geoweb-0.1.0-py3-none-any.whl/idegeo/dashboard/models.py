# -*- encoding: utf-8 -*-__unicode__
import os
from django.db import models
from ckeditor_uploader.fields import RichTextUploadingField
from fontawesome_6.fields import IconField
from idegeo.base.related import GeonodeForeignKey

FONTS = (
    ('Roboto', 'Roboto'),
    ('Poppins', 'Poppins '),
    ('Nunito', 'Nunito'),
    ('Lato', 'Lato'),
    ('Aleo', 'Aleo'),
    ('Muli', 'Muli'),
    ('Arapey', 'Arapey'),
    ('Assistant', 'Assistant'),
    ('Barlow', 'Barlow'),
    ('Oswald', 'Oswald'),
    ('Bitter', 'Bitter'),
    ('Rokkitt', 'Rokkitt'),
    ('Carme', 'Carme'),
    ('Rubik', 'Rubik'),
    ('Gelasio', 'Gelasio'),
    ('Spectral', 'Spectral'),
    ('Alegreya', 'Alegreya'),
    ('Montserrat', 'Montserrat'),
    ('Abhaya Libre', 'Abhaya Libre'),
    ('Asap Condensed', 'Asap Condensed'),
    ('Source Sans Pro', 'Source Sans Pro'),
    ('Roboto Mono', 'Roboto Mono'),
    ('Merriweather Sans', 'Merriweather Sans'),
    ('Merriweather', 'Merriweather'),
    ('Architects Daughter', 'Architects Daughter')
)

SIZE = (
    ('1', 'Normal'),
    ('2', 'Grande'),
    ('3', 'Extra grande'),
)

EDGE = (
    ('1', 'Izquierdo'),
    ('2', 'Derecho'),
    ('3', 'Superior'),
    ('4', 'Inferior'),
    ('5', 'Paralelos horizontales'),
    ('6', 'Paralelos verticales'),
    ('7', 'Borde completo'),
    ('8', 'Sin bordes'),
)

def get_upload_path(instance, filename):
                    return os.path.join("indicadores", filename)


class Site(models.Model):

    name = models.CharField(
        verbose_name="Nombre del sitio",
        help_text="Este es un nombre corto para identificar rápidamente el sitio",
        max_length=250,
        unique=True
    )

    info_text = RichTextUploadingField(
        verbose_name="Información de sitio",
        help_text="Opcional",
        null=True,
        blank=True
    )

    title = models.CharField(
        verbose_name="Titulo del sitio",
        help_text="Es el título que puede mostrarse en el header",
        max_length=500
    )

    subtitle = models.CharField(
        verbose_name="Subtitulo del sitio",
        help_text="Este también aparece en el header",
        max_length=500
    )

    url = models.CharField(
        verbose_name="url del sitio",
        help_text="Es la url del sitio que completa la liga dashboards/",
        max_length=500
    )
    
    def __str__(self):
        return self.name


class SiteLogos(models.Model):

    site = models.ForeignKey(
        Site,
        related_name="icons",
        on_delete=models.CASCADE
    )

    icon = models.ImageField(
        verbose_name="Logo",
        help_text='Este logo se muestra en el header',
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None
    )

    icon_link = models.URLField(
        verbose_name="Link del logo",
        blank=True,
        default=None
    )

    stack_order = models.IntegerField(
        null=False,
        blank=False,
        default=1
    )

class IndicatorGroup(models.Model):

    site = models.ForeignKey(Site,
        on_delete=models.CASCADE)

    name = models.CharField(
        verbose_name="Nombre del grupo de indicadores.",
        max_length=250
    )

    info_text = RichTextUploadingField(
        verbose_name="Información de grupo",
        help_text="Opcional",
        null=True,
        blank=True
    )

    description = models.CharField(
        verbose_name="Descripcion del grupo.", max_length=250
    )

    stack_order = models.IntegerField(
        null=False,
        blank=False,
        default=1
    )
    
    def __str__(self):
        return self.name


class SubGroup(models.Model):

    group = models.ForeignKey(IndicatorGroup,
        on_delete=models.CASCADE)

    name = models.CharField(
        verbose_name="Nombre del subgrupo de indicadores.",
        max_length=250
    )

    info_text = RichTextUploadingField(
        verbose_name="Información de subgrupo",
        help_text="Opcional",
        null=True,
        blank=True
    )

    icon = IconField(
        verbose_name="Icono del subgrupo de indicadores."
    )

    icon_custom = models.ImageField(
        verbose_name="Icono personalizado del subgrupo de indicadores.",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None
    )

    stack_order = models.IntegerField(
        null=False,
        blank=False,
        default=1
    )
    
    def __str__(self):
        return self.name


class Indicator(models.Model):

    subgroup = models.ForeignKey(
        SubGroup,
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )

    group = models.ForeignKey(
        IndicatorGroup,
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )

    site = models.ForeignKey(
        Site,
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )

    name = models.CharField(
        verbose_name="Nombre del indicador",
        max_length=250
    )

    plot_type = models.CharField(
        verbose_name="Tipo de gráfica",
        max_length=250
    )

    info_text = RichTextUploadingField(
        verbose_name="Información de indicador",
        help_text="Opcional",
        null=True,
        blank=True
    )

    layer = GeonodeForeignKey(
        'GeonodeModels.Layers',
        verbose_name="Capa de indicador",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        db_constraint=False,
    )

    layer_id_field = models.CharField(
        verbose_name="Campo id para identificar geometrías de la capa",
        max_length=550,
        blank=False,
        null=False
    )

    layer_nom_field = models.CharField(
        verbose_name="Campo para nombrar geometrías de la capa",
        max_length=550,
        blank=True,
        null=True
    )

    high_values_percentage = models.IntegerField(
        verbose_name="Porcentaje de geometrías a recuperar",
        default=10,
        blank=True,
        null=True
    )

    use_single_field = models.BooleanField(
        verbose_name="Generar gráfica con un solo campo",
        blank=False,
        null=False,
        default=False
    )

    is_histogram = models.BooleanField(
        verbose_name="Indicador de histograma",
        help_text="""Si se selecciona esta opción, el indicador se 
                    generará como un histograma, pudiendo elegir los 
                    campos para el mismo.""",
        blank=False,
        null=False,
        default=False
    )

    histogram_fields = models.JSONField(
        verbose_name='Campos para generar el histograma',
        blank=True,
        null=True
    ) 

    field_one = models.CharField(
        verbose_name="Campo 1",
        max_length=550,
        blank=False,
        null=False
    )

    field_two = models.CharField(
        verbose_name="Campo 2",
        max_length=550,
        blank=True,
        null=True
    )

    field_popup = models.JSONField(
        verbose_name='Campos para desplegar info en el popup',
        blank=True,
        null=True
    )

    category_method = models.CharField(
        verbose_name="Metodo de clasificación",
        max_length=250,
        blank=True,
        null=True,
    )

    field_category = models.IntegerField(
        verbose_name="Número de categorías para gráfica",
        blank=True,
        null=True,
        default=5
    )

    colors = models.CharField(
        verbose_name="Colores de gráfico y tematización",
        max_length=250,
        blank=True,
        null=True
    )

    use_custom_colors = models.BooleanField(
        verbose_name="Usar colores provistos por el cliente",
        blank=False,
        null=False,
        default=False
    )

    custom_colors = models.CharField(
        verbose_name="Colores custom de gráfico y tematización",
        max_length=250,
        blank=True,
        null=True
    )

    plot_config = models.JSONField(
        verbose_name='Configuracion para la gráfica',
        blank=True,
        null=True
    )

    
    plot_values = models.JSONField(
        verbose_name='Valores para la gráfica',
        blank=True,
        null=True
    )


    map_values = models.JSONField(
        verbose_name='Valores para tematización de la capa',
        blank=True,
        null=True
    )

    show_general_values = models.BooleanField(
        verbose_name="Mostrar valores generales",
        blank=False,
        default=False
    )

    use_filter = models.BooleanField(
        verbose_name="Activar filtro",
        blank=False,
        default=False
    )

    filters = models.JSONField(
        verbose_name='Filtros',
        blank=True,
        null=True
    )
    
    stack_order = models.IntegerField(
        null=False,
        blank=False,
        default=1
    )


    def __str__(self):
        return self.name


class IndicatorSlider(models.Model):

    subgroup = models.ForeignKey(
        SubGroup,
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )

    group = models.ForeignKey(
        IndicatorGroup,
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )

    site = models.ForeignKey(
        Site,
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )

    name = models.CharField(
        verbose_name="Nombre del indicador",
        max_length=250
    )

    layer = GeonodeForeignKey(
        'GeonodeModels.Layers',
        verbose_name="Capa de indicador",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        db_constraint=False
    )

    layer_id_field = models.CharField(
        verbose_name="Campo id para identificar geometrías de la capa",
        max_length=550,
        blank=False,
        null=False
    )

    slider_fields = models.JSONField(
        verbose_name='Campos para cada parte del slider',
        blank=True,
        null=True
    ) 

    field_popup = models.JSONField(
        verbose_name='Campos para desplegar info en el popup',
        blank=True,
        null=True
    )

    category_method = models.CharField(
        verbose_name="Metodo de clasificación",
        max_length=250,
        blank=True,
        null=True,
    )

    field_category = models.IntegerField(
        verbose_name="Número de categorías para gráfica",
        blank=True,
        null=True,
        default=5
    )

    colors = models.CharField(
        verbose_name="Colores de gráfico y tematización",
        max_length=250,
        blank=True,
        null=True
    )

    use_custom_colors = models.BooleanField(
        verbose_name="Usar colores provistos por el cliente",
        blank=False,
        null=False,
        default=False
    )

    custom_colors = models.CharField(
        verbose_name="Colores custom de gráfico y tematización",
        max_length=250,
        blank=True,
        null=True
    )

    plot_config = models.JSONField(
        verbose_name='Configuracion para la gráfica',
        blank=True,
        null=True
    )

    
    plot_values = models.JSONField(
        verbose_name='Valores para la gráfica',
        blank=True,
        null=True
    )


    map_values = models.JSONField(
        verbose_name='Valores para tematización de la capa',
        blank=True,
        null=True
    )

    def __str__(self):
        return self.name


class IndicatorFieldBoxInfo(models.Model):

    indicator = models.ForeignKey(Indicator,
        on_delete=models.CASCADE)

    field = models.CharField(
        verbose_name="Campo de información",
        help_text="Se generará un total de este campo a partir de cada una de las geometrias de la capa",
        max_length=550,
        blank=False,
        null=False
    )

    is_percentage = models.BooleanField(
        verbose_name="Es de porcentaje?",
        help_text="Si se marca esta opción el valor desplegado será un porcentaje",
        default=False
    )

    field_percentage_total = models.CharField(
        verbose_name="Campo total para calcular porcentaje",
        help_text="Este campo se tomará como el total para calcular el porcentaje a desplegar.",
        max_length=550,
        blank=True,
        null=True
    )

    name = models.CharField(
        verbose_name="Nombre del campo",
        max_length=550,
        blank=False,
        null=False
    )

    icon = IconField(
        verbose_name="Icono",
        help_text="Este icono aparecerá en el cuadro de información.",
        blank=False,
        null=False
    )

    icon_custom = models.ImageField(
        verbose_name="Icono personalizado para cuadro de información.",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None
    )

    color = models.CharField(
        verbose_name="Color de fondo del recuadro",
        max_length=550,
        default="#000000",
        blank=False,
        null=False
    )

    size = models.CharField(
        verbose_name="Tamaño de recuadro",
        max_length=40,
        choices=SIZE,
        blank=True,
        null=True,
        default='1'
    )

    edge_style = models.CharField(
        verbose_name="Tipo borde para recuadro",
        max_length=40,
        choices=EDGE,
        blank=True,
        null=True,
        default='8'
    )

    edge_color = models.CharField(
        verbose_name="Color de borde del recuadro",
        max_length=550,
        default="#000000",
        blank=True,
        null=True
    )

    text_color = models.CharField(
        verbose_name="Color de texto del recuadro",
        max_length=550,
        default="#ffffff",
        blank=False,
        null=False
    )

    stack_order = models.IntegerField(
        null=False,
        blank=False,
        default=1
    )

class SiteConfiguration(models.Model):
    site = models.OneToOneField(
        Site,
        on_delete=models.CASCADE
    )
    show_header = models.BooleanField(
        default=True,
        verbose_name="Mostrar encabezado",
        help_text="Si está desmarcado, el encabezado no aparecerá."
    )
    show_footer = models.BooleanField(
        default=True,
        verbose_name="Mostrar pie de página",
        help_text="Si está desmarcado, el footer no aparecerá."
    )


    header_background_color =  models.CharField(
        verbose_name="Color de fondo del encabezado",
        help_text="Este color se aplicará unicamente al fondo del encabezado",
        max_length=40,
        blank=True,
        null=True
    )

    header_text_color = models.CharField(
        verbose_name='Color del texto del encabezado',
        help_text="Este color se aplicará unicamente al texto del encabezado",
        max_length=40,
        blank=True,
        null=True
    )

    header_font_size = models.IntegerField(
        verbose_name="Tamaño de fuente del encabezado (px)",
        blank=True,
        null=True,
        default="28"
    )

    site_font_style = models.CharField(
        verbose_name="Tipo de letra del sitio",
        max_length=40,
        choices=FONTS,
        blank=True,
        null=True,
        default='Times New Roman'
    )
    

    site_text_color = models.CharField(
        verbose_name="Color de texto del footer",
        help_text="Este color se aplicará en el texto del footer",
        max_length=40,
        blank=True,
        null=True
    )

    site_interface_text_color = models.CharField(
        verbose_name="Color de texto de interfaz",
        help_text="Este color se aplicará en el texto del los contenedores",
        max_length=40,
        blank=True,
        null=True
    )

    site_background_color = models.CharField(
        verbose_name="Color de fondo del footer",
        help_text="Este color se aplicará en el texto del footer",
        max_length=40,
        blank=True,
        null=True
    )

    site_interface_background_color = models.CharField(
        verbose_name="Color de fondo del los contenedores",
        help_text="Este color se aplicará en el texto de los contenedores",
        max_length=40,
        blank=True,
        null=True
    )

    site_font_size = models.IntegerField(
        verbose_name="Tamaño de fuente del sitio (px)",
        blank=True,
        null=True,
        default="16"
    )

    indicator_box_title = models.CharField(
        verbose_name="Título del recuadro de selección de indicadores",
        default="Indicador",
        max_length=255,
        blank=True,
        null=True
    )

    