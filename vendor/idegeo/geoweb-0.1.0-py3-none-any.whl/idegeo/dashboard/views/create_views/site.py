from idegeo.dashboard.forms import SiteForm

from idegeo.dashboard.models import Site

from idegeo.dashboard.views.create_views.base import IdegeoCreateView


class CreateSitesView(IdegeoCreateView):
    model = Site
    form_class = SiteForm

    success_url = 'dashboard:sites'
    template_name = 'create/base.html'
    back_button = "dashboard:sites"

    title = "Crear sitio" 
