from django import forms

from idegeo.dashboard.models import IndicatorGroup, Site

from idegeo.dashboard.views.create_views.base import IdegeoCreateView

class GroupCreateForm(forms.ModelForm):

    class Meta:
        model = IndicatorGroup
        fields = [
            'name',
            'description'
        ]


class CreateGroupsView(IdegeoCreateView):
    model = IndicatorGroup
    form_class = GroupCreateForm

    success_url = 'dashboard:groups'
    template_name = 'create/base.html'
    back_button = "dashboard:groups"

    title = "Crear grupo" 

    def get_success_url_args(self):
        return [self.kwargs['pk']]

    def get_back_button_args(self):
        return [self.kwargs['pk']]

    def get_objects(self):
        if not hasattr(self, "site"):
            self.site = Site.objects.get(
                pk=self.kwargs['pk']
            )

    def save_form(self, form):
        created_object = form.save(commit=False)
        created_object.site = self.site
        created_object.save()
        self.created_object_id = created_object.pk
        return created_object

    def get_initial(self):

        return {
            "site": self.site,
        }
    
    def get_context_data(self, *args, **kwargs):
        context = super(CreateGroupsView,self).get_context_data(*args, **kwargs)

        context["site"] = self.site

        return context