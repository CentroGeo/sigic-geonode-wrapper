from idegeo.dashboard.forms import SubGroupForm

from idegeo.dashboard.models import SubGroup
from idegeo.dashboard.models import IndicatorGroup

from idegeo.dashboard.views.create_views.base import IdegeoCreateView


class CreateSubGroupView(IdegeoCreateView):
    model = SubGroup
    form_class = SubGroupForm

    template_name = "create/base.html"
    success_url = "dashboard:subgroups"
    back_button = "dashboard:detail_group"
    
    title = "Crear subgrupo"

    def get_success_url_args(self):
        return [self.kwargs['pk']]

    def get_back_button_args(self):
        return [self.kwargs['pk']]

    def get_objects(self):
        if not hasattr(self, "group"):
            self.group = IndicatorGroup.objects.get(
                pk=self.kwargs['pk']
            )
    
    def save_form(self, form):
        created_object = form.save(commit=False)
        created_object.group = self.group
        created_object.save()
        return created_object

    def get_initial(self):

        return {
            "group": self.group
        }

    def get_context_data(self, *args, **kwargs):
        context = super(CreateSubGroupView,self).get_context_data(*args, **kwargs)

        context["group"] = self.group

        return context