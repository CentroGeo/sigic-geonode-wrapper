from idegeo.dashboard.forms import IndicatorForm

from idegeo.dashboard.models import Indicator, SubGroup, IndicatorGroup, Site

from idegeo.dashboard.views.create_views.base import IdegeoCreateView

class CreateIndicatorView(IdegeoCreateView):
    model = Indicator
    form_class = IndicatorForm

    template_name = "create/base.html"
    success_url = "dashboard:detail_indicator"
    back_button = "dashboard:detail_site"
    
    title = "Crear indicador"

    def get_success_url_args(self):
        return [self.created_object_id]

    def get_back_button_args(self):
        return [self.kwargs['pk']]


    def get_objects(self):
        self.subgroup = None
        self.group = None
        self.site = None

        if "subgroup" in self.kwargs['type']:
                self.subgroup = SubGroup.objects.get(
                    pk=self.kwargs['pk']
                )
                
                self.back_button = "dashboard:detail_subgroup"
        
        elif "group" in self.kwargs['type']:
                self.group = IndicatorGroup.objects.get(
                    pk=self.kwargs['pk']
                )
                self.back_button = "dashboard:detail_group"

        elif "site" in self.kwargs['type']:
                self.site = Site.objects.get(
                    pk=self.kwargs['pk']
                )
                self.back_button = "dashboard:detail_site"
    
    def save_form(self, form):
        created_object = form.save(commit=False)
        if "subgroup" in self.kwargs['type']:
            created_object.subgroup = self.subgroup
            created_object.stack_order = len(self.subgroup.indicator_set.all()) + 1
        elif "group" in self.kwargs['type']:
            created_object.group = self.group
            created_object.stack_order = len(self.group.indicator_set.all()) + 1
        elif "site" in self.kwargs['type']:
            created_object.site = self.site
            created_object.stack_order = len(self.site.indicator_set.all()) + 1
        created_object.save()
        self.created_object_id = created_object.pk
        return created_object

    def get_initial(self):

        return {
            "site": self.site,
            "group": self.group,
            "subgroup": self.subgroup
        }

    def get_context_data(self, *args, **kwargs):
        context = super(CreateIndicatorView,self).get_context_data(*args, **kwargs)

        context["site"] = self.site
        context["group"] = self.group
        context["subgroup"] = self.subgroup

        return context