from django import forms
from django.views.generic.edit import CreateView
from django.views.generic.detail import SingleObjectMixin
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.shortcuts import redirect
from django.urls import reverse

class IdegeoCreateView(CreateView, SingleObjectMixin):
    success_url = 'dashboard:groups'

    title = "Crear" 
    back_button = "dashboard:groups"

    def get_success_url_args(self):
        return []

    def get_back_button_args(self):
        return []

    def get_back_button_url(self):
        return reverse(self.back_button, args=self.get_back_button_args())

    def get_success_url(self):
        return reverse(self.success_url, args=self.get_success_url_args())

    def redirect_on_success(self):

        return redirect(self.get_success_url())
    
    def save_form(self, form):
        created_object = form.save(commit=False)
        created_object.created_by = self.request.user
        created_object.save()
        return created_object

    def form_valid(self, form):
        try:
            self.object = self.save_form(form)
            return self.redirect_on_success()
        except forms.ValidationError as errors:
            for field, error in dict(errors).items():
                try:
                    form.add_error(field, error)
                except:
                    form.add_error(None, '{} ({})'.format(
                        str(error), field))

            return self.form_invalid(form)
    
    def get_objects(self):
        pass

    def post(self, *args, **kwargs):
        self.get_objects()

        return super(IdegeoCreateView,self).post(*args, **kwargs)
    
    def get(self, *args, **kwargs):
        self.get_objects()

        return super(IdegeoCreateView,self).get(*args, **kwargs)

    def get_context_data(self, *args, **kwargs):
        context = super(IdegeoCreateView,self).get_context_data(*args, **kwargs)
        context['title'] = self.title
        context['back_url'] = self.get_back_button_url
        return context
    
    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(IdegeoCreateView, self).dispatch(*args, **kwargs)