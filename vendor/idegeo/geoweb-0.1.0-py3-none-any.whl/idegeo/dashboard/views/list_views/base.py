# -*- encoding: utf-8 -*-
from django.views.generic import ListView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

class IdegeoListView(ListView):
    """
        Vista generica de lista
    """
    paginate_by = 10
    empty_message = "Lista vacía"
    title = "Lista"
    
    
    
    def get_list_item_template(self):
        if hasattr(self, 'list_item_template'):
            return self.list_item_template

        return NotImplementedError('No template for list item was given')
    
    def get_initial_queryset(self):
        if hasattr(self, 'queryset'):
            return self.queryset

        raise NotImplementedError('No initial queryset was provided')
    
    def get_queryset(self):
        queryset = self.get_initial_queryset()
        return queryset
    
    def get_templates(self):
        return {
            'list_item': self.get_list_item_template(),
        }

    def get_context_data(self, **kwargs):
        context = {'object_list': super(IdegeoListView,self).get_context_data(**kwargs)}
        context['empty_message'] = self.empty_message
        context['title'] = self.title
        context['templates'] = self.get_templates()
        context['sort_object_list'] = super(IdegeoListView,self).get_context_data(**kwargs)
        return context
    
    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(IdegeoListView, self).dispatch(*args, **kwargs)