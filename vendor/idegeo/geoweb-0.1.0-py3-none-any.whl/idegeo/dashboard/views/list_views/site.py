# -*- encoding: utf-8 -*-
from idegeo.dashboard.models import Site
from idegeo.dashboard.views.list_views.base import IdegeoListView

class ListSitesView(IdegeoListView):
    """
        Muestra al usuario una lista de los 
        sitios disponibles.
    """

    template_name = "list/site_list.html"

    list_item_template = "list_items/site.html"

    empty_message = "No hay sitios registrados"

    title = "Sitios de indicadores"

    def get_initial_queryset(self):
        return Site.objects.all()

    def get_context_data(self, **kwargs):
        context = {'object_list': super(IdegeoListView,self).get_context_data(**kwargs)}
        context['empty_message'] = self.empty_message
        context['title'] = self.title
        context['templates'] = self.get_templates()
        context['site_url'] = "https://geoweb.centrogeo.org.mx"
        context["model"] = "site"
        return context