# -*- encoding: utf-8 -*-
from idegeo.dashboard.models import SubGroup
from idegeo.dashboard.models import IndicatorGroup

from django.views.generic.detail import SingleObjectMixin

from idegeo.dashboard.views.list_views.base import IdegeoListView

class ListSubGroupView(IdegeoListView, SingleObjectMixin):
    """
        Muestra al usuario una lista de los 
        grupos disponibles.
    """
    paginate_by = 10

    template_name = "list/subgroups_list.html"
    list_item_template = "list_items/subgroup.html"

    empty_message = "No hay subgrupos registrados"

    title = "Lista de subgrupos"


    def get(self, request, *args, **kwargs):
        self.object = self.get_object(queryset=IndicatorGroup.objects.all())
        return super(ListSubGroupView, self).get(request, *args, **kwargs)

    def get_initial_queryset(self):
        return SubGroup.objects.filter(group=self.object).order_by('stack_order')
    
    def get_context_data(self, *args, **kwargs):
        context = super(ListSubGroupView,self).get_context_data(*args, **kwargs)
        context["group"] = self.object
        context["model"] = "subgroups"
        context['sort_object_list'] = SubGroup.objects.filter(group=self.object).order_by('stack_order')
        return context