# -*- encoding: utf-8 -*-
from idegeo.dashboard.models import IndicatorGroup, Site
from idegeo.dashboard.views.list_views.base import IdegeoListView

from django.views.generic.detail import SingleObjectMixin

class ListGroupsView(IdegeoListView, SingleObjectMixin):
    """
        Muestra al usuario una lista de los 
        grupos disponibles.
    """
    paginate_by = 10

    template_name = "list/groups_list.html"

    list_item_template = "list_items/group.html"

    empty_message = "No hay grupos registrados"

    title = "Lista de grupos de indicadores"

    def get(self, request, *args, **kwargs):
        self.object = self.get_object(queryset=Site.objects.all())
        return super(ListGroupsView, self).get(request, *args, **kwargs)

    def get_initial_queryset(self):
        return IndicatorGroup.objects.filter(site=self.object).order_by('stack_order')

    def get_context_data(self, *args, **kwargs):
        context = super(ListGroupsView,self).get_context_data(*args, **kwargs)
        context["site"] = self.object
        context["model"] = "groups"
        context['sort_object_list'] = IndicatorGroup.objects.filter(site=self.object).order_by('stack_order')
        return context