# -*- encoding: utf-8 -*-
from idegeo.dashboard.models import Indicator
from idegeo.dashboard.models import SubGroup, IndicatorGroup, Site

from django.views.generic.detail import SingleObjectMixin

from idegeo.dashboard.views.list_views.base import IdegeoListView

class ListIndicatorView(IdegeoListView, SingleObjectMixin):
    """
        Muestra al usuario una lista de los 
        indicadores disponibles.
    """
    paginate_by = 10

    template_name = "list/indicators_list.html"
    list_item_template = "list_items/indicator.html"

    empty_message = "No hay indicadores registrados"

    title = "Lista de indicadores"

    def get(self, request, *args, **kwargs):
        if "subgroup" in self.kwargs['type']:
            self.object = self.get_object(queryset=SubGroup.objects.all())
        elif "group" in self.kwargs['type']:
            self.object = self.get_object(queryset=IndicatorGroup.objects.all())
        elif "site" in self.kwargs['type']:
            self.object = self.get_object(queryset=Site.objects.all())
        return super(ListIndicatorView, self).get(request, *args, **kwargs)

    def get_initial_queryset(self):
        if "subgroup" in self.kwargs['type']:
            return Indicator.objects.filter(subgroup=self.object).order_by('stack_order')
        if "group" in self.kwargs['type']:
            return Indicator.objects.filter(group=self.object).order_by('stack_order')
        if "site" in self.kwargs['type']:
            return Indicator.objects.filter(site=self.object).order_by('stack_order')
    
    def get_context_data(self, *args, **kwargs):
        context = super(ListIndicatorView,self).get_context_data(*args, **kwargs)
        if "subgroup" in self.kwargs['type']:
            context["subgroup"] = self.object
            context['sort_object_list'] = Indicator.objects.filter(subgroup=self.object).order_by('stack_order')
        elif "group" in self.kwargs['type']:
            context["group"] = self.object
            context['sort_object_list'] = Indicator.objects.filter(group=self.object).order_by('stack_order')
        elif "site" in self.kwargs['type']:
            context["site"] = self.object
            context['sort_object_list'] = Indicator.objects.filter(site=self.object).order_by('stack_order')

        context["model"] = "indicators"
        return context