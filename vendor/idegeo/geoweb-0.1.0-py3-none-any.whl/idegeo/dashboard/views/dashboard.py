import os
from django.shortcuts import render
from idegeo.dashboard.models import Site
import json
from idegeo.dashboard.models import Site, SiteConfiguration

def get_layer_url(layer, request):
        rest_url = 'gwc/service/tms/1.0.0/geonode:'

        return (os.environ.get("GEONODE_API_ROOT","")
                + "geoserver/"
                + rest_url
                + layer.name
                + "@EPSG:900913@pbf/{z}/{x}/{-y}.pbf"
                + (f'?access_token={request.user.oauth_token}' if request.user.is_authenticated else ''))

def filter_layers(layers):
    filteredLayers = []

    for layer in layers:
        found = [l for l in filteredLayers if l[0] == layer[0]]
        
        if len(found) > 0:
            found[0][1].append( layer[1] )
        else:
            filteredLayers.append([layer[0], [layer[1]]])

    return filteredLayers

def site_dashboard(request,url):
    obj = Site.objects.get(url=url)

    siteconfiguration, _ = SiteConfiguration.objects.get_or_create(site=obj)

    layers = []

    if obj.indicatorgroup_set.all():
        for group in obj.indicatorgroup_set.all():
            if group.subgroup_set.all():
                for subgroup in group.subgroup_set.all():
                    if subgroup.indicator_set.all():
                        for i in subgroup.indicator_set.all():
                            if i.plot_values or i.histogram_fields:
                                try:
                                    layers.append([get_layer_url(i.layer, request),i.id])
                                except:
                                    pass
            elif group.indicator_set.all():
                for i in group.indicator_set.all():
                    if i.plot_values or i.histogram_fields:
                        try:
                            layers.append([get_layer_url(i.layer, request),i.id])
                        except:
                            pass
    else:
        for i in obj.indicator_set.all():
            if i.plot_values or i.histogram_fields:
                try:
                    layers.append([get_layer_url(i.layer, request),i.id])
                except:
                    pass
    
    filtered_layers = filter_layers(layers)

    context = {
        "site": obj,  
        "layers": json.dumps(filtered_layers),
        "siteconfiguration": siteconfiguration,  
    }

    return render(request, 'dashboard/base.html', context)
