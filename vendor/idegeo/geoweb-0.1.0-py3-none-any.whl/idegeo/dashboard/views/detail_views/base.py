from django.views.generic import UpdateView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.shortcuts import redirect
from django.db.models import ProtectedError

class IdegeoDetailView(UpdateView):
    success_url = '#'

    delete_redirect_url = 'dashboard:groups'

    title = ""

    def get_update_form_template(self):
        if hasattr(self, 'update_form_template'):
            return self.update_form_template

        raise NotImplementedError('No template for update form was given')

    def get_detail_template(self):
        if hasattr(self, 'detail_template'):
            return self.detail_template

        raise NotImplementedError('No template for detail was given')

    def get_summary_template(self):
        if hasattr(self, 'summary_template'):
            return self.summary_template

        return ''

    def get_delete_redirect_url(self):
        if hasattr(self, 'delete_redirect_url'):
            return self.delete_redirect_url

        raise NotImplementedError('No redirect url was given in case of deletion')

    def get_delete_redirect_url_args(self):
        return []

    def handle_delete(self):
        self.object = self.get_object()

        try:
            redirect_to = self.get_delete_redirect_url()
            redirect_url_args = self.get_delete_redirect_url_args()
            self.object.delete()
            return redirect(redirect_to, *redirect_url_args)
        except ProtectedError:
            return self.protected_redirect()

    def post(self, *args, **kwargs):
        if 'delete' in self.request.GET:
            return self.handle_delete()

        return super(IdegeoDetailView,self).post(*args, **kwargs)

    def get(self, *args, **kwargs):
        self.object = self.get_object()

        return super(IdegeoDetailView,self).get(*args, **kwargs)

    def get_context_data(self, *args, **kwargs):
        context = super(IdegeoDetailView,self).get_context_data(*args, **kwargs)

        context['detail_template'] = self.get_detail_template()
        context['update_form_template'] = self.get_update_form_template()
        context['summary_template'] = self.get_summary_template()
        return context
    
    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(IdegeoDetailView, self).dispatch(*args, **kwargs)