from django.views.generic.detail import SingleObjectMixin
from idegeo.dashboard.forms import GroupForm

from idegeo.dashboard.models import IndicatorGroup

from idegeo.dashboard.views.detail_views.base import IdegeoDetailView


class DetailGroupView(IdegeoDetailView, SingleObjectMixin):
    model = IndicatorGroup
    form_class = GroupForm
    delete_redirect_url = 'dashboard:groups'

    template_name = 'detail/group.html'

    detail_template = 'details/group.html'
    summary_template = 'summaries/group.html'
    update_form_template = 'update/base.html'

    def get_summary_info(self):
        subgroups = self.object.subgroup_set.all()

        return {
            'subgroups': subgroups
        }


    def get_delete_redirect_url_args(self):
        return [self.object.site.pk]

        
    def get(self, *args, **kwargs):
        self.object = self.get_object()

        return super(IdegeoDetailView,self).get(*args, **kwargs)

    def get_context_data(self, *args, **kwargs):
        context = super(DetailGroupView,self).get_context_data(*args, **kwargs)
        context['group'] = self.object
        context['title'] = "Grupo " + self.object.name
        context['summary_info'] = self.get_summary_info()
        context['nav'] = [{"name": "Inicio", 'id': ''},{"name": "Sitio", 'id': self.object.site.id}]
        return context