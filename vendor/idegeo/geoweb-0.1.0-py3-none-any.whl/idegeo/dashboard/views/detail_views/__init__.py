from .group import DetailGroupView
from .indicator import DetailIndicatorView
from .subgroup import DetailSubGroupView
from .site import DetailSiteView

__all__ = [
    "DetailGroupView",
    "DetailIndicatorView",
    "DetailSubGroupView",
    "DetailSiteView"
]