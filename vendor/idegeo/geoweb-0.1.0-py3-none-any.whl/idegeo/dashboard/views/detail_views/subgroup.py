from django.views.generic.detail import SingleObjectMixin
from idegeo.dashboard.forms import SubGroupForm

from idegeo.dashboard.models import SubGroup, IndicatorGroup

from idegeo.dashboard.views.detail_views.base import IdegeoDetailView


class DetailSubGroupView(IdegeoDetailView, SingleObjectMixin):
    model = SubGroup
    form_class = SubGroupForm
    delete_redirect_url = 'dashboard:detail_group'

    template_name = 'detail/subgroup.html'

    detail_template = 'details/subgroup.html'
    summary_template = 'summaries/subgroup.html'
    update_form_template = 'update/base.html'


    def get_delete_redirect_url_args(self):
        return [self.object.group.pk]

        
    def get(self, *args, **kwargs):
        self.object = self.get_object()
        self.group = IndicatorGroup.objects.get(pk=self.object.group.pk)

        return super(IdegeoDetailView,self).get(*args, **kwargs)

    def get_context_data(self, *args, **kwargs):
        context = super(DetailSubGroupView,self).get_context_data(*args, **kwargs)
        context['subgroup'] = self.object
        context['group'] = self.group
        context['title'] = "Subgrupo " + self.object.name
        context['nav'] = [{"name": "Inicio", 'id': ''},{"name": "Sitio", 'id': self.object.group.site.id},{"name":"Grupo", 'id': self.group.id}]
        return context