import os
from django.views.generic.detail import SingleObjectMixin
from idegeo.dashboard.forms import IndicatorFormClone, IndicatorFieldBoxInfoForm, IndicatorFormUpdate

from idegeo.dashboard.models import Indicator, SubGroup, IndicatorGroup, Site

from idegeo.dashboard.views.detail_views.base import IdegeoDetailView


class DetailIndicatorView(IdegeoDetailView, SingleObjectMixin):
    model = Indicator
    form_class = IndicatorFormUpdate
    delete_redirect_url = 'dashboard:detail_site'

    template_name = 'detail/indicator.html'

    detail_template = 'details/indicator.html'
    summary_template = 'summaries/indicator.html'
    update_form_template = 'update/base.html'


    def get_delete_redirect_url_args(self):
        
        if hasattr(self.object.subgroup, 'pk'):
            subgroup_id = self.object.subgroup.pk
            return [subgroup_id]

        if hasattr(self.object.group, 'pk'):
            group_id = self.object.group.pk
            return [group_id]

        if hasattr(self.object.site, 'pk'):
            site_id = self.object.site.pk
            return [site_id]

    def get_delete_redirect_url(self):
        if hasattr(self, 'delete_redirect_url'):
            
            if hasattr(self.object.subgroup, 'pk'):
                self.delete_redirect_url = 'dashboard:detail_subgroup'
                return self.delete_redirect_url

            if hasattr(self.object.group, 'pk'):
                self.delete_redirect_url = 'dashboard:detail_group'
                return self.delete_redirect_url

            if hasattr(self.object.site, 'pk'):
                self.delete_redirect_url = 'dashboard:detail_site'
                return self.delete_redirect_url


        raise NotImplementedError('No redirect url was given in case of deletion')
    
    def get(self, *args, **kwargs):
        self.object = self.get_object()
        if hasattr(self.object.subgroup, 'pk'):
            self.subgroup = SubGroup.objects.get(pk=self.object.subgroup.pk)
            
        if hasattr(self.object.group, 'pk'):
            self.group = IndicatorGroup.objects.get(pk=self.object.group.pk)

        if hasattr(self.object.site, 'pk'):
            self.site = Site.objects.get(pk=self.object.site.pk)


        return super(IdegeoDetailView,self).get(*args, **kwargs)

    def get_layer_url(self):
        rest_url = 'wfs?service=wfs&version=2.0.0&request=GetFeature&typeNames=geonode:'
        format_url = '&outputFormat=application/json&srsName=EPSG:4326'

        return (os.environ.get("GEONODE_API_ROOT","https://geonode.centrogeo.org.mx/")
                + "geoserver/"
                + rest_url
                + self.object.layer.name
                + "&access_token="
                + os.environ.get("GEOSERVER_ACCESS_TOKEN","")
                + format_url)

        
    def get_infobox_update_forms(self):
        
        box_forms = []
        for box in self.object.indicatorfieldboxinfo_set.all():
            box_forms.append({
                "form": IndicatorFieldBoxInfoForm(instance=box,auto_id='databox_%s-'+str(box.id)),
                "field_id": box.id
                })
        return box_forms

    def get_context_data(self, *args, **kwargs):
        context = super(DetailIndicatorView,self).get_context_data(*args, **kwargs)
        context['indicator'] = self.object

        if hasattr(self.object.subgroup, 'pk'):
            context['subgroup'] = self.subgroup
            context['nav'] = [{"name": "Inicio", 'id': ''},{"name": "Sitio", 'id': self.object.subgroup.group.site.id},{"name":"Grupo", 'id': self.object.subgroup.group.id},{"name":"Subgrupo", 'id': self.object.subgroup.id}]
        
        if hasattr(self.object.group, 'pk'):
            context['group'] = self.group
            context['nav'] = [{"name": "Inicio", 'id': ''},{"name": "Sitio", 'id': self.object.group.site.id},{"name":"Grupo", 'id': self.object.group.id}]
            
        if hasattr(self.object.site, 'pk'):
            context['site'] = self.site
            context['nav'] = [{"name": "Inicio", 'id': ''},{"name": "Sitio", 'id': self.object.site.id}]
        
        context['title'] = "Indicador"
        context['layer_url'] = self.get_layer_url()
        context['layer_name'] = self.object.layer.name
        context['update_box_forms'] = self.get_infobox_update_forms()
        context['data_form'] = IndicatorFieldBoxInfoForm(auto_id='databox_%s')
        # clone form
        context['clone_form'] = IndicatorFormClone(instance=self.object,auto_id='clone_%s')        
        
        return context