from django.views.generic.detail import SingleObjectMixin
from idegeo.dashboard.forms import SiteForm, SiteStyleForm, SiteLogosForm

from idegeo.dashboard.models import Site

from idegeo.dashboard.views.detail_views.base import IdegeoDetailView


class DetailSiteView(IdegeoDetailView, SingleObjectMixin):
    model = Site
    form_class = SiteForm
    delete_redirect_url = 'dashboard:sites'

    template_name = 'detail/site.html'

    detail_template = 'details/site.html'
    summary_template = 'summaries/site.html'
    update_form_template = 'update/base.html'

    def get_summary_info(self):
        groups = self.object.indicatorgroup_set.all()
        indicators = self.object.indicator_set.all()

        return {
            'indicators': indicators,
            'groups': groups
        }

    def get_site_styles(self):
        try:
            site_styles = self.object.siteconfiguration
            return SiteStyleForm(instance=site_styles)
        except:
            return SiteStyleForm()

    def get_logos_forms(self):
        
        logos_forms = []
        for logo in self.object.icons.all():
            logos_forms.append({
                "form": SiteLogosForm(instance=logo,auto_id='logo_%s-'+str(logo.id)),
                "field_id": logo.id
                })
        return logos_forms

    def get_context_data(self, *args, **kwargs):
        context = super(DetailSiteView,self).get_context_data(*args, **kwargs)
        context['site'] = self.object
        context['summary_info'] = self.get_summary_info()
        context['site_url'] = "https://geoweb.centrogeo.org.mx"
        context['styles_form'] = self.get_site_styles()
        context['logos_forms'] = self.get_logos_forms()
        context['create_logo'] = SiteLogosForm(auto_id='logo_%s')
        context['title'] = self.object.name
        context['nav'] = [{"name": "Inicio", 'id': ''}]
        return context