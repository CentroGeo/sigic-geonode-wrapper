#-*-encoding:utf-8-*-
from django.core.exceptions import ValidationError

def validate_slug(value):
    if " " in value:
        raise ValidationError(u'%s contiene espacios, el campo url no debe contener ningún espacio' % value)
    
    special_characters = "\"!@#$%^&*()-+?_=,<>/ñáóúíéàèìòùäüöïë\""
    if any(c in special_characters for c in value):
        raise ValidationError(u'%s contiene caracteres especiales, el campo url no debe contener ningún caracter especial como acentos' % value)