from django.contrib import admin
from .models import Site, SiteLogos, IndicatorGroup, SubGroup, Indicator, IndicatorFieldBoxInfo, SiteConfiguration

admin.site.register(Site)
admin.site.register(SiteLogos)
admin.site.register(IndicatorGroup)
admin.site.register(SubGroup)
admin.site.register(Indicator)
admin.site.register(IndicatorFieldBoxInfo)
admin.site.register(SiteConfiguration)