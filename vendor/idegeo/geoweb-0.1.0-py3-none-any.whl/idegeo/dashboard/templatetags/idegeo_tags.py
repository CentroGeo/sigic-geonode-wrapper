from django import template

register = template.Library()

def cut_pagination(range, page=1):
    length = len(range)
    if length < 6:
        return {
            'range': range,
            'pre_ellipsis': False,
            'post_ellipsis': False
        }

    lower_limit = max(0, page - 3)
    upper_limit = min(page + 2, length)

    return {
        'range': range[lower_limit: upper_limit],
        'pre_ellipsis': page > 3,
        'post_ellipsis': length - page > 2
    }

def detail_component(context, detail_template, object):
    context['detail_template'] = detail_template
    context['object'] = object
    return context

def summary_component(context, summary_template, object):
    context['summary_template'] = summary_template
    context['object'] = object
    return context

def delete_component(context, object):
    context['object'] = object
    return context

def delete_specific_component(context, message, id):
    context['message'] = message
    context['id'] = id
    return context

def update_component(context, update_template, form):
    context['update_template'] = update_template
    context['form'] = form
    return context

def create_modal_component(context, create_template, form):
    context['create_template'] = create_template
    context['form'] = form
    return context

def update_custom_modal_component(context, create_template, form, id):
    context['create_template'] = create_template
    context['form'] = form
    context['id'] = id
    return context

def clone_modal_component(context, clone_template, form):
    context['clone_template'] = clone_template
    context['form'] = form
    return context

def create_component(context, create_template, form):
    context['create_template'] = create_template
    context['form'] = form
    return context

def delete_component(context, object):
    context['object'] = object
    return context

def is_histogram(things, histogram):
    return things.filter(is_histogram=histogram)

register.filter('cut_pagination', cut_pagination)
register.filter('is_histogram', is_histogram)
register.inclusion_tag(
    'detail/summary.html',
    takes_context=True)(summary_component)
register.inclusion_tag(
    'detail/detail.html',
    takes_context=True)(detail_component)
register.inclusion_tag(
    'modals/update.html',
    takes_context=True)(update_component)
register.inclusion_tag(
    'modals/create.html',
    takes_context=True)(create_modal_component)
register.inclusion_tag(
    'modals/custom_update.html',
    takes_context=True)(update_custom_modal_component)
register.inclusion_tag(
    'modals/clone_modal.html',
    takes_context=True)(clone_modal_component)
register.inclusion_tag(
    'create/create.html',
    takes_context=True)(create_component)
register.inclusion_tag(
    'modals/delete.html',
    name='delete_component',
    takes_context=True)(delete_component)
register.inclusion_tag(
    'modals/delete_specific.html',
    name='delete_specific_component',
    takes_context=True)(delete_specific_component)