#-*-encoding:utf-8-*-
from django import forms
from .validators import validate_slug
from ckeditor_uploader.widgets import CKEditorUploadingWidget
from idegeo.middleware import UserMiddleware

from idegeo.GeonodeModels.models import Layers
from idegeo.dashboard.models import Indicator, SubGroup,  \
                                     IndicatorGroup, Site, \
                                     IndicatorFieldBoxInfo,\
                                     SiteConfiguration, SiteLogos

class SiteForm(forms.ModelForm):

    url = forms.CharField(
        label="Texto de complementa la url del sitio",
        help_text="Es la url del sitio que completa la liga dashboards/, no debe contener espacios ni caracteres especiales",
        max_length=500,
        validators=[validate_slug])
    
    
    info_text = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'),required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['info_text'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = Site
        fields = [
            'name',
            'info_text',
            'title',
            'subtitle',
            'url'
        ]


class GroupForm(forms.ModelForm):
    info_text = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'),required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['info_text'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = IndicatorGroup
        fields = [
            'name',
            'info_text',
            'description'
        ]
        

class IndicatorForm(forms.ModelForm):
    info_text = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'),required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['info_text'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = Indicator
        fields = [
            "name",
            "is_histogram",
            "info_text",
            "layer"
        ]
    
    def __init__(self, *args, **kwargs):
        super(IndicatorForm, self).__init__(*args, **kwargs)
        self.fields['layer'].queryset = Layers.objects.using('geonode').all()

class IndicatorFormUpdate(forms.ModelForm):
    info_text = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'),required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['info_text'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = Indicator
        fields = [
            "name",
            "info_text",
        ]

class IndicatorFormClone(forms.ModelForm):
    field_one = forms.ChoiceField(
        label="Campo 1"
    )

    field_two = forms.ChoiceField(
        label="Campo 2"
    )

    clone_boxes = forms.BooleanField(
        label="Clonar cuadros de información?"
    )

    class Meta:
        model = Indicator
        fields = [
            "name",
            "field_one",
            "field_two",
            "clone_boxes"
        ]

class SubGroupForm(forms.ModelForm):
    info_text = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'),required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['info_text'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = SubGroup
        fields = [
            "name",
            'info_text',
            "icon",
            "icon_custom"
        ]
        
class IndicatorFieldBoxInfoForm(forms.ModelForm):
    field = forms.ChoiceField(
        label="Campo de información",
        help_text="Se generará un total de este campo a partir de cada una de las geometrias de la capa"
    )

    field_percentage_total = forms.ChoiceField(
        label="Campo total para calcular porcentaje",
        help_text="Este campo se tomará como el total para calcular el porcentaje a desplegar."
    )

    color = forms.CharField(
        label="Color de fondo del recuadro",
        help_text="Da click en el recuadro para cambiar el color",
        widget =  forms.TextInput(attrs={'type': 'color', 'style': 'width: 40px; height: 40px; padding: 5px'})
    )

    edge_color = forms.CharField(
        label="Color de borde",
        help_text="Da click en el recuadro para cambiar el color",
        widget =  forms.TextInput(attrs={'type': 'color', 'style': 'width: 40px; height: 40px; padding: 5px'})
    )

    text_color = forms.CharField(
        label="Color de texto del recuadro",
        help_text="Da click en el recuadro para cambiar el color",
        widget =  forms.TextInput(attrs={'type': 'color', 'style': 'width: 40px; height: 40px; padding: 5px'})
    )
    class Meta:
        model = IndicatorFieldBoxInfo
        fields = [
            "field",
            "is_percentage",
            "field_percentage_total",
            "name",
            "color",
            "icon",
            "icon_custom",
            "size",
            "edge_style",
            "edge_color",
            "text_color"
        ]

class SiteStyleForm(forms.ModelForm):

    class Meta:
        model = SiteConfiguration
        exclude = ["site"]
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['show_header'].label = "Mostrar encabezado"
        self.fields['show_header'].help_text = "Marca esta casilla para encabezado."
        self.fields['show_footer'].label = "Mostrar pie de página"
        self.fields['show_footer'].help_text = "Marca esta casilla para mostrar pie de página."
    
    header_background_color = forms.CharField(
        label="Color de fondo del encabezado",
        help_text="Este color se aplicará unicamente al fondo del encabezado. Da click en el recuadro para cambiar el color",
        widget =  forms.TextInput(attrs={'type': 'color', 'style': 'width: 40px; height: 40px; padding: 5px'})
    )

    
    header_text_color = forms.CharField(
        label="Color del texto del encabezado",
        help_text="Este color se aplicará unicamente al texto del encabezado. Da click en el recuadro para cambiar el color",
        widget =  forms.TextInput(attrs={'type': 'color', 'style': 'width: 40px; height: 40px; padding: 5px'})
    )

    site_text_color = forms.CharField(
        label="Color de texto del footer",
        help_text="Este color se aplicará en el texto del footer. Da click en el recuadro para cambiar el color",
        widget =  forms.TextInput(attrs={'type': 'color', 'style': 'width: 40px; height: 40px; padding: 5px'})
    )

    site_background_color = forms.CharField(
        label="Color de fondo del footer",
        help_text="Este color se aplicará en el fondo del footer. Da click en el recuadro para cambiar el color",
        widget =  forms.TextInput(attrs={'type': 'color', 'style': 'width: 40px; height: 40px; padding: 5px'})
    )

    site_interface_text_color = forms.CharField(
        label="Color de texto del los contenedores",
        help_text="Este color se aplicará en el texto de los contenedores. Da click en el recuadro para cambiar el color",
        widget =  forms.TextInput(attrs={'type': 'color', 'style': 'width: 40px; height: 40px; padding: 5px'})
    )

    site_interface_background_color = forms.CharField(
        label="Color de fondo del los contenedores",
        help_text="Este color se aplicará en el texto de los contenedores. Da click en el recuadro para cambiar el color",
        widget =  forms.TextInput(attrs={'type': 'color', 'style': 'width: 40px; height: 40px; padding: 5px'})
    )
    class Meta:
        model = SiteConfiguration
        exclude = [ "site" ]


class SiteLogosForm(forms.ModelForm):
    class Meta:
        model = SiteLogos
        exclude = [ "site", "stack_order" ]