# -*- encoding: utf-8 -*-
import json
from django.http import JsonResponse
import traceback

from idegeo.dashboard.models import *
from idegeo.dashboard.utils.indicator_utils import get_data_from_db, process_data, assign_color
from django.shortcuts import get_object_or_404

def build_indicator_data(request):
    """
    Recibe una petición ajax con los datos para construir la
    data del indicador.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse con la data del indicador.

    """
    if request.method == "POST":
        data_from_post = json.load(request)
        field_id = data_from_post['fieldId']
        field_one = data_from_post['fieldOne']
        field_two = data_from_post['fieldTwo']
        method = data_from_post['method']
        categories = int(data_from_post['categories'])
        manual_bins = data_from_post['manualBins']
        indicator = Indicator.objects.get(id=data_from_post['indicatorId'])

        # trae la data filtrada de la tabla de atributos
        data = get_data_from_db(
            [field_one,field_two] if field_two else field_one,
            field_id,
            indicator.layer.name
        )

        # procesa la data y regresa un diccionario con los datos
        processed_data = process_data(
            data,
            [field_one,field_two] if field_two else field_one,
            field_id,
            method,
            categories,
            indicator,
            [float(i) for i in manual_bins.split(",")] if method == "manual" else []
        )

        return JsonResponse(processed_data)


def save_indicator_data(request):
    """
    Recibe una petición ajax con los datos para guardar la
    configuración del indicador.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse con la data del indicador
                    en json.

    """
    if request.method == "POST":
        data_from_post = json.load(request)
        indicator = Indicator.objects.get(id=data_from_post['indicatorId'])

        if "histogram_fields" in data_from_post:
            indicator.layer_id_field = data_from_post['fieldId']
            indicator.layer_nom_field = data_from_post['fieldName']
            indicator.high_values_percentage = data_from_post['highValues']
            indicator.histogram_fields = data_from_post['histogram_fields']
            indicator.colors = data_from_post['colors']
            indicator.use_custom_colors = data_from_post['useCustomColor']
            indicator.custom_colors = data_from_post['customColors']
            indicator.plot_config = data_from_post['plotConfig']
            indicator.use_filter = data_from_post['use_filter']
            indicator.show_general_values = data_from_post['general_values']
            indicator.filters = data_from_post['filters']
        else:
            indicator.layer_id_field = data_from_post['fieldId']
            indicator.use_single_field = data_from_post['singleField']
            indicator.field_one = data_from_post['fieldOne']
            indicator.field_two = data_from_post['fieldTwo']
            indicator.field_popup = data_from_post['fieldPopUp']
            indicator.category_method = data_from_post['categoryMethod']
            indicator.field_category = data_from_post['fieldCategory']
            indicator.colors = data_from_post['colors']
            indicator.use_custom_colors = data_from_post['useCustomColor']
            indicator.custom_colors = data_from_post['customColors']
            indicator.plot_values = data_from_post['plotValues']
            indicator.map_values = data_from_post['mapValues']
            indicator.plot_config = data_from_post['plotConfig']
            indicator.use_filter = data_from_post['use_filter']
            indicator.filters = data_from_post['filters']
        
        indicator.save()

        
        return JsonResponse({"indicator": indicator.id})
    
def create_infobox_data(request):
    """
    Recibe una petición ajax con los datos para guardar la
    configuración del recuadro de datos crudos.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse con la data del info box
                    en json.

    """
    if request.method == "POST":
        indicator = Indicator.objects.get(id=request.POST.get('indicatorId'))

        new_obj = IndicatorFieldBoxInfo(
            indicator=indicator,
            color = request.POST.get('color'),
            field = request.POST.get('field'),
            is_percentage = request.POST.get('is_percentage') if request.POST.get('is_percentage') else False,
            field_percentage_total = request.POST.get('field_percentage_total'),
            icon = request.POST.get('icon'),
            icon_custom = request.FILES.get('icon_custom'),
            name = request.POST.get('name'),
            size = request.POST.get('size'),
            edge_style = request.POST.get('edge_style'),
            edge_color = request.POST.get('edge_color'),
            text_color = request.POST.get('text_color')
        )
        
        new_obj.save()

        
        return JsonResponse({"indicator": new_obj.id})


def update_infobox_data(request):
    """
    Recibe una petición ajax con los datos para actualizar la
    configuración del recuadro de datos crudos.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse con la data del info box
                    en json.

    """
    if request.method == "POST":
        infobox = IndicatorFieldBoxInfo.objects.get(id=request.POST.get('id'))

        infobox.color = request.POST.get('color')
        infobox.field = request.POST.get('field')
        infobox.is_percentage = request.POST.get('is_percentage') if request.POST.get('is_percentage') else False
        infobox.field_percentage_total = request.POST.get('field_percentage_total')
        infobox.icon = request.POST.get('icon')
        if request.FILES.get('icon_custom'):
                infobox.icon_custom = request.FILES.get('icon_custom')
        infobox.name = request.POST.get('name')
        infobox.size = request.POST.get('size')
        infobox.edge_style = request.POST.get('edge_style')
        infobox.edge_color = request.POST.get('edge_color')
        infobox.text_color = request.POST.get('text_color')
        
        infobox.save()

        
        return JsonResponse({"indicator": infobox.id})

def save_styles_data(request):
    """
    Recibe una petición ajax con los datos para actualizar o crear
    un nuevo conjunto de estilos para el sitio

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse con la data del info box
                    en json.

    """
    if request.method == "POST":
        data_from_post = json.load(request)

        if "stylesId" in data_from_post:
            obj = SiteConfiguration.objects.get(id=data_from_post['stylesId'])

            obj.show_header = data_from_post.get('show_header', False)
            obj.show_footer = data_from_post.get('show_footer', False)
            obj.header_background_color = data_from_post['header_background_color']
            obj.header_text_color = data_from_post['header_text_color']
            obj.header_font_size = data_from_post['header_font_size']
            obj.site_interface_text_color = data_from_post['site_interface_text_color']
            obj.site_interface_background_color = data_from_post['site_interface_background_color']
            obj.site_font_style = data_from_post['site_font_style']
            obj.site_text_color = data_from_post['site_text_color']
            obj.site_background_color = data_from_post['site_background_color']
            obj.site_font_size = data_from_post['site_font_size']
            obj.indicator_box_title = data_from_post['indicator_box_title']


        
            obj.save()
        
        else:
            site = Site.objects.get(id=data_from_post['id'])
            obj = SiteConfiguration(
                site=site,
                show_header=data_from_post.get('show_header', False),
                show_footer=data_from_post.get('show_footer', False),
                header_background_color = data_from_post['header_background_color'],
                header_text_color = data_from_post['header_text_color'],
                header_font_size = data_from_post['header_font_size'],
                site_interface_text_color = data_from_post['site_interface_text_color'],
                site_interface_background_color = data_from_post['site_interface_background_color'],
                site_font_style = data_from_post['site_font_style'],
                site_text_color = data_from_post['site_text_color'],
                site_background_color = data_from_post['site_background_color'],
                site_font_size = data_from_post['site_font_size'],
                indicator_box_title = data_from_post['indicator_box_title']
            )

            obj.save()

        
        return JsonResponse({"style": obj.id})


def create_or_update_logo(request):
    """
    Recibe una petición ajax con los datos para guardar o
    actualizar un nuevo logo del sitio.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse con la data del info box
                    en json.

    """
    if request.method == "POST":
        try:
            site = Site.objects.get(id=request.POST.get('siteId'))

            obj = SiteLogos(site=site, 
            icon = request.FILES.get('icon'),
            icon_link = request.POST.get('icon_link'),
            stack_order = len(site.icons.all())+1)

            obj.save()
        except:
            obj = SiteLogos.objects.get(id=request.POST.get('id'))

            if request.FILES.get('icon'):
                obj.icon = request.FILES.get('icon')
            obj.icon_link = request.POST.get('icon_link')
        
            obj.save()

        
        return JsonResponse({"logo": obj.id})

def view_indicator_data(request):
    """
    Recibe una petición ajax con los datos para visualizar la
    configuración del indicador.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse con la data del info box
                    en json.

    """
    if request.method == "POST":
        data_from_post = json.load(request)

        try:
            indicator = Indicator.objects.get(id=data_from_post['idIndicator'])

            data = {}
            if indicator.plot_values:
                data["plot_values"] = indicator.plot_values
                data["map_values"] = indicator.map_values
                data["plot_config"] = indicator.plot_config
                data["layer_id_field"] = indicator.layer_id_field
                data["field_popup"] = indicator.field_popup
                data["info_text"] = indicator.info_text
                data["field_one"] = indicator.field_one
                data["use_filter"] = indicator.use_filter
                try:
                    data["filters"] = indicator.filters
                except:
                    data["filters"] = json.loads("{}")
            else:
                data["histogram_fields"] = indicator.histogram_fields
                data["plot_config"] = indicator.plot_config
                data["layer_id_field"] = indicator.layer_id_field
                data["layer_nom_field"] = indicator.layer_nom_field
                data["high_values_percentage"] = indicator.high_values_percentage
                data["custom_colors"] = indicator.custom_colors
                data["info_text"] = indicator.info_text
                data["use_filter"] = indicator.use_filter
                data["show_general_values"] = indicator.show_general_values
                try:
                    data["filters"] = indicator.filters
                except:
                    data["filters"] = json.load("{}")

            boxes = []
            for box in indicator.indicatorfieldboxinfo_set.all():
                info_box = {
                    "id": box.id,
                    "field": box.field,
                    "is_percentage": box.is_percentage,
                    "field_percentage_total": box.field_percentage_total,
                    "name": box.name,
                    "icon": box.icon.as_html(),
                    "icon_custom": box.icon_custom.url,
                    "color": box.color,
                    "size": box.size,
                    "edge_style": box.edge_style,
                    "edge_color": box.edge_color,
                    "text_color": box.text_color,
                    "order": box.stack_order
                }
                boxes.append(info_box)
            
            data["info_boxes"] = boxes

        except Exception as e:
            
            print(traceback.format_exc())
            print(e)
            data = None
        
        return JsonResponse({"data": data})

def select_group_data(request):
    """
    Recibe una petición ajax con los datos para visualizar la
    configuración del indicador.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse con la data del info box
                    en json.

    """
    if request.method == "POST":
        data_from_post = json.load(request)

        group = IndicatorGroup.objects.get(id=data_from_post["idGroup"])

        subgroups = []
        indicators = []
        if group.subgroup_set.all():
            for subgroup in group.subgroup_set.all().order_by('stack_order'):
                if len(subgroup.indicator_set.all()) > 0:
                    temp_dict = {
                        "subgroup_id": subgroup.id,
                        "subgroup_name": subgroup.name,
                        "subgroup_icon": subgroup.icon.as_html(),
                        "icon_custom": subgroup.icon_custom.name,
                        "indicators": []
                    }
                    for indicator in subgroup.indicator_set.all().order_by('stack_order'):
                        if indicator.plot_values or indicator.is_histogram:
                            temp_dict["indicators"].append({
                                "indicator_id": indicator.id,
                                "indicator_name": indicator.name,
                                "is_histogram": indicator.is_histogram
                            })
                    if len(temp_dict["indicators"]) > 0:
                        subgroups.append(temp_dict)

        else:
            for indicator in group.indicator_set.all().order_by('stack_order'):
                if indicator.plot_values or indicator.is_histogram:
                    temp_dict = {
                        "indicator_id": indicator.id,
                        "indicator_name": indicator.name,
                        "is_histogram": indicator.is_histogram
                    }
                    indicators.append(temp_dict)
        
        return JsonResponse({
                "subgroups": subgroups,
                "indicators": indicators,
            })

def save_stack_order_data(request):
    """
    Recibe una petición ajax con los datos para ordenar los elementos de un
    modelo.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse indicando si se hizo correctamente
                    el ordenamiento.

    """
    if request.method == "POST":
        data = json.load(request)
        models_dict = {
            'groups': IndicatorGroup,
            'subgroups': SubGroup,
            'indicators': Indicator,
            'site_logos': SiteLogos,
            'info_box': IndicatorFieldBoxInfo
        } 

        for idx,e in enumerate(data['sort_ids']):
            obj = get_object_or_404(models_dict[data['model']], id=int(e))
            obj.stack_order = idx + 1
            obj.save()

        return JsonResponse({'ok': 'ok'})
    else:
        return JsonResponse({"error": "Not post request"})


def clone_indicator(request):
    """
    Recibe una petición ajax con los datos para clonar un indicador.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse indicando si se hizo correctamente
                    la clonacion.

    """
    if request.method == "POST":
        data_from_post = json.load(request)
        
        ind_to_clone = Indicator.objects.get(id=data_from_post['indicatorId'])

        field_id = ind_to_clone.layer_id_field
        field_one = data_from_post['field_one']
        field_two = data_from_post['field_two']
        method = ind_to_clone.category_method
        categories = ind_to_clone.field_category

        # trae la data filtrada de la tabla de atributos
        data = get_data_from_db(
            [field_one,field_two] if not ind_to_clone.use_single_field else field_one,
            field_id,
            ind_to_clone.layer.name
        )

        # procesa la data y regresa un diccionario con los datos
        processed_data = process_data(
            data,
            [field_one,field_two] if not ind_to_clone.use_single_field else field_one,
            field_id,
            method,
            categories,
            ind_to_clone,
            []
        )

        if len(ind_to_clone.custom_colors) > 0:
            color_data = assign_color(processed_data,ind_to_clone.colors,ind_to_clone.custom_colors.split(","))
        else:
            color_data = assign_color(processed_data,ind_to_clone.colors)

        stack_order = 0
        if ind_to_clone.subgroup:
            stack_order = len(ind_to_clone.subgroup.indicator_set.all()) + 1
        elif ind_to_clone.group:
            stack_order = len(ind_to_clone.group.indicator_set.all()) + 1
        elif ind_to_clone.site:
            stack_order = len(ind_to_clone.site.indicator_set.all()) + 1

        new_obj = Indicator(
            subgroup=ind_to_clone.subgroup,
            group=ind_to_clone.group,
            site=ind_to_clone.site,
            name=data_from_post['name'] if data_from_post['name'] != ind_to_clone.name else ind_to_clone.name + " clon " + str(stack_order),
            plot_type=ind_to_clone.plot_type,
            info_text=ind_to_clone.info_text,
            layer=ind_to_clone.layer,
            layer_id_field=ind_to_clone.layer_id_field,
            use_single_field=ind_to_clone.use_single_field,
            is_histogram=ind_to_clone.is_histogram,
            histogram_fields=ind_to_clone.histogram_fields,
            field_one=data_from_post['field_one'],
            field_two=data_from_post['field_two'],
            field_popup=ind_to_clone.field_popup,
            category_method=ind_to_clone.category_method,
            field_category=ind_to_clone.field_category,
            colors=ind_to_clone.colors,
            use_custom_colors=ind_to_clone.use_custom_colors,
            custom_colors=ind_to_clone.custom_colors,
            use_filter=ind_to_clone.use_filter,
            filters=ind_to_clone.filters,
            plot_config=ind_to_clone.plot_config,
            plot_values=color_data["plot_data"],
            map_values=color_data["theming_data"],
            stack_order=stack_order
        )

        new_obj.save()

        if "clone_boxes" in data_from_post:
            for box_info in ind_to_clone.indicatorfieldboxinfo_set.all():
                new_box = IndicatorFieldBoxInfo(
                    indicator=new_obj,
                    field = box_info.field,
                    is_percentage = box_info.is_percentage,
                    field_percentage_total = box_info.field_percentage_total,
                    name = box_info.name,
                    icon = box_info.icon,
                    icon_custom = box_info.icon_custom,
                    color = box_info.color,
                    size = box_info.size,
                    edge_style = box_info.edge_style,
                    edge_color = box_info.edge_color,
                    text_color = box_info.text_color,
                    stack_order = box_info.stack_order
                )
                new_box.save()


        return JsonResponse({'ind_clone': new_obj.id})
    else:
        return JsonResponse({"error": "Not post request"})


def delete_logo(request):
    """
    Recibe una petición ajax con el id para eliminar un logo.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse indicando si se elimino
                    correctamente el logo.

    """
    if request.method == "POST":
        data = json.load(request)

        logo = SiteLogos.objects.get(id=data['id'])

        logo.delete()

        return JsonResponse({'ok': 'ok'})
    else:
        return JsonResponse({"error": "Not post request"})

def delete_infobox(request):
    """
    Recibe una petición ajax con el id para eliminar un logo.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse indicando si se elimino
                    correctamente el logo.

    """
    if request.method == "POST":
        data = json.load(request)

        logo = IndicatorFieldBoxInfo.objects.get(id=data['id'])

        logo.delete()

        return JsonResponse({'ok': 'ok'})
    else:
        return JsonResponse({"error": "Not post request"})

def get_indicators_data(request):
    """
    Recibe una petición ajax con los ids de los indicadores a rergesar.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse con la data de los indicadores.

    """

    if request.method == "POST":
        data_from_post = json.load(request)

        try:
            
            data = {}

            for i in data_from_post["indicatorIds"]:

                indicator = Indicator.objects.get(id=i)
                data[i] = {
                    "name": indicator.name,
                    "histogram_fields": indicator.histogram_fields,
                    "plot_config": indicator.plot_config,
                    "layer_id_field": indicator.layer_id_field,
                    "custom_colors": indicator.custom_colors,
                    "info_text": indicator.info_text
                }

        except:
            data = None
        
        return JsonResponse({
                "data": data
            })

def get_info_data(request):
    """
    Recibe una petición ajax con los ids del sitio, grupo, subgrupo.

    Params:
        request (object):   El objeto request que contiene los datos
                            de la petición.

    Return:
        (object):   Un objecto JsonResponse con la data info de los objetos.

    """
    if request.method == "POST":
        data_from_post = json.load(request)

        try:
            data = ''

            if data_from_post["type"] == 'site':
                site = Site.objects.get(id=data_from_post["id"])

                if site.info_text:
                    data = site.info_text
                else:
                    data = "No hay información"
            
            elif data_from_post["type"] == 'group':
                group = IndicatorGroup.objects.get(id=data_from_post["id"])

                if group.info_text:
                    data = group.info_text
                elif group.site.info_text:
                    data = group.site.info_text
                else:
                    data = "No hay información"

            elif data_from_post["type"] == 'subgroup':
                subgroup = SubGroup.objects.get(id=data_from_post["id"])

                if subgroup.info_text:
                    data = subgroup.info_text
                elif subgroup.group.info_text:
                    data = subgroup.group.info_text
                elif subgroup.group.site.info_text:
                    data = subgroup.group.site.info_text
                else:
                    data = "No hay información"

        except:
            data = None
        
        return JsonResponse({
                "info": data
            })

