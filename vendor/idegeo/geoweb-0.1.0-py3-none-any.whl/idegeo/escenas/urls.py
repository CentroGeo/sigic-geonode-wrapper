from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='escenas_index'),
    path('escenarios/', views.index_escenarios, name='escenas_escenarios'),
    path('escenarios/publicos/', views.index_escenarios, name='escenas_escenarios_publicos'),
    path('escenario/<slug:slug>/', views.index_escenas, name='escenas_del_escenario'),
    path('escenas/', views.index_escenas, name='escenas_lista'),
    path('escenas/publicas/', views.index_escenas, name='escenas_publicas'),
    path('viewer/<int:scenario_id>/', views.viewer_escenario, name='escenas_viewer'),
]