from ninja import ModelSchema, Schema
from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import Field
from idegeo.escenas.models import Scenario, Scene  # Import the actual models

class SceneSchemaBasic(Schema):
    id: str
    name: str
    stack_order: int

class ScenesLayoutStylesSchema(Schema):
    text_panel: int = 50
    map_panel: int = 50
    timeline_position: str = "bottom" # "top" || "bottom" || "right" || "left"
    primary_color: Optional[str] = "#9333EA"
    secondary_color: Optional[str] = "#E755F7"

class ScenarioSchema(ModelSchema):
    scenes: Optional[List[SceneSchemaBasic]] = None
    
    class Meta:
        model = Scenario
        fields = [
            'id',
            'name',
            'created_at',
            'user',
            'url_id',
            'is_public',
            'description',
            'card_image',
            'scenes_layout_styles'
        ]
    
    @staticmethod
    def resolve_scenes(obj):
        scenes = Scene.objects.filter(scenario=obj).order_by('stack_order')
        return [SceneSchemaBasic(
            id=str(scene.id),
            name=scene.name,
            stack_order=scene.stack_order
        ) for scene in scenes]
    
    @staticmethod
    def resolve_scenes_layout_styles(obj):
        if obj.scenes_layout_styles:
            return ScenesLayoutStylesSchema(**obj.scenes_layout_styles)
        return ScenesLayoutStylesSchema()

class InputCreateScenarioSchema(Schema):
    name: str = Field(..., min_length=1, max_length=256)
    url_id: Optional[str] = None
    is_public: bool = False
    description: Optional[str] = None
    scenes_layout_styles: Optional[Dict[str, Any]] = Field(
        default={
            'text_panel': 50,
            'map_panel': 50,
            'timeline_position': 'bottom',
            'primary_color': '#9333EA',
            'secondary_color': '#E755F7'
        }
    )

class InputUpdateScenarioSchema(Schema):
    name: Optional[str] = Field(None, min_length=1, max_length=256)
    url_id: Optional[str] = None
    is_public: Optional[bool] = None
    description: Optional[str] = None
    scenes_layout_styles: Optional[Dict[str, Any]] = None

class InputUpdateScenarioOrderSchema(Schema):
    id: str
    stack_order: int