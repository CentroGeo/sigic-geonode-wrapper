from uuid import UUID
from typing import Optional, List, Dict, Any
from ninja import ModelSchema, Schema
from pydantic import Field
from decimal import Decimal
from idegeo.escenas.models import Layer, SceneMarker

# ============= LAYER SCHEMAS =============

class LayerSchema(ModelSchema):
    class Meta:
        model = Layer
        fields = [
            'id',
            'geonode_id',
            'name',
            'style',
            'style_title',
            'visible',
            'opacity',
            'stack_order',
            'scene'
        ]

class InputCreateLayerSchema(ModelSchema):
    scene: int = Field(..., description="ID de la escena")
    geonode_id: Optional[int] = Field(None, description="ID de la capa en GeoNode")
    
    class Meta:
        model = Layer
        fields = [
            'name',
            'style',
            'style_title',
            'visible',
            'opacity',
            'stack_order'
        ]

class InputUpdateLayerSchema(Schema):
    name: Optional[str] = None
    visible: Optional[bool] = None
    opacity: Optional[float] = None
    stack_order: Optional[int] = None
    geonode_id: Optional[int] = None

class InputUpdateLayerStyleSchema(Schema):
    style: Optional[str] = None
    style_title: Optional[str] = None

class InputDeleteLayerSchema(Schema):
    id: int

class LayerReorderItem(Schema):
    id: int
    stack_order: int