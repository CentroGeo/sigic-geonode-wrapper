from ninja import Schema, ModelSchema
from typing import Optional
from idegeo.escenas.models import SceneMarker

class SceneMarkerSchema(ModelSchema):
    class Meta:
        model = SceneMarker
        fields = [
            'id', 
            'lat', 
            'lng', 
            'title', 
            'content', 
            'icon', 
            'color',
            'image_url', 
            'options', 
            'scene'
        ]

class InputCreateMarkerSchema(ModelSchema):
    scene: int
    
    class Meta:
        model = SceneMarker
        fields = ['lat', 'lng', 'title', 'content', 'icon', 'color', 'image_url', 'options']

class InputUpdateMarkerSchema(Schema):
    lat: Optional[float] = None
    lng: Optional[float] = None
    title: Optional[str] = None
    content: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    image_url: Optional[str] = None
    options: Optional[dict] = None

class InputDeleteMarkerSchema(Schema):
    id: int