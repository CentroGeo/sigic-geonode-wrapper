from ninja import ModelSchema, Schema
from typing import Optional, List
from pydantic import Field
from idegeo.escenas.models import Scene
from .layer import LayerSchema
from .marker import SceneMarkerSchema

class SceneSchema(ModelSchema):
    layers: List[LayerSchema] = []
    markers: List[SceneMarkerSchema] = []
    
    class Meta:
        model = Scene
        fields = ['id', 'name', 'map_center_lat', 'map_center_long', 'zoom', 
                  'text_position', 'text_content', 'styles', 'stack_order', 'scenario']
    
    @staticmethod
    def resolve_layers(obj):
        return list(obj.layers.all().order_by('stack_order'))
    
    @staticmethod
    def resolve_markers(obj):
        return list(obj.markers.all())

class InputCreateSceneSchema(ModelSchema):
    scenario: int = Field(..., description="ID del escenario")
    
    class Meta:
        model = Scene
        fields = ['name', 'map_center_lat', 'map_center_long', 'zoom', 
                  'text_position', 'text_content', 'styles']

class InputUpdateSceneSchema(Schema):
    name: Optional[str] = None
    map_center_lat: Optional[float] = None
    map_center_long: Optional[float] = None
    zoom: Optional[int] = None
    text_position: Optional[str] = None
    text_content: Optional[str] = None
    styles: Optional[dict] = None

class InputUpdateSceneOrderSchema(Schema):
    id: int
    stack_order: int