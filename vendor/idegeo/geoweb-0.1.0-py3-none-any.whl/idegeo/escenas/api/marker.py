from typing import List
from ninja import Router
from django.shortcuts import get_object_or_404
from django.http import HttpResponse

from idegeo.escenas.models import (SceneMarker, Scene)
from idegeo.escenas.schema import (
    SceneMarkerSchema,
    InputCreateMarkerSchema,
    InputUpdateMarkerSchema,
    InputDeleteMarkerSchema
)
import logging

logger = logging.getLogger(__name__)
router = Router(tags=["Scene Markers"])

# Obtener un marcador específico
@router.get('/{marker_id}', response=SceneMarkerSchema)
def get_marker(request, marker_id: int):
    obj = get_object_or_404(SceneMarker, id=marker_id)

    scenario = obj.scene.scenario
    if not scenario.is_public and scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    return obj

# Listar todos los marcadores de una capa
@router.get('/scene/{scene_id}', response=List[SceneMarkerSchema])
def get_markers_by_scene(request, scene_id: int):
    scene = get_object_or_404(Scene, id=scene_id)

    if not scene.scenario.is_public and scene.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    return list(SceneMarker.objects.filter(scene=scene))

# Crear un marcador
@router.post('/add/', response=SceneMarkerSchema)
def create_marker(request, payload: InputCreateMarkerSchema):
    scene = get_object_or_404(Scene, id=payload.scene)

    if scene.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    marker_data = payload.dict()
    marker_data['scene'] = scene

    marker = SceneMarker.objects.create(**marker_data)
    return marker

# Crear múltiples marcadores
@router.post('/bulk/add/{scene_id}', response=List[SceneMarkerSchema])
def create_bulk_markers(request, scene_id: int, payload: List[InputCreateMarkerSchema]):
    scene = get_object_or_404(Scene, id=scene_id)

    if scene.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    markers = []
    for marker_data in payload:
        marker = SceneMarker.objects.create(**marker_data.dict())
        markers.append(marker)

    return markers

# Actualizar un marcador
@router.put('/update/{marker_id}', response=SceneMarkerSchema)
def update_marker(request, marker_id: int, payload: InputUpdateMarkerSchema):
    marker = get_object_or_404(SceneMarker, id=marker_id)
    scene = marker.scene

    if scene.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    for attr, value in payload.dict(exclude_unset=True).items():
        setattr(marker, attr, value)

    marker.save()
    return marker

# Eliminar un marcador
@router.delete("/delete/{marker_id}")
def delete_marker(request, marker_id: int):
    logger.info(f"DELETE marker {marker_id}")

    try:
        marker = SceneMarker.objects.get(id=marker_id)
    except SceneMarker.DoesNotExist:
        logger.error(f"Marker {marker_id} not found in database")
        return HttpResponse(f"Marcador {marker_id} no encontrado", status=404)

    scene = marker.scene

    # Verificar permisos
    if scene.scenario.user != request.user and not request.user.is_superuser:
        logger.warning(f"Unauthorized delete of marker {marker_id}")
        return HttpResponse("No autorizado para eliminar este marcador", status=403)

    # Eliminar
    marker.delete()
    logger.info(f"Deleted marker {marker_id}")

    return {"success": True}

# Eliminar múltiples marcadores
@router.delete("/bulk/delete/{scene_id}")
def bulk_delete_markers(request, scene_id: int, marker_ids: List[InputDeleteMarkerSchema]):
    scene = get_object_or_404(Scene, id=scene_id)

    if scene.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    deleted_count = SceneMarker.objects.filter(
        id__in=marker_ids,
        scene=scene
    ).delete()[0]

    return {"success": True, "deleted_count": deleted_count}