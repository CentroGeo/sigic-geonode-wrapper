import json
from typing import List
from ninja import Router
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404

from idegeo.escenas.models import (Scene, Scenario, Layer)
from idegeo.escenas.schema import (
    SceneSchema,
    LayerSchema,
    InputCreateSceneSchema,
    InputUpdateSceneSchema,
    InputUpdateSceneOrderSchema
)

router = Router(tags=["Scenes"])

@router.get('/{scene_id}', response=SceneSchema)
def get_scene(request, scene_id: int):
    obj = get_object_or_404(Scene, id=scene_id)

    scenario = obj.scenario
    if not scenario.is_public and scenario.owner != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    return obj

@router.get('/{scenario_id}/scenes/', response=List[SceneSchema], auth=None)
def list_scenes(request, scenario_id: int):
    scenario = get_object_or_404(Scenario, id=scenario_id)

    # Verificar permisos
    if not scenario.is_public:
        if not request.user.is_authenticated:
            return JsonResponse({"detail": "Este escenario es privado"}, status=403)
        if scenario.user != request.user and not request.user.is_superuser:
            return JsonResponse({"detail": "No autorizado"}, status=403)

    # Simplemente filtrar por escenario
    queryset = Scene.objects.filter(scenario=scenario)
    return list(queryset.order_by("stack_order"))

@router.post('/add/', response=SceneSchema)
def create_scene(request, payload: InputCreateSceneSchema):
    payload_dict = payload.dict()
    scenario_id = payload_dict.pop('scenario')
    scenario_obj = get_object_or_404(Scenario, id=scenario_id)

    if scenario_obj.owner != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    obj = Scene(**payload_dict, scenario=scenario_obj)

    obj.save()
    return obj

@router.post('/bulk/reorder')
def reorder_scenes(request, payload: List[InputUpdateSceneOrderSchema]):

    if not payload:
        return {"success": False, "message": "No scenes provided"}

    # Verificar permisos en la primera escena
    first_scene = get_object_or_404(Scene, id=payload[0].id)
    if first_scene.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    updated_count = 0
    for item in payload:
        try:
            scene = Scene.objects.get(id=item.id)
            scene.stack_order = item.stack_order
            scene.save()
            updated_count += 1
        except Scene.DoesNotExist:
            continue

    return {"success": True, "updated_count": updated_count}

@router.put('/update/{scene_id}', response=SceneSchema)
def update_scene(request, scene_id:int, payload: InputUpdateSceneSchema):
    obj = get_object_or_404(Scene, id=scene_id)

    if obj.scenario.owner != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    for attr, value in payload.dict(exclude_unset=True).items():
        setattr(obj, attr, value)

    obj.save()
    return obj

@router.delete('/delete/{scene_id}')
def delete_scene(request, scene_id: int):
    obj = get_object_or_404(Scene, id=scene_id)

    if obj.scenario.owner != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    obj.delete()
    return {"success": True}

# related layer to a scene
@router.get('/{scene_id}/layers', response=List[LayerSchema])
def list_layers(request, scene_id: int):
    scene = get_object_or_404(Scene, id=scene_id)

    if not scene.scenario.is_public and scene.scenario.owner != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    queryset = Layer.objects.filter(scene__id=scene_id)
    return list(queryset)