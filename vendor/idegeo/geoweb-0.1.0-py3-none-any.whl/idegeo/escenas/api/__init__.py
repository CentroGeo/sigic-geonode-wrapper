from .scenario import router
from .scene import router as scene_router
from .scene_layer import router as layer_router
from .marker import router as marker_router
from .upload import router as upload_router


'''
Cadena de Permisos:
Marker → Layer → Scene → Scenario → Owner
  ↓       ↓       ↓         ↓         ↓
Marcador Capa  Escena  Escenario  Usuario
'''

# Mantener la estructura jerárquica original
router.add_router("/scenes/", scene_router)
router.add_router("/layers/", layer_router)
router.add_router("/markers/", marker_router)
router.add_router("/upload", upload_router)