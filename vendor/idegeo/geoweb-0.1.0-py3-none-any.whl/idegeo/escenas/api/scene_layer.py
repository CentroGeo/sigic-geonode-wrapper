from typing import List
from ninja import Router
from django.shortcuts import get_object_or_404
from django.http import HttpResponse

from idegeo.escenas.models import Scene, Layer
from idegeo.escenas.schema import (
    LayerSchema,
    LayerReorderItem,
    InputCreateLayerSchema,
    InputUpdateLayerSchema,
    InputUpdateLayerStyleSchema,
    InputDeleteLayerSchema
)

router = Router(tags=["Scene Layers"])

# Obtener una capa específica de una escena
@router.get('/{layer_id}', response=LayerSchema)
def get_scene_layer(request, layer_id: int):
    obj = get_object_or_404(Layer, id=layer_id)

    scenario = obj.scene.scenario
    if not scenario.is_public and scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    return obj

# Listar todas las capas de una escena
@router.get('/scene/{scene_id}', response=List[LayerSchema])
def list_scene_layers(request, scene_id: int):
    scene = get_object_or_404(Scene, id=scene_id)

    if not scene.scenario.is_public and scene.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    return list(scene.layers.all().order_by('stack_order'))

# Crear una capa para una escena
@router.post('/add/', response=LayerSchema)
def create_scene_layer(request, payload: InputCreateLayerSchema):
    payload_dict = payload.dict()
    scene_id = payload_dict.pop('scene')
    scene_obj = get_object_or_404(Scene, id=scene_id)

    if scene_obj.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    obj = Layer(**payload_dict, scene=scene_obj)
    obj.save()
    return obj

# Crear múltiples capas para una escena
@router.post('/bulk/add/{scene_id}', response=List[LayerSchema])
def create_bulk_scene_layers(request, scene_id: int, payload: List[InputCreateLayerSchema]):
    scene_obj = get_object_or_404(Scene, id=scene_id)

    if scene_obj.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    created_layers = []
    for item in payload:
        item_dict = item.dict()
        item_dict.pop('scene', None)  # Remover scene del dict si existe
        obj = Layer(**item_dict, scene=scene_obj)
        obj.save()
        created_layers.append(obj)

    return created_layers

# Actualizar una capa
@router.put('/update/{layer_id}', response=LayerSchema)
def update_scene_layer(request, layer_id: int, payload: InputUpdateLayerSchema):
    obj = get_object_or_404(Layer, id=layer_id)

    if obj.scene.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    for attr, value in payload.dict(exclude_unset=True).items():
        setattr(obj, attr, value)

    obj.save()
    return obj

# Modificar orden de capas
@router.post('/bulk/reorder')
def reorder_layers(request, payload: List[LayerReorderItem]):
    if not payload:
        return {"success": False, "message": "No layers provided"}

    # Verificar permisos en la primera capa
    first_layer = get_object_or_404(Layer, id=payload[0].id)
    if first_layer.scene.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    updated_count = 0
    for item in payload:
        try:
            layer = Layer.objects.get(id=item.id)
            layer.stack_order = item.stack_order
            layer.save()
            updated_count += 1
        except Layer.DoesNotExist:
            continue

    return {"success": True, "updated_count": updated_count}

# Actualizar estilo de capa
@router.put('/update/style/{layer_id}', response=LayerSchema)
def update_layer_style(request, layer_id: int, payload: InputUpdateLayerStyleSchema):
    obj = get_object_or_404(Layer, id=layer_id)

    if obj.scene.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    for attr, value in payload.dict(exclude_unset=True).items():
        setattr(obj, attr, value)

    obj.save()
    return obj

# Eliminar una capa
@router.delete("/delete/{layer_id}")
def delete_scene_layer(request, layer_id: int):
    obj = get_object_or_404(Layer, id=layer_id)

    if obj.scene.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    obj.delete()
    return {"success": True}

# Eliminar múltiples capas
@router.delete("/bulk/delete/{scene_id}")
def bulk_delete_scene_layers(request, scene_id: int, payload: List[InputDeleteLayerSchema]):
    scene_obj = get_object_or_404(Scene, id=scene_id)

    if scene_obj.scenario.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    deleted_count = 0
    errors = []

    for item in payload:
        try:
            layer_id = item.id
            obj = Layer.objects.get(id=layer_id)

            if obj.scene.id != scene_obj.id:
                errors.append(f"Layer {layer_id} no pertenece a esta escena")
                continue

            obj.delete()
            deleted_count += 1

        except Layer.DoesNotExist:
            errors.append(f"Layer {layer_id} no existe")
        except Exception as e:
            errors.append(f"Error eliminando layer: {str(e)}")

    if errors:
        import logging
        logger = logging.getLogger(__name__)
        logger.warning(f"Errores en bulk delete: {errors}")

    return {"success": True, "deleted_count": deleted_count, "errors": errors}