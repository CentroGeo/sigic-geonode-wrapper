# idegeo/escenas/api/upload.py
from ninja import Router, File
from ninja.files import UploadedFile
from django.http import JsonResponse
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from PIL import Image
import io
import os
import uuid
import datetime

router = Router(tags=["Uploads"])

# Configuración
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5 MB
MAX_IMAGE_DIMENSION = 2048  # pixels
ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'gif', 'webp']

@router.post('/image')
def upload_image(request, upload: UploadedFile = File(...)):
    # Verificar autenticación
    if not request.user.is_authenticated:
        return JsonResponse({
            "error": {
                "message": "Debes iniciar sesión para subir imágenes"
            }
        }, status=403)
    
    # Validar tamaño del archivo
    if upload.size > MAX_FILE_SIZE:
        return JsonResponse({
            "error": {
                "message": f"El archivo es demasiado grande. Máximo {MAX_FILE_SIZE // 1024 // 1024}MB"
            }
        }, status=400)
    
    # Validar extensión
    file_extension = upload.name.split('.')[-1].lower()
    if file_extension not in ALLOWED_EXTENSIONS:
        return JsonResponse({
            "error": {
                "message": f"Formato no permitido. Usa: {', '.join(ALLOWED_EXTENSIONS)}"
            }
        }, status=400)
    
    try:
        # Abrir y validar imagen
        image = Image.open(upload.file)
        
        # Verificar que es una imagen válida
        image.verify()
        
        # Reabrir para procesamiento (verify() cierra el archivo)
        upload.file.seek(0)
        image = Image.open(upload.file)
        
        # Redimensionar si es muy grande
        if image.width > MAX_IMAGE_DIMENSION or image.height > MAX_IMAGE_DIMENSION:
            image.thumbnail(
                (MAX_IMAGE_DIMENSION, MAX_IMAGE_DIMENSION), 
                Image.Resampling.LANCZOS
            )
            
            # Guardar imagen redimensionada en memoria
            output = io.BytesIO()
            
            # Convertir RGBA a RGB si es necesario (para JPEG)
            if image.mode == 'RGBA' and file_extension in ['jpg', 'jpeg']:
                rgb_image = Image.new('RGB', image.size, (255, 255, 255))
                rgb_image.paste(image, mask=image.split()[3])
                image = rgb_image
            
            # Guardar con calidad optimizada
            format_name = 'JPEG' if file_extension in ['jpg', 'jpeg'] else file_extension.upper()
            image.save(output, format=format_name, quality=85, optimize=True)
            output.seek(0)
            
            # Usar el BytesIO como archivo
            upload.file = output
        else:
            # Si no se redimensionó, volver al inicio del archivo
            upload.file.seek(0)

        # CREAR SUBCARPETA POR FECHA
        today = datetime.date.today()
        subfolder = f"{today.year}/{today.month:02d}"
        
        # GENERAR NOMBRE ÚNICO
        unique_filename = f"{subfolder}/{uuid.uuid4().hex[:8]}_{upload.name}"
        
        # USAR FileSystemStorage CON TU MEDIA_ROOT
        fs = FileSystemStorage()
        
        # Guardar archivo (se guardará automáticamente en settings.MEDIA_ROOT)
        filename = fs.save(unique_filename, upload.file)
        
        # CONSTRUIR URL COMPLETA
        file_url = request.build_absolute_uri(
            os.path.join(settings.MEDIA_URL, filename)
        )
        
        # Retornar respuesta en formato CKEditor
        return JsonResponse({
            'url': file_url
        })
        
    except Exception as e:
        return JsonResponse({
            "error": {
                "message": f"Error al procesar la imagen: {str(e)}"
            }
        }, status=400)