from uuid import UUID
from typing import List, Optional
from ninja import Router, UploadedFile, File, Form
from ninja.pagination import paginate, PageNumberPagination
from ninja.security import django_auth
from django.http import HttpResponse
from django.shortcuts import get_object_or_404

from idegeo.escenas.models import Scenario
from idegeo.escenas.models import Scene
from idegeo.escenas.schema import(
    ScenarioSchema,
    SceneSchema,
    InputCreateScenarioSchema,
    InputUpdateScenarioSchema,
    InputUpdateScenarioOrderSchema
)

router = Router(tags=["Scenarios"])

@router.get('/', response=List[ScenarioSchema], auth=None)
@paginate(PageNumberPagination, page_size=10)
def list_scenarios(
    request,
    user: Optional[str] = None,
    is_public: Optional[bool] = None
):
    queryset = Scenario.objects.select_related("user").order_by("-created_at")

    # Si el usuario NO está autenticado, mostrar solo públicos
    if not request.user.is_authenticated:
        queryset = queryset.filter(is_public=True)
    else:
        # Si está autenticado, mostrar públicos O los suyos propios
        from django.db.models import Q
        queryset = queryset.filter(
            Q(is_public=True) | Q(user=request.user)
        )
    
    # Filtros adicionales opcionales
    if user:
        queryset = queryset.filter(user__id=user)
    
    if is_public is not None:
        queryset = queryset.filter(is_public=is_public)
    
    return list(queryset)

@router.get('/{scenario_id}', response=ScenarioSchema, auth=None)
def get_scenario(request, scenario_id:str):
    obj = get_object_or_404(Scenario, id=scenario_id)

    if not obj.is_public:
        if not request.user.is_authenticated:
            return HttpResponse("Este escenario es privado. Inicia sesión para verlo.", status=403)

        if obj.user != request.user and not request.user.is_superuser:
            return HttpResponse("No tienes permiso para ver este escenario.", status=403)

    return obj

@router.post('/add/', response=ScenarioSchema, auth=django_auth)
def create_scenario(request, payload: InputCreateScenarioSchema):

    payload_dict = payload.dict()

    # Valores por defecto si scenes_layout_styles no está definido.
    if 'scenes_layout_styles' not in payload_dict or not payload_dict['scenes_layout_styles']:
        payload_dict['scenes_layout_styles'] = {
            'text_panel': 50,
            'map_panel': 50,
            'timeline_position': 'bottom'
        }
    
    obj = Scenario(**payload_dict, user=request.user)
    obj.save()
    
    return obj

@router.put('/{scenario_id}', response=ScenarioSchema, auth=django_auth)
def update_scenario(request, scenario_id: int, payload: InputUpdateScenarioSchema):
    obj = get_object_or_404(Scenario, id=scenario_id)

    if obj.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    for attr, value in payload.dict(exclude_unset=True).items():
        setattr(obj, attr, value)

    obj.save()
    return obj

@router.post('/upload-image/{scenario_id}/', response=ScenarioSchema, auth=django_auth)
def upload_scenario_image(request, scenario_id: int, card_image: File[UploadedFile]):

    obj = get_object_or_404(Scenario, id=scenario_id)

    if obj.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    obj.card_image.save(card_image.name, card_image)

    return obj

@router.delete('/{scenario_id}', auth=django_auth)
def delete_scenario(request, scenario_id: int):
    obj = get_object_or_404(Scenario, id=scenario_id)

    if obj.user != request.user and not request.user.is_superuser:
        return HttpResponse("No autorizado", status=403)

    obj.delete()
    return {"success": True, "message": "Escenario eliminado correctamente"}

# list scenario scenes
@router.get('/{identifier}/scenes/', response=List[SceneSchema], auth=None)
def list_scenes(request, identifier: int):
    # Obtener el escenario
    scenario = get_object_or_404(Scenario, id=identifier)

    # Verificar permisos del escenario padre
    if not scenario.is_public:
        if not request.user.is_authenticated:
            return HttpResponse("Este escenario es privado. Inicia sesión para verlo.", status=403)

        if scenario.user != request.user and not request.user.is_superuser:
            return HttpResponse("No tienes permiso para ver este escenario.", status=403)

    # Si tiene permisos, devolver las escenas
    queryset = Scene.objects.filter(scenario=scenario)
    return list(queryset.order_by("stack_order"))