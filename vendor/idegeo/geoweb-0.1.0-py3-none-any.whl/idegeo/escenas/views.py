import os
import json
from django.shortcuts import render
from django.shortcuts import get_object_or_404
from .models import Scenario
from django.http import JsonResponse

def index(request):
    user = request.user
    is_auth = ''
    userSerialize = {}

    if user.is_authenticated and not user.is_anonymous:
        userSerialize['id'] = user.id
        userSerialize['token'] = user.token
        userSerialize['username'] = user.username
        userSerialize['is_superuser'] = user.is_superuser
        userSerialize['is_staff'] = user.is_staff
        is_auth = 'True'

    template = "escenas_index.html"

    return render(
        request,
        template,
        {
            'user_isauth': is_auth,
            'user': json.dumps(userSerialize),
            'GEONODE_API_ROOT': os.environ.get('GEONODE_API_ROOT', 'http://localhost'),
        },
    )

def index_escenarios(request):
    user = request.user
    is_auth = ''
    userSerialize = {}

    if user.is_authenticated and not user.is_anonymous:
        userSerialize['id'] = user.id
        userSerialize['token'] = user.token
        userSerialize['username'] = user.username
        userSerialize['is_superuser'] = user.is_superuser
        userSerialize['is_staff'] = user.is_staff
        is_auth = 'True'

    is_public_route = "/escenario/" in request.path or "/publicos/" in request.path

    if is_public_route:
        template = "public_scenarios_index.html"
    else:
        template = "private_scenarios_index.html"

    return render(
        request, 
        template,
        {
            'user_isauth': is_auth,
            'user': json.dumps(userSerialize),
            'is_public_route': is_public_route,
            'GEONODE_API_ROOT': os.environ.get('GEONODE_API_ROOT', 'http://localhost'),
        },
    )

def index_escenas(request, slug=None):
    user = request.user
    is_auth = ''
    userSerialize = {}

    if user.is_authenticated and not user.is_anonymous:
        userSerialize['id'] = user.id
        userSerialize['token'] = user.token
        userSerialize['username'] = user.username
        userSerialize['is_superuser'] = user.is_superuser
        userSerialize['is_staff'] = user.is_staff
        is_auth = 'True'

    is_public_route = "/escena/" in request.path or "/publicas/" in request.path or slug is not None

    scenario_id = None
    if slug:
        try:
            from idegeo.escenas.models import Scenario
            scenario = get_object_or_404(Scenario, id=slug)
            scenario_id = str(scenario.id)
        except (ValueError, Scenario.DoesNotExist):
            try:
                scenario = get_object_or_404(Scenario, url_id=slug)
                scenario_id = str(scenario.id)
            except Scenario.DoesNotExist:
                pass

    if is_public_route:
        template = "public_scenes_index.html"
    else:
        template = "private_scenes_index.html"

    return render(
        request, 
        template,
        {
            'user_isauth': is_auth,
            'user': json.dumps(userSerialize),
            'is_public_route': is_public_route,
            'scenario_id': scenario_id,
            'GEONODE_API_ROOT': os.environ.get('GEONODE_API_ROOT', 'http://localhost'),
        },
    )

def viewer_escenario(request, scenario_id):
    print(f"🔍 viewer_escenario called with scenario_id: {scenario_id}")

    scenario = get_object_or_404(Scenario, id=scenario_id)

    # Verificar permisos
    if not scenario.is_public and scenario.user != request.user and not request.user.is_superuser:
        return JsonResponse({'error': 'No autorizado'}, status=403)

    context = {
        'scenario_id': scenario_id,
        'scenario_name': scenario.name,
        'is_public': scenario.is_public,
        'user_isauth': request.user.is_authenticated,
        'GEONODE_API_ROOT': os.environ.get('GEONODE_API_ROOT', 'http://localhost'),
    }

    print(f"🔍 Rendering viewer.html with context: {context}")

    return render(request, 'viewer.html', context)