from django.db import models
from django.core.exceptions import ValidationError
from ckeditor_uploader.fields import RichTextUploadingField
from django_choices_field import TextChoicesField
# from .scenario import Scenario

def default_styles():
    return {
        "text_panel": 40,
        "map_panel": 60,
    }

class ScenesDescriptor:
    def __get__(self, instance, owner):
        if instance is None:
            return self
        if not hasattr(instance, '_scenes'):
            instance._scenes = []
        return instance._scenes
    
    def __set__(self, instance, value):
        if not isinstance(value, list):
            raise ValidationError("El valor debe ser una lista")
        from .scene import Scene
        for item in value:
            if not isinstance(item, Scene):
                raise ValidationError("Todos los elementos deben ser instancias de Scene")
        instance._scenes = value

class SceneTextPosition(models.TextChoices):
    LEFT = "left", "Izquierda"
    RIGHT = "right", "Derecha"

class Scene(models.Model):
    name = models.CharField(
        max_length=256,
        verbose_name='Nombre',
        help_text='Nombre de la escena',
        blank=False)
    
    map_center_lat = models.FloatField(
        null=True,
        blank=True)

    map_center_long = models.FloatField(
        null=True,
        blank=True)

    zoom = models.IntegerField(
        null=True,
        blank=True)

    text_position = TextChoicesField(
        verbose_name="Tipo",
        choices_enum=SceneTextPosition,
        default=SceneTextPosition.LEFT,
        help_text="Posicion del texto dentro de una escena"
    )

    text_content = RichTextUploadingField(
        blank=True,
        null=True,
        verbose_name="Contenido",
        help_text="Texto de la escena"
    )

    styles = models.JSONField(
        verbose_name="Estilo de la escena",
        null=True,
        blank=True,
        default=default_styles
    )
    
    stack_order = models.IntegerField(default=0, blank=False)

    scenario = models.ForeignKey(
        'Scenario',
        blank=False,
        null=False,
        on_delete=models.CASCADE,
        related_name='scenes'
    )

    def __str__(self):
        return str(self.name)
    
    class Meta:
        db_table = "escenas_scenes"
        verbose_name = "Scene"
        verbose_name_plural = "Scenes"
        ordering = ["stack_order"]

    def save(self, *args, **kwargs):
        if self._state.adding:
            from .scenario import Scenario
            top_level_items = Scene.objects.filter(scenario=self.scenario).order_by('-stack_order')
            if top_level_items.exists():
                self.stack_order = top_level_items[0].stack_order + 1
            else:
                self.stack_order = 1

        super().save(*args, **kwargs)