from django.db import models
from django.conf import settings
from django.core.exceptions import ValidationError

class Scenario(models.Model):
    name = models.CharField(
        max_length=256,
        verbose_name='Nombre',
        help_text='Nombre del escenario',
        blank=False
    )
    created_at = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name="Propietario",
        on_delete=models.CASCADE,
        related_name='scenarios'
    )

    url_id = models.CharField(max_length=255, unique=True, null=True, blank=True)

    is_public = models.BooleanField(
        default=False,
        verbose_name='Público',
        help_text='Si está marcado, el escenario será visible para todos los usuarios.'
    )

    card_image = models.ImageField(
        upload_to='scenarios/cards/',
        null=True,
        blank=True,
        verbose_name='Imagen de portada',
        help_text='Imagen que representa el escenario'
    )

    description = models.TextField(
        blank=True,
        null=True,
        verbose_name='Descripción',
        help_text='Descripción detallada del escenario'
    )

    scenes_layout_styles = models.JSONField(
        default=dict,
        blank=True,
        verbose_name='Estilos de Layout',
        help_text='Configuración del layout de las escenas (text_panel, map_panel, timeline_position, primary_color, secondary_color)'
    )

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        if user is not None:
            self.user = user

    def add_scene(self, scene):
        from .scene import Scene
        if not hasattr(self, '_scenes_cache'):
            self._scenes_cache = []
        self.scenes.append(scene)

    @property
    def scenes(self):
        if not hasattr(self, '_scenes_cache'):
            self._scenes_cache = list(self.scene_set.all())
        return self._scenes_cache
    
    @scenes.setter
    def scenes(self, value):
        if not isinstance(value, list):
            raise ValidationError("El valor debe ser una lista")
        self._scenes_cache = value

    @property
    def owner(self):
        return self.user

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'escenas_scenarios'
        verbose_name = "Escenario"
        verbose_name_plural = "Escenarios"
        ordering = ['-created_at']