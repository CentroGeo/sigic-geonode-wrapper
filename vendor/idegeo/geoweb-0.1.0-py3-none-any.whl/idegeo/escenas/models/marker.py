from django.db import models
from ckeditor_uploader.fields import RichTextUploadingField
from .scene import Scene

class SceneMarker(models.Model):
    scene = models.ForeignKey(
        Scene,
        on_delete=models.CASCADE,
        related_name='markers'
    )
    lat = models.DecimalField(
        max_digits=19,
        decimal_places=10,
        verbose_name='Latitud',
        blank=False,
        null=False
    )
    lng = models.DecimalField(
        max_digits=19,
        decimal_places=10,
        verbose_name='Longitud',
        blank=False,
        null=False
    )
    title = models.CharField(
        verbose_name="Título",
        max_length=255,
        null=True,
        blank=True
    )
    content = RichTextUploadingField(
        verbose_name="Contenido del Marcador",
        null=True,
        blank=True
    )
    icon = models.CharField(
        max_length=50,
        default='fas fa-map-marker-alt',
        verbose_name="Icono",
        help_text="Clase de Font Awesome (ej: 'fas fa-home')"
    )
    color = models.CharField(
        max_length=7,
        default='#ec4899',
        verbose_name="Color del marcador",
        help_text="Color hexadecimal (ej: #ec4899, #2563eb)"
    )
    image_url = models.CharField(
        max_length=255,
        null=True,
        blank=True
    )
    options = models.JSONField(
        verbose_name="Opciones del marcador",
        null=True,
        blank=True,
        default=dict,
        help_text="Opciones adicionales en formato JSON"
    )
    
    class Meta:
        db_table = 'scenes_markers'
        verbose_name = "Scene Marker"
        verbose_name_plural = "Scene Markers"
        ordering = ['id']
    
    def __str__(self):
        return f"Marker {self.id} - {self.title or 'Sin título'} (Scene: {self.scene.name})"