from django.db import models
from ckeditor_uploader.fields import RichTextUploadingField
from fontawesome_6.fields import IconField

class Layer(models.Model):
    geonode_id = models.IntegerField(
        verbose_name='ID de la capa en Geonode',
        blank=True,
        null=True,
        db_index=True,
        help_text='ID de referencia de la capa en GeoNode'
    )
    
    scene = models.ForeignKey(
        'Scene',
        on_delete=models.CASCADE,
        related_name='layers',
        null=False,
        blank=False
    )
    
    name = models.CharField(
        max_length=256,
        verbose_name='Nombre de la capa (typename)',
        blank=False,
        help_text='Nombre técnico de la capa en GeoServer (ej: geonode:alcaldias_sumatoria)'
    )
    
    style = models.CharField(
        max_length=256,
        verbose_name='Nombre del estilo',
        blank=True,
        null=True,
        help_text='Nombre del estilo aplicado a la capa'
    )

    style_title = models.CharField(
        max_length=256,
        verbose_name='Título del estilo',
        blank=True,
        null=True,
        help_text='Título del estilo aplicado a la capa'
    )
    
    visible = models.BooleanField(
        default=True,
        verbose_name='Visible',
        help_text='Si la capa está visible en el mapa'
    )
    
    opacity = models.FloatField(
        default=1.0,
        verbose_name='Opacidad',
        help_text='Opacidad de la capa (0.0 a 1.0)'
    )
    
    stack_order = models.IntegerField(
        default=0,
        verbose_name='Orden de apilamiento',
        help_text='Orden de las capas en el mapa (mayor = arriba)'
    )
    
    class Meta:
        db_table = "scenes_layers"
        verbose_name = "Layer"
        verbose_name_plural = "Layers"
        ordering = ['stack_order']
    
    def __str__(self):
        return f"{self.name} (Scene: {self.scene_id})"
    
    def save(self, *args, **kwargs):
        if self._state.adding:
            layers = Layer.objects.filter(scene=self.scene).order_by('-stack_order')
            if layers.exists():
                self.stack_order = layers[0].stack_order + 1
            else:
                self.stack_order = 1
        super().save(*args, **kwargs)
