from django.urls import path, re_path


from . import views

urlpatterns = [

    # base urls
    path('', views.layers_catalogue, name="layers_home"),
    re_path(r'^external_wms/', views.external_wms, name='external_wms'),
    re_path(r'^pdf_metadata_layer/(?P<layer_pk>[^/]*)$', views.pdf_metadata_layer, name="pdf_metadata_layer"),
]