import os
import json
import requests
from weasyprint import HTML

from django.shortcuts import render
from django.template.loader import render_to_string
from django.http import HttpResponse, JsonResponse
from owslib.wms import WebMapService

from idegeo.GeonodeModels.models import HierarchicalKeyword, TopicCategory
from idegeo.GeonodeModels.utils import get_visible_resources


def layers_catalogue(request):
    
    categories = TopicCategory.objects.all()
    
    categories_dict = []
    for c in categories:
        categories_dict.append({
            'id': c.id,
            'identifier': c.identifier,
            'description': c.description,
            'description_en': c.description_en,
            'gn_description': c.gn_description,
            'gn_description_en': c.gn_description_en,
            'is_choice': c.is_choice,
            'fa_class': c.fa_class,
            'layers': get_visible_resources(request.user,c.resourcebase_set.filter(resource_type='dataset')).count()
        })
    
    tags = HierarchicalKeyword.objects.all()
    
    tags_dict = []
    for t in tags:
        if (
            t.keywords.filter(
                content_object__gt=0,
                content_object__resource_type__exact='dataset',
            ) 
            and t.name != 'GEOSERVER'
            and t.name != 'WFS'
            and t.name != 'WMS'
        ):
            tags_dict.append({
                'id': t.id,
                'name': t.name,
                'layers': get_visible_resources(request.user,t.keywords).count(),
            })

    return render(request, "layer_base.html", { 
        'tags': tags_dict,
        'categories': categories_dict
    })

def generar_pdf(html):
    pdf = HTML(string=html).write_pdf()
    
    if pdf:
        return HttpResponse(pdf, content_type='application/pdf')

    return HttpResponse('Error al generar el PDF')


def pdf_metadata_layer(request, layer_pk):

    response =  requests.get(
            os.getenv("GEONODE_API_ROOT") + "api/v2/datasets/" + layer_pk
    )

    layer_info = response.json()

    layer = layer_info["dataset"]

    rendered = render_to_string('pdf_metadata_layer.html', {'pagesize': 'A4', 'resource': layer})

    return generar_pdf(rendered)

def external_wms(request):
    if request.method == 'POST':
        # Get the raw bytes of the request payload
        payload = request.body
        
        # Parse the payload as JSON
        data = json.loads(payload)

        # Get the value of the wmsUrl variable from the JSON data
        wms_url = data.get('wmsUrl')
        name_search = data.get('nameSearch')
        layers_dict = {}

        wms = WebMapService(wms_url)

        layers = list(wms.contents)

        if name_search:
            if name_search in layers:
                layers_dict[name_search] = {
                    'title': wms.contents[name_search].title,
                    'styles': wms.contents[name_search].styles,
                    'abstract': wms.contents[name_search].abstract,
                    'bbox': wms.contents[name_search].boundingBox,
                }
        else:
            for layer in layers:
                layers_dict[layer] = {
                    'title': wms.contents[layer].title,
                    'styles': wms.contents[layer].styles,
                    'abstract': wms.contents[layer].abstract,
                    'bbox': wms.contents[layer].boundingBox,
                }
        return JsonResponse(layers_dict)

    else:
        return HttpResponse("Not ajax request")