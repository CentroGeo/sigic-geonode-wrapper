from django.apps import AppConfig

class IdegeoCatalogLayersConfig(AppConfig):
    name = "catalog.layers"
    label = "idegeo_catalog_layers"