from django.apps import AppConfig

class IdegeoCatalogLayersConfig(AppConfig):
    name = "idegeo.catalog.layers"
    label = "idegeo_catalog_layers"