from django.urls import path, re_path

from . import views

urlpatterns = [

    # base urls
    path('', views.maps_catalogue, name="geovisor_mapas"),
    re_path(r'^(?P<mapid>[^/]+)/embed$', views.map_embed, name='map_embed'),
    re_path(r'^(?P<mapid>[^/]+)/swipe_map$', views.swipe_map, name='swipe_map'),
    re_path(r'^(?P<mapid>[^/]+)/map_dual$', views.map_dual, name='map_dual'),
]