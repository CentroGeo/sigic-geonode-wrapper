import os
import json

from django.shortcuts import render
from django.views.decorators.clickjacking import xframe_options_exempt

from idegeo.GeonodeModels.models import HierarchicalKeyword, TopicCategory, Map, Style
from idegeo.GeonodeModels.utils import get_visible_resources


def maps_catalogue(request):
    
    categories = TopicCategory.objects.all()
    
    categories_dict = []
    for c in categories:
        categories_dict.append({
            'id': c.id,
            'identifier': c.identifier,
            'description': c.description,
            'description_en': c.description_en,
            'gn_description': c.gn_description,
            'gn_description_en': c.gn_description_en,
            'is_choice': c.is_choice,
            'fa_class': c.fa_class,
            'maps': get_visible_resources(request.user,c.resourcebase_set.filter(resource_type='map'))
        })
    
    tags = HierarchicalKeyword.objects.all()
    
    tags_dict = []
    for t in tags:
        if (
            t.keywords.filter(
                content_object__gt=0,
                content_object__resource_type__exact='map',
            ) 
            and t.name != 'GEOSERVER'
            and t.name != 'WFS'
            and t.name != 'WMS'
        ):
            tags_dict.append({
                'id': t.id,
                'name': t.name,
                'maps': get_visible_resources(request.user,t.keywords.all()),
                # 'maps': t.resourcebase_set.filter(resource_type='map')
            })

    maps = Map.objects.all()
    
    maps_dict = []
    for m in maps:
        maps_dict.append({
            'id': m.id,
            'title': m.title
        })

    return render(request, "maps_base.html", { 
        'tags': tags_dict,
        'categories': categories_dict,
        'map_list':maps_dict
    })

def get_or_none(classmodel, **kwargs):
    try:
        return classmodel.objects.get(**kwargs)
    except classmodel.DoesNotExist:
        return None

@xframe_options_exempt
def map_embed(request, mapid=None, template='embed/embed.html'):
    if mapid:
        map_obj = get_or_none(Map,id=mapid)

    if map_obj:
        serialized_layers = []
        for l in map_obj.maplayers.all():
            if l.dataset.resourcebase_ptr:
                style_title = Style.objects.get(name=l.current_style.split(':')[1])
                serialized_layers.append({
                    'uuid': l.id,
                    'pk': l.dataset.resourcebase_ptr.id,
                    'workspace': l.dataset.workspace,
                    'name': l.name,
                    'style': l.current_style,
                    'title': l.dataset.resourcebase_ptr.title,
                    'style_title': style_title.sld_title,
                    'abstract': l.dataset.resourcebase_ptr.abstract,
                    'll_bbox_polygon': json.loads(l.dataset.resourcebase_ptr.ll_bbox_polygon.geojson),
                    'ows_url': l.ows_url if l.ows_url else l.dataset.ows_url,
                    'order': l.order,
                    'visibility': l.visibility,
                    'opacity': l.opacity,
                    'attributes': [
                        {
                            'attribute': a.attribute, 
                            'visible': a.visible,
                            'label': a.attribute_label
                        } for a in l.dataset.attributes
                    ],
                    'download_url': f'{os.getenv("GEONODE_API_ROOT")}datasets/{l.name}/dataset_download',
                    'legend': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{l.dataset.name}&STYLE={l.current_style}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:12;forceLabels:on',
                })
        
        serialized_map = {
            'id': map_obj.pk,
            'title': map_obj.title,
            'map_data': map_obj.resourcebase_ptr.blob,
            'layers': serialized_layers
        }
        


    return render(request, template, {
        'map_title': map_obj.title,
        'map_data': json.dumps(serialized_map)
    })


def swipe_map(request, mapid=None, template='swipe/swipe_map.html'):

    map_obj = None
    if mapid:
        map_obj = get_or_none(Map,id=mapid)

    map_layers = []
    map_title = None
    config = {}
    if map_obj:
        for l in map_obj.maplayers.all():
            if l.dataset.resourcebase_ptr:
                style_title = Style.objects.get(name=l.current_style.split(':')[1])
                map_layers.append({
                    'uuid': l.id,
                    'pk': l.dataset.resourcebase_ptr.id,
                    'workspace': l.dataset.workspace,
                    'name': l.name,
                    'style': l.current_style,
                    'title': l.dataset.resourcebase_ptr.title,
                    'style_title': style_title.sld_title,
                    'abstract': l.dataset.resourcebase_ptr.abstract,
                    'll_bbox_polygon': json.loads(l.dataset.resourcebase_ptr.ll_bbox_polygon.geojson),
                    'url': l.ows_url if l.ows_url else l.dataset.ows_url,
                    'order': l.order,
                    'visibility': l.visibility,
                    'opacity': l.opacity,
                    'attributes': [
                        {
                            'attribute': a.attribute, 
                            'visible': a.visible,
                            'label': a.attribute_label
                        } for a in l.dataset.attributes
                    ],
                    'download_url': f'{os.getenv("GEONODE_API_ROOT")}datasets/{l.name}/dataset_download',
                    'legend': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{l.dataset.name}&STYLE={l.current_style}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:12;forceLabels:on',
                })
        
        map_title = map_obj.title
        config = map_obj.resourcebase_ptr.blob

    return render(request, template, {
        'config': json.dumps(config),
        'map_layers': json.dumps(map_layers),
        'map_title': map_title
    })


@xframe_options_exempt
# Vista que genera un objeto config para un mapa dual
def map_dual(request, mapid=None, template='dual/map_dual.html'):

    map_obj = None
    if mapid:
        map_obj = get_or_none(Map,id=mapid)

    map_layers = []
    map_title = None
    config = {}
    if map_obj:
        for l in map_obj.maplayers.all():
            if l.dataset.resourcebase_ptr:
                style_title = Style.objects.get(name=l.current_style.split(':')[1])
                map_layers.append({
                    'uuid': l.id,
                    'pk': l.dataset.resourcebase_ptr.id,
                    'workspace': l.dataset.workspace,
                    'name': l.name,
                    'style': l.current_style,
                    'title': l.dataset.resourcebase_ptr.title,
                    'style_title': style_title.sld_title,
                    'abstract': l.dataset.resourcebase_ptr.abstract,
                    'll_bbox_polygon': json.loads(l.dataset.resourcebase_ptr.ll_bbox_polygon.geojson),
                    'url': l.ows_url if l.ows_url else l.dataset.ows_url,
                    'order': l.order,
                    'visibility': l.visibility,
                    'opacity': l.opacity,
                    'download_url': f'{os.getenv("GEONODE_API_ROOT")}datasets/{l.name}/dataset_download',
                    'legend': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{l.dataset.name}&STYLE={l.current_style}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:12;forceLabels:on',
                })
        
        map_title = map_obj.title
        config = map_obj.resourcebase_ptr.blob

    return render(request, template, {
        'config': json.dumps(config),
        'map_layers': json.dumps(map_layers),
        'map_title': map_title
    })
