from django.apps import AppConfig

class IdegeoCatalogMapsConfig(AppConfig):
    name = "idegeo.catalog.maps"
    label = "idegeo_catalog_maps"