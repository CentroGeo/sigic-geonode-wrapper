from django.apps import AppConfig

class IdegeoCatalogMapsConfig(AppConfig):
    name = "catalog.maps"
    label = "idegeo_catalog_maps"