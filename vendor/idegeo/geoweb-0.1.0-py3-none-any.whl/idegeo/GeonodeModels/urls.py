from django.urls import re_path
from idegeo.GeonodeModels.views import *


urlpatterns = [
    re_path(r'^datasets/$', dataset_view, name='get_datasets'),
    re_path(r'^categories/$', categories_view, name='get_categories'),
    re_path(r'^map_view_data/$', maps_view, name='maps_view'),
]