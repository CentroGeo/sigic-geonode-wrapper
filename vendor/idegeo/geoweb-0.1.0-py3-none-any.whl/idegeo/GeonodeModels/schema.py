import os
import json
from typing import Optional
from ninja import Schema
from datetime import datetime
from idegeo.GeonodeModels.models import Layers
from idegeo.people.schema import DefaultUserSchema

class GeonodeLayerSchema(Schema):
    id: int
    pk: int
    uuid: str
    workspace: str
    store: str
    name: str
    typename: str
    charset: str
    default_style: dict
    styles: list
    elevation_regex: Optional[str] = None
    has_elevation: bool
    has_time: bool
    subtype: str
    title: str
    abstract: str
    ll_bbox_polygon: dict
    extent: tuple
    is_mosaic: bool
    time_regex: Optional[str] = None
    date: datetime
    remote_service_id: Optional[int] = None
    featureinfo_custom_template: Optional[str]
    use_featureinfo_custom_template: bool
    ptype: str
    thumbnail_url: str
    ows_url: str
    gwc_url: str
    direct_wps_download_url: str
    download_url: str
    legend: str
    legend_no_style: str
    attributes:list
    category: Optional[dict] = None
    regions: list

    @staticmethod
    def resolve_id(obj):
        return obj.resourcebase_ptr.id

    @staticmethod
    def resolve_pk(obj):
        return obj.resourcebase_ptr.id

    @staticmethod
    def resolve_uuid(obj):
        return obj.resourcebase_ptr.uuid

    @staticmethod
    def resolve_subtype(obj):
        return obj.resourcebase_ptr.subtype
    
    @staticmethod
    def resolve_title(obj):
        return obj.resourcebase_ptr.title
    
    @staticmethod
    def resolve_abstract(obj):
        return obj.resourcebase_ptr.abstract
    
    @staticmethod
    def resolve_ll_bbox_polygon(obj):
        return json.loads(obj.resourcebase_ptr.ll_bbox_polygon.geojson)
    
    @staticmethod
    def resolve_extent(obj):
        return obj.resourcebase_ptr.ll_bbox_polygon.extent

    @staticmethod
    def resolve_date(obj):
        return obj.resourcebase_ptr.date
        
    @staticmethod
    def resolve_thumbnail_url(obj):
        return obj.resourcebase_ptr.thumbnail_url

    @staticmethod
    def resolve_gwc_url(obj):
        return obj.ows_url.replace('ows', 'gwc/service/wms')

    @staticmethod
    def resolve_direct_wps_download_url(obj):
        return f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WPS&version=1.0.0&request=Execute&identifier=gs:Download&datainputs=layerName=geonode:{obj.name};outputFormat=application/zip&RawDataOutput=result'

    @staticmethod
    def resolve_download_url(obj):
        return f'{os.getenv("GEONODE_API_ROOT")}datasets/geonode:{obj.name}/dataset_download'

    @staticmethod
    def resolve_legend(obj):
        return f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{obj.name}&STYLE={obj.default_style.name if obj.default_style else ""}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:12;forceLabels:on'

    @staticmethod
    def resolve_legend_no_style(obj):
        return  f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{obj.name}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:12;forceLabels:on'

    @staticmethod
    def resolve_styles(obj):
        return [{
            'id': style.id,
            'name': style.name,
            'sld_title': style.sld_title,
            'workspace': style.workspace
        } for style in obj.styles.all()]

    @staticmethod
    def resolve_default_style(obj):
        return {
            'id': obj.default_style.id if obj.default_style else None,
            'name': obj.default_style.name if obj.default_style else None,
            'sld_title': obj.default_style.sld_title if obj.default_style else None,
            'workspace': obj.default_style.workspace if obj.default_style else None
        }

    
    @staticmethod
    def resolve_attributes(obj):
        return [
            {
                'attribute': a.attribute, 
                'visible': a.visible,
                'label': a.attribute_label
            } for a in obj.attributes
        ]

    
    @staticmethod
    def resolve_category(obj):
        return {
            'id': obj.resourcebase_ptr.category.id,
            'identifier': obj.resourcebase_ptr.category.identifier,
            'description': obj.resourcebase_ptr.category.description,
            'gn_description': obj.resourcebase_ptr.category.gn_description,
            'fa_class': obj.resourcebase_ptr.category.fa_class,
            'count': 1
        } if obj.resourcebase_ptr.category else None

    
    @staticmethod
    def resolve_regions(obj):
        return [
            {
                'code': r.code,
                'name': r.name
            } for r in obj.regions.all()
        ]