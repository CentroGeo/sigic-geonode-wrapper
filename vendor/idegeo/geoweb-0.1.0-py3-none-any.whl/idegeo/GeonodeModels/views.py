import os
import json
from django.http import JsonResponse
from idegeo.GeonodeModels.models import Layers, Map, Style, TopicCategory
from idegeo.GeonodeModels.utils import get_visible_resources
from django.db.models import Q


def dataset_view(request):

    q = Q()

    if 'title' in request.GET: 
        q &= Q(resourcebase_ptr__title__icontains=request.GET['title'])

    if 'region' in request.GET: 
        q &= Q(regions__name=request.GET['region'])

    
    if 'category' in request.GET: 
        q &= Q(resourcebase_ptr__category__identifier=request.GET['category'])


    if 'keyword' in request.GET: 
        q &= Q(resourcebase_ptr__keywords__id=request.GET['keyword'])


    if 'provider' in request.GET: 
        q &= Q(resourcebase_ptr__edition=request.GET['provider'])

    if 'advertised' in request.GET:
        q &= Q(resourcebase_ptr__advertised=request.GET['advertised'])
    
    if 'page_size' in request.GET: 
        page_size = int(request.GET['page_size'])
    else:
        page_size = 100
    
    # Get the page number from the request, defaulting to 1 if not provided
    if 'page' in request.GET:
        page = int(request.GET['page'])
    else:
        page = 1

    # Calculate the starting and ending indices for pagination
    start_index = (page - 1) * page_size
    end_index = page * page_size

    # Retrieve the appropriate slice of layers using the calculated indices
    queryset = get_visible_resources(request.user,Layers.objects.filter(q))
    queryset = queryset.order_by('resourcebase_ptr__title')
    layers = queryset[start_index:end_index]

    # Calculate the total number of records that match the query
    total_records = queryset.count()

    # Calculate the total number of pages
    total_pages = (total_records + page_size - 1) // page_size  # This ensures rounding up
    serialized_layers = []
    for l in layers:
        serialized_layers.append({
            'id': l.resourcebase_ptr.id,
            'pk': l.resourcebase_ptr.id,
            'uuid': l.resourcebase_ptr.uuid,
            'workspace': l.workspace,
            'store': l.store,
            'name': l.name,
            'typename': l.typename,
            'charset': l.charset,
            'default_style': {
                'id': l.default_style.id if l.default_style else None,
                'name': l.default_style.name if l.default_style else None,
                'sld_title': l.default_style.sld_title if l.default_style else None,
                'workspace': l.default_style.workspace if l.default_style else None
            },
            'styles': [{
                'id': style.id,
                'name': style.name,
                'sld_title': style.sld_title,
                'workspace': style.workspace
            } for style in l.styles.all()],
            'elevation_regex': l.elevation_regex,
            'has_elevation': l.has_elevation,
            'has_time': l.has_time,
            'subtype': l.resourcebase_ptr.subtype,
            'title': l.resourcebase_ptr.title,
            'abstract': l.resourcebase_ptr.abstract,
            'll_bbox_polygon': l.resourcebase_ptr.ll_bbox_polygon.geojson,
            'extent': l.resourcebase_ptr.ll_bbox_polygon.extent,
            'is_mosaic': l.is_mosaic,
            'time_regex': l.time_regex,
            'date': l.resourcebase_ptr.date,
            'remote_service_id': l.remote_service_id,
            'featureinfo_custom_template': l.featureinfo_custom_template,
            'use_featureinfo_custom_template': l.use_featureinfo_custom_template,
            'ptype': l.ptype,
            'thumbnail_url': l.resourcebase_ptr.thumbnail_url,
            'ows_url': l.ows_url,
            'gwc_url': l.ows_url.replace('ows', 'gwc/service/wms'),
            'direct_wps_download_url': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WPS&version=1.0.0&request=Execute&identifier=gs:Download&datainputs=layerName=geonode:{l.name};outputFormat=application/zip&RawDataOutput=result',
            'download_url': f'{os.getenv("GEONODE_API_ROOT")}datasets/geonode:{l.name}/dataset_download',
            'legend': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{l.name}&STYLE={l.default_style.name if l.default_style else ""}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:12;forceLabels:on',
            'legend_no_style': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{l.name}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:12;forceLabels:on',
            'attributes': [
                {
                    'attribute': a.attribute, 
                    'visible': a.visible,
                    'label': a.attribute_label
                } for a in l.attributes
            ],
            'category': {
                'id': l.resourcebase_ptr.category.id,
                'identifier': l.resourcebase_ptr.category.identifier,
                'description': l.resourcebase_ptr.category.description,
                'gn_description': l.resourcebase_ptr.category.gn_description,
                'fa_class': l.resourcebase_ptr.category.fa_class,
                'count': 1
            } if l.resourcebase_ptr.category else None,
            'regions': [
                {
                    'code': r.code,
                    'name': r.name
                } for r in l.regions.all()
            ]
        })

    return JsonResponse({
        "layers": serialized_layers,
        "total": total_records,
        "total_pages": total_pages
    })


def maps_view(request):

    if 'mapid' in request.GET: 

        map = Map.objects.get(pk=request.GET['mapid'])
        serialized_layers = []
        for l in map.maplayers.all():
            if l.dataset.resourcebase_ptr:
                style_title = Style.objects.get(name=l.current_style.split(':')[1])
                serialized_layers.append({
                    'uuid': l.id,
                    'pk': l.dataset.resourcebase_ptr.id,
                    'workspace': l.dataset.workspace,
                    'name': l.name,
                    'style': l.current_style,
                    'title': l.dataset.resourcebase_ptr.title,
                    'style_title': style_title.sld_title,
                    'abstract': l.dataset.resourcebase_ptr.abstract,
                    'll_bbox_polygon': json.loads(l.dataset.resourcebase_ptr.ll_bbox_polygon.geojson),
                    'ows_url': l.ows_url if l.ows_url else l.dataset.ows_url,
                    'order': l.order,
                    'visibility': l.visibility,
                    'opacity': l.opacity,
                    'attributes': [
                        {
                            'attribute': a.attribute, 
                            'visible': a.visible,
                            'label': a.attribute_label
                        } for a in l.dataset.attributes
                    ],
                    'direct_wps_download_url': f'{os.getenv("GEONODE_API_ROOT")}/geoserver/ows?service=WPS&version=1.0.0&request=Execute&identifier=gs:Download&datainputs=layerName=geonode:{l.dataset.name};outputFormat=SHAPE-ZIP&RawDataOutput={l.dataset.name}',
                    'download_url': f'{os.getenv("GEONODE_API_ROOT")}datasets/{l.name}/dataset_download',
                    'legend': f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{l.dataset.name}&STYLE={l.current_style}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:12;forceLabels:on',
                })
        
        serialized_map = {
            'id': map.pk,
            'title': map.title,
            'map_data': map.resourcebase_ptr.blob,
            'layers': serialized_layers
        }
        
        return JsonResponse(serialized_map)

    else:
        
        return JsonResponse({"layers": {}})
    

def categories_view(request):

    all_categories = TopicCategory.objects.all()

    serialized_categories = []
    for cat in all_categories:
        serialized_categories.append({
            'id': cat.id,
            'identifier': cat.identifier,
            'description': cat.description,
            'description_en': cat.description_en,
            'gn_description': cat.gn_description,
            'gn_description_en': cat.gn_description_en,
            'is_choice': cat.is_choice,
            'fa_class': cat.fa_class,
            'link': f'{os.getenv("GEONODE_API_ROOT")}api/v2/categories/{cat.id}',
            'count': get_visible_resources(request.user,cat.resourcebase_set.filter(resource_type='dataset')).count()
        })

    return JsonResponse({
        'categories': serialized_categories,
        'total': len(serialized_categories)
    })