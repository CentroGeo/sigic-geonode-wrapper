from django.db.models import Q
from django.db import connections


def get_permitted_resources(user, queryset):

    user_id = -1 if user.is_anonymous else int(user.geonode_user_id)

    with connections["geonode"].cursor() as cursor:
        cursor.execute("""
            SELECT id FROM django_content_type 
            WHERE model = 'resourcebase' AND app_label = 'base'
        """)
        content_type = cursor.fetchone()
    
    if not content_type:
        return queryset.none()

    content_type_id = content_type[0]

    # Fetch permission IDs manually to interpolate the IN clause
    with connections["geonode"].cursor() as cursor:
        cursor.execute("""
            SELECT id FROM auth_permission 
            WHERE content_type_id = %s AND codename IN ('view_resourcebase', 'change_resourcebase')
        """, [content_type_id])
        permission_ids = [row[0] for row in cursor.fetchall()]

    if not permission_ids:
        return queryset.none()
    
    permission_ids_sql = ",".join(str(pid) for pid in permission_ids)

    resource_ids = set()

    with connections["geonode"].cursor() as cursor:
        cursor.execute(f"""
            SELECT object_pk FROM guardian_userobjectpermission
            WHERE user_id = %s AND permission_id IN ({permission_ids_sql})
        """, [user_id])
        resource_ids.update([int(row[0]) for row in cursor.fetchall()])

    with connections["geonode"].cursor() as cursor:
        cursor.execute(f"""
            SELECT gp.object_pk FROM guardian_groupobjectpermission gp
            JOIN people_profile_groups ug ON gp.group_id = ug.group_id
            WHERE ug.profile_id = %s AND gp.permission_id IN ({permission_ids_sql})
        """, [user_id])
        resource_ids.update([int(row[0]) for row in cursor.fetchall()])

    # Filtering the queryset
    model_fields = {field.name for field in queryset.model._meta.get_fields()}
    if not resource_ids:
        return queryset.none()

    if "content_object" in model_fields:
        return queryset.filter(content_object__id__in=resource_ids)
    elif "id" in model_fields:
        return queryset.filter(id__in=resource_ids)
    elif "resourcebase_ptr" in model_fields:
        return queryset.filter(resourcebase_ptr__id__in=resource_ids)
    else:
        return queryset.none()




def get_visible_resources(
    user,
    queryset
):

    is_admin = user.is_superuser if user and user.is_authenticated else False
    if is_admin:
        return queryset

    if not is_admin:

        if not user or not user.is_authenticated or user.is_anonymous:
            model_fields = {field.name for field in queryset.model._meta.get_fields()}

            if "content_object" in model_fields:
                queryset = queryset.filter(
                    Q(content_object__is_published=True) 
                ).exclude(content_object__is_approved=False)
            elif "id" in model_fields:
                queryset = queryset.filter(
                    Q(is_published=True) 
                ).exclude(is_approved=False)
            elif "resourcebase_ptr" in model_fields:
                queryset = queryset.filter(
                    Q(resourcebase_ptr__is_published=True) 
                ).exclude(resourcebase_ptr__is_approved=False)

        queryset = get_permitted_resources(
            user, queryset
        )

    return queryset