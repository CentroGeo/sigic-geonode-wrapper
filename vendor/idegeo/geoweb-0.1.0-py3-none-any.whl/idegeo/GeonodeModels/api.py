from uuid import UUID
from typing import List, Optional
from ninja import Router, UploadedFile, File, Form
from ninja.pagination import paginate, PageNumberPagination
from django.shortcuts import get_object_or_404
from django.db.models import Q

from idegeo.GeonodeModels.models import Layers, Map, Style, TopicCategory
from idegeo.GeonodeModels.utils import get_visible_resources
from idegeo.GeonodeModels.schema import GeonodeLayerSchema

router = Router(tags=["Geonode"])


@router.get('/layers/', response=List[GeonodeLayerSchema], auth=None)
@paginate(PageNumberPagination, page_size=10)
def list_geonode_layers(
    request, 
    title: Optional[str] = None,
    region: Optional[str] = None,
    category: Optional[str] = None,
    keyword: Optional[str] = None,
    provider: Optional[str] = None,
    advertised: Optional[str] = None,
):
    q = Q()

    if title: 
        q &= Q(resourcebase_ptr__title__icontains=title)

    if region: 
        q &= Q(regions__name=region)

    if category: 
        q &= Q(resourcebase_ptr__category__identifier=category)

    if keyword: 
        q &= Q(resourcebase_ptr__keywords__id=keyword)

    if provider: 
        q &= Q(resourcebase_ptr__edition=provider)

    if advertised:
        q &= Q(resourcebase_ptr__advertised=advertised)
        
    queryset = get_visible_resources(request.user,Layers.objects.filter(q))
    queryset = queryset.order_by('resourcebase_ptr__title')

    return queryset