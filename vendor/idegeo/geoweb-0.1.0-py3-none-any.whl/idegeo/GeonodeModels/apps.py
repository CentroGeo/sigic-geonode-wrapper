from django.apps import AppConfig


class GeonodeModelsConfig(AppConfig):
    name = "idegeo.GeonodeModels"
    verbose_name = "GeonodeModels"