from django.db import models
from django.db.models import Count
from django.db.models.fields.json import JSONField
from django.contrib.gis.db.models import PolygonField


from taggit.models import TagBase, ItemBase
from taggit.managers import TaggableManager, _TaggableManager

from treebeard.mp_tree import MP_Node, MP_NodeQuerySet, MP_NodeManager

class LayersManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().using("geonode")
    

class Layers(models.Model):
    resourcebase_ptr                = models.OneToOneField('ResourceBase',primary_key=True,on_delete=models.CASCADE)
    title_en                        = models.CharField(null=True, blank=True, max_length=255)
    abstract_en                     = models.TextField(null=True, blank=True)
    purpose_en                      = models.TextField(null=True, blank=True)
    constraints_other_en            = models.TextField(null=True, blank=True)
    supplemental_information_en     = models.TextField(null=True, blank=True)
    data_quality_statement_en       = models.TextField(null=True, blank=True)
    workspace                       = models.CharField(null=True, blank=True, max_length=255)
    store                           = models.CharField(null=True, blank=True, max_length=255)
    name                            = models.CharField(null=True, blank=True, max_length=255)
    typename                        = models.CharField(null=True, blank=True, max_length=255)
    charset                         = models.CharField(null=True, blank=True, max_length=255)
    elevation_regex                 = models.CharField(null=True, blank=True, max_length=128)
    has_elevation                   = models.BooleanField(null=True, blank=True)
    has_time                        = models.BooleanField()
    is_mosaic                       = models.BooleanField()
    time_regex                      = models.CharField(null=True, blank=True, max_length=128)
    remote_service_id               = models.IntegerField(null=True, blank=True)
    featureinfo_custom_template     = models.TextField(null=True, blank=True)
    use_featureinfo_custom_template = models.BooleanField()
    ptype                           = models.CharField(null=True, blank=True, max_length=255)
    ows_url                         = models.CharField(null=True, blank=True, max_length=200)
    default_style                   = models.ForeignKey(
                                        'Style', on_delete=models.SET_NULL, related_name="dataset_default_style", null=True, blank=True
                                    )
    styles                          = models.ManyToManyField('Style', through='LayerStyle', related_name="dataset_styles")

    regions = models.ManyToManyField(
        'Region', verbose_name="keywords region", blank=True, through='ResourceBaseRegions'
    )

    objects = LayersManager()

    @property
    def attributes(self):
        if self.attribute_set and self.attribute_set.count():
            _attrs = self.attribute_set
        else:
            _attrs = Attribute.objects.filter(dataset=self)
        return _attrs.exclude(attribute="the_geom").order_by("display_order")

    def attribute_config(self):
        # Get custom attribute sort order and labels if any
        cfg = {}
        visible_attributes = self.attribute_set.visible()
        if visible_attributes.exists():
            cfg["getFeatureInfo"] = {
                "fields": [lyr.attribute for lyr in visible_attributes],
                "propertyNames": {lyr.attribute: lyr.attribute_label for lyr in visible_attributes},
                "displayTypes": {lyr.attribute: lyr.featureinfo_type for lyr in visible_attributes},
            }

        if self.use_featureinfo_custom_template:
            cfg["ftInfoTemplate"] = self.featureinfo_custom_template

        return cfg

    def __str__(self):
        return str(self.alternate)

    def __str__(self):
        return self.title_en
    
    class Meta:
        db_table = "layers_dataset"
        managed = False


class Attribute(models.Model):
    attribute          = models.CharField(null=True, blank=True, max_length=255)
    description        = models.CharField(null=True, blank=True, max_length=255)
    attribute_label    = models.CharField(null=True, blank=True, max_length=255)
    attribute_type     = models.CharField(null=True, blank=True, max_length=50)
    visible            = models.BooleanField()
    display_order      = models.IntegerField(null=True, blank=True)
    count              = models.IntegerField(null=True, blank=True)
    min                = models.CharField(null=True, blank=True, max_length=255)
    max                = models.CharField(null=True, blank=True, max_length=255)
    average            = models.CharField(null=True, blank=True, max_length=255)
    median             = models.CharField(null=True, blank=True, max_length=255)
    stddev             = models.CharField(null=True, blank=True, max_length=255)
    sum                = models.CharField(null=True, blank=True, max_length=255)
    unique_values      = models.TextField(null=True, blank=True)
    last_stats_updated = models.DateTimeField(null=True, blank=True)
    dataset            = models.ForeignKey(Layers, blank=False, null=False, unique=False, on_delete=models.CASCADE, related_name="attribute_set")
    featureinfo_type   = models.CharField(null=True, blank=True, max_length=255)

    def __str__(self):
        return self.attribute
    
    class Meta:
        db_table = "layers_attribute"
        managed = False


class LayerStyle(models.Model):
    dataset = models.ForeignKey('Layers', to_field='resourcebase_ptr_id', on_delete=models.CASCADE)
    style = models.ForeignKey('Style', on_delete=models.CASCADE)

    class Meta:
        db_table = 'layers_dataset_styles'
        managed = False

class Style(models.Model):

    """Model for storing styles."""

    name = models.CharField("style name", max_length=255, unique=True)
    sld_title = models.CharField(max_length=255, null=True, blank=True)
    sld_body = models.TextField("sld text", null=True, blank=True)
    sld_version = models.CharField("sld version", max_length=12, null=True, blank=True)
    sld_url = models.CharField("sld url", null=True, max_length=1000)
    workspace = models.CharField(max_length=255, null=True, blank=True)
    
    def __str__(self):
        return str(self.name)
    
    class Meta:
        db_table = "layers_style"
        managed = False

class TaggedContentItem(ItemBase):
    content_object = models.ForeignKey("ResourceBase", on_delete=models.CASCADE)
    tag = models.ForeignKey("HierarchicalKeyword", related_name="keywords", on_delete=models.CASCADE)

    # see https://github.com/alex/django-taggit/issues/101
    @classmethod
    def tags_for(cls, model, instance=None, **extra_filters):
        kwargs = extra_filters or {}
        if instance is not None:
            return cls.tag_model().objects.filter(**{f"{cls.tag_relname()}__content_object": instance}, **kwargs)
        return (
            cls.tag_model()
            .objects.filter(**{f"{cls.tag_relname()}__content_object__isnull": False}, **kwargs)
            .distinct()
        )
    
    class Meta:
        db_table = "base_taggedcontentitem"
        managed = False


class HierarchicalKeywordQuerySet(MP_NodeQuerySet):
    """QuerySet to automatically create a root node if `depth` not given."""

    def create(self, **kwargs):
        if "depth" not in kwargs:
            return self.model.add_root(**kwargs)
        return super().create(**kwargs)


class HierarchicalKeywordManager(MP_NodeManager):
    def get_queryset(self):
        return HierarchicalKeywordQuerySet(self.model).order_by("path")

class HierarchicalKeyword(TagBase, MP_Node):
    node_order_by = ["name"]
    objects = HierarchicalKeywordManager()
     
    class Meta:
        db_table = "base_hierarchicalkeyword"
        managed = False
class ResourceBase(models.Model):

    uuid = models.CharField(max_length=36, unique=True)
    title = models.CharField("title", max_length=255)
    abstract = models.TextField("abstract", max_length=2000, blank=True)
    edition = models.CharField("edition", max_length=255)
    purpose = models.TextField("purpose", max_length=500, null=True, blank=True)
    alternate = models.CharField("alternate", max_length=255, null=True, blank=True)
    bbox_polygon = PolygonField(null=True, blank=True)
    ll_bbox_polygon = PolygonField(null=True, blank=True)
    blob = JSONField(null=True, blank=True)
    srid = models.CharField(max_length=30, blank=False, null=False, default="EPSG:4326")
    resource_type = models.CharField("Resource Type", max_length=1024, blank=True, null=True)
    thumbnail_url = models.TextField("Thumbnail url", null=True, blank=True)
    thumbnail_path = models.TextField("Thumbnail path", null=True, blank=True)
    subtype = models.CharField(max_length=128, null=True, blank=True)
    date = models.DateTimeField("date")
    date_type = models.CharField(
        "date type", max_length=255, default="publication"
    )
    resource_type = models.CharField(max_length=255)
    category = models.ForeignKey(
        'TopicCategory',
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    keywords = TaggableManager(
        "keywords",
        through=TaggedContentItem,
        blank=True,
        manager=_TaggableManager,
    )
    is_published = models.BooleanField(
        "Is Published", default=True
    )
    is_approved = models.BooleanField(
        "Approved", default=True
    )
    advertised = models.BooleanField(
        "Advertised",
        default=True,
        help_text="If False, will hide the resource from search results and catalog listings",
    )

    class Meta:
        db_table = "base_resourcebase"
        managed = False



class RegionManager(models.Manager):
    def get_queryset(self): 
        qs = super().get_queryset().using("geonode")
        qs = qs.annotate(count=Count('layers'))
        return qs
    

class Region(models.Model):
    code = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=255)
    name_en = models.CharField(max_length=255)
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.CASCADE, related_name="children")

    # Save bbox values in the database.
    # This is useful for spatial searches and for generating thumbnail images
    # and metadata records.
    bbox_x0 = models.DecimalField(max_digits=30, decimal_places=15, blank=True, null=True)
    bbox_x1 = models.DecimalField(max_digits=30, decimal_places=15, blank=True, null=True)
    bbox_y0 = models.DecimalField(max_digits=30, decimal_places=15, blank=True, null=True)
    bbox_y1 = models.DecimalField(max_digits=30, decimal_places=15, blank=True, null=True)
    srid = models.CharField(max_length=30, blank=False, null=False, default="EPSG:4326")

    objects = RegionManager()

    def __str__(self):
        return str(self.name)
    
    class Meta:
        db_table = "base_region"
        managed = False



class ResourceBaseRegions(models.Model):
    resourcebase = models.ForeignKey(Layers,blank=False, null=False, on_delete=models.CASCADE)
    region = models.ForeignKey(Region,blank=False, null=False, on_delete=models.CASCADE)

    class Meta:
        db_table = "base_resourcebase_regions"
        managed = False


class TopicCategoryManager(models.Manager):
    def get_queryset(self): 
        qs = super().get_queryset().using("geonode")
        qs = qs.annotate(count=Count('resourcebase'))
        return qs
    

class TopicCategory(models.Model):

    identifier = models.CharField(max_length=255, default="location")
    description = models.TextField(default="")
    description_en = models.TextField(default="")
    gn_description = models.TextField("GeoNode description", default="", null=True)
    gn_description_en = models.TextField("GeoNode description en", default="", null=True)
    is_choice = models.BooleanField(default=True)
    fa_class = models.CharField(max_length=64, default="fa-times")

    objects = TopicCategoryManager()

    def __str__(self):
        return self.gn_description

    class Meta:
        db_table = "base_topiccategory"
        managed = False


class Document(ResourceBase):

    """
    A document is any kind of information that can be attached to a map such as pdf, images, videos, xls...
    """

    extension = models.CharField(max_length=128, blank=True, null=True)

    doc_url = models.URLField(
        blank=True,
        null=True,
        max_length=255,
        help_text="The URL of the document if it is external.",
        verbose_name="URL",
    )

    title_en = models.CharField(null=True, blank=True, max_length=255)

    def __str__(self):
        return str(self.title)
    
    class Meta:
        db_table = "documents_document"
        managed = False


class Map(ResourceBase):
    """
    A Map aggregates several layers together and annotates them with a viewport
    configuration.
    """

    last_modified = models.DateTimeField(auto_now_add=True)
    # The last time the map was modified.

    urlsuffix = models.CharField("Site URL", max_length=255, blank=True)
    # Alphanumeric alternative to referencing maps by id, appended to end of
    # URL instead of id, ie http://domain/maps/someview

    featuredurl = models.CharField("Featured Map URL", max_length=255, blank=True)
    # Full URL for featured map view, ie http://domain/someview

    def __str__(self):
        return f'{self.title}'

    @property
    def datasets(self):
        dataset_names = MapLayer.objects.filter(map__id=self.id).values("name")
        return Layers.objects.filter(resourcebase_ptr__alternate__in=dataset_names)

    def keyword_list(self):
        keywords_qs = self.keywords.all()
        if keywords_qs:
            return [kw.name for kw in keywords_qs]
        else:
            return []

    @property
    def sender(self):
        return None

    @property
    def class_name(self):
        return self.__class__.__name__

    class Meta:
        db_table = "maps_map"
        managed = False


class MapLayer(models.Model):
    """
    The MapLayer model represents a layer included in a map.  This doesn't just
    identify the dataset, but also extra options such as which style to load
    and the file format to use for image tiles.
    """

    map = models.ForeignKey(Map, related_name="maplayers", on_delete=models.CASCADE, null=True, blank=True)
    # The map containing this layer

    dataset = models.ForeignKey(Layers, related_name="maplayers", on_delete=models.SET_NULL, null=True, blank=True)
    # The dataset object, retrieved by the `name` (Dataset alternate) and `store` attributes.

    extra_params = models.JSONField(null=True, default=dict, blank=True)
    # extra_params: an opaque JSONField where the client can put useful
    # information about the maplayer. For the moment the only extra information
    # will be the "msid", which is set by the client to match the maplayer with
    # the layer inside the mapconfig blob.

    name = models.TextField("name", null=True, blank=True)
    # The name of the layer to load.

    store = models.TextField("store", null=True, blank=True)

    # The interpretation of this name depends on the source of the layer (Google
    # has a fixed set of names, WMS services publish a list of available layers
    # in their capabilities documents, etc.)

    current_style = models.TextField("current style", null=True, blank=True)
    # Here in `current_style` we store the selected style.

    ows_url = models.URLField("ows URL", null=True, blank=True)
    # The URL of the OWS service providing this layer, if any exists.

    local = models.BooleanField(default=False, blank=True)
    # True if this layer is served by the local geoserver

    # Extend MapLayer model with visualization properties #11251
    order = models.IntegerField(default=0)
    visibility = models.BooleanField(default=True)
    opacity = models.FloatField(default=1.0)

    @property
    def dataset_title(self):
        """
        Used by geonode/maps/templates/maps/map_download.html
        """
        if self.dataset:
            title = self.dataset.title
        else:
            title = self.name
        return title

    @property
    def local_link(self):
        """
        Used by geonode/maps/templates/maps/map_download.html
        """
        layer = self.dataset if self.local else None
        if layer:
            link = f'<a href="{layer.get_absolute_url()}">{layer.title}</a>'
        else:
            link = f"<span>{self.name}</span> "
        return link

    @property
    def get_legend(self):
        # Get style name or return None
        if self.dataset and self.dataset.default_style:
            style_name = self.dataset.default_style.name
        elif self.current_style and ":" in self.current_style:
            style_name = self.current_style.split(":")[1]
        elif self.current_style:
            style_name = self.current_style
        else:
            return None

        href = self.dataset.get_legend_url(style_name=style_name)
        style = Style.objects.filter(name=style_name).first()
        if style:
            # replace map-legend display name if style has a title
            style_name = style.sld_title or style_name
        return {style_name: href}

    class Meta:
        db_table = "maps_maplayer"
        managed = False
        ordering = ["order"]

    def __str__(self):
        return f"{self.ows_url}?datasets={self.name}"