import os

from django.db import models
from django.utils.text import slugify
from django.conf import settings
from idegeo.geo_stories.models.base import IdegeoBaseModel
from django_choices_field import TextChoicesField


def get_upload_path(instance, filename):
    return os.path.join("map_previews", filename)

class MapType(models.TextChoices):
    REGULAR = "regular", "Regular"
    SWIPE = "swipe", "Swipe"
    DUAL = "dual", "Dual"


class MapPosition(models.TextChoices):
    LEFT = "left", "Izquierda"
    RIGHT = "right", "Derecha"



class IdegeoMap(IdegeoBaseModel):

    name = models.CharField(
        verbose_name="Nombre del mapa",
        max_length=255
    )

    slug = models.SlugField(unique=True, max_length=30, blank=True)

    preview = models.ImageField(
        upload_to=get_upload_path,
        null=True,
        blank=True,
        verbose_name="Previsualizacion del mapa"
    )

    zoom = models.IntegerField(
        verbose_name='zoom',
        default=5
    )

    center_lat = models.FloatField(
        verbose_name='center X',
        default=-101.61
    )

    center_long = models.FloatField(
        verbose_name='center Y',
        default=22.21
    )

    map_type = TextChoicesField(
        verbose_name="Tipo de mapa",
        choices_enum=MapType,
        default=MapType.REGULAR,
    )

    base_layer = models.CharField(
        max_length=255,
        verbose_name="Capa base",
        default="osm",
    )

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name="Propietario",
        on_delete=models.CASCADE
    )

    highlight_color = models.CharField(
        verbose_name="Color de resaltado",
        max_length=255,
        default="#ff51ba"
    )

    def save(self, *args, **kwargs):
        if not self.slug and self.name:
            base_slug = slugify(self.name)[:20]
            slug = base_slug
            suffix = 1

            while IdegeoMap.objects.filter(slug=slug).exists():
                # Adjust max length to leave room for suffix
                slug = f"{base_slug[:20 - len(str(suffix)) - 1]}-{suffix}"
                suffix += 1

            self.slug = slug

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name
    
    class Meta:
        db_table = "IdegeoMap"

        verbose_name = "Idegeo Map"

        verbose_name_plural = "Idegeo Maps"

        ordering = ["-updated_at"]


class IdegeoMapLayer(IdegeoBaseModel):

    map = models.ForeignKey(
        IdegeoMap,
        on_delete=models.CASCADE
    )

    name = models.CharField(
        max_length=256,
        verbose_name='Nombre de la capa en Geoserver',
        blank=False
    )

    style = models.CharField(
        max_length=256,
        verbose_name='Estilo de la capa',
        blank=True
    )

    geonode_id = models.CharField(
        max_length=256,
        verbose_name='Id de la capa en Geonode',
        blank=True,
        null=True
    )

    map_position = TextChoicesField(
        verbose_name="Posición en el mapa (si aplica)",
        choices_enum=MapPosition,
        default=MapPosition.LEFT,
    )

    visibility = models.BooleanField(default=True)

    opacity = models.FloatField(default=1.0)
    
    stack_order = models.IntegerField(default=0, blank=False)

    def __str__(self):
        return f"Map: {self.map.name}, Layer: {self.name}"
    
    class Meta:
        db_table = "IdegeoMapLayer"

        verbose_name = "Idegeo Map Layer"

        verbose_name_plural = "Idegeo Map Layers"

    def save(self, *args, **kwargs):
        if self._state.adding:
            layers = IdegeoMapLayer.objects.filter(map=self.map).order_by('-stack_order')
            if layers.exists():
                self.stack_order = layers[0].stack_order + 1
            else:
                self.stack_order = 1

        super().save(*args, **kwargs)