import os
import json

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_GET, require_POST
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import JsonResponse

from idegeo.GeonodeModels.models import Layers
from .models import IdegeoMap, IdegeoMapLayer


def index(request):
    user = request.user
    is_auth = ""
    userSerialize = {}

    if user.is_authenticated and not user.is_anonymous:
        userSerialize["id"] = user.id
        userSerialize["token"] = user.token
        userSerialize["username"] = user.username
        userSerialize["is_superuser"] = user.is_superuser
        userSerialize["is_staff"] = user.is_staff
        is_auth = "True"

    is_visor = "visor" in request.path

    if is_visor:
        template = "idegeo_maps.html"
    else:
        template = "config_maps.html"

    return render(
        request,
        template,
        {"user_isauth": is_auth, "user": json.dumps(userSerialize)},
    )


@require_GET
@login_required
def list_maps(request):

    page = int(request.GET.get("page", "1"))
    page_size = int(request.GET.get("page_size", "10"))

    qs = IdegeoMap.objects.all()

    # Paginate results
    paginator = Paginator(qs, page_size)
    try:
        maps = paginator.page(page)
    except PageNotAnInteger:
        maps = paginator.page(1)
    except EmptyPage:
        maps = []

    data = [
        {
            "id": map.id,
            "name": map.name,
            "slug": map.slug,
            "owner": map.owner.username,
            "preview": map.preview.url if map.preview else None,
            "createdAt": map.created_at.strftime("%B %d, %Y, %I:%M %p"),
            "owner_id": map.owner.id,
        }
        for map in maps
    ]

    return JsonResponse(
        {
            "total_pages": paginator.num_pages,
            "current_page": page,
            "total_items": paginator.count,
            "results": data,
        },
        safe=False,
    )


@require_GET
@login_required
def list_map_layers(request, map_id):

    qs = IdegeoMapLayer.objects.filter(map__pk=map_id)

    data = [
        {
            "id": layer.id,
            "name": layer.name,
            "style": layer.style,
            "geonode_id": layer.geonode_id,
            "map_position": layer.map_position,
            "opacity": layer.opacity,
            "visibility": layer.visibility,
        }
        for layer in qs
    ]

    return JsonResponse(
        {
            "results": data,
        },
        safe=False,
    )


@require_POST
@login_required
def create_map(request):
    name = request.POST.get("name")
    slug = request.POST.get("slug")

    map_instance = IdegeoMap(name=name, slug=slug, owner=request.user)

    map_instance.save()

    return JsonResponse(
        {"success": True, "mapId": map_instance.id, "mapSlug": map_instance.slug}
    )


@require_POST
@login_required
def delete_map(request, map_id):
    try:
        map_obj = IdegeoMap.objects.get(id=map_id)

        map_obj.delete()

        return JsonResponse({"success": True, "message": "Map deleted successfully"})
    except IdegeoMap.DoesNotExist:
        return JsonResponse({"success": False, "message": "404 Map does not exists"})


@require_GET
def map_data(request, map_slug):
    try:
        map_obj = IdegeoMap.objects.get(slug=map_slug)

        map_data = {
            "id": map_obj.id,
            "name": map_obj.name,
            "slug": map_obj.slug,
            "zoom": map_obj.zoom,
            "center_lat": map_obj.center_lat,
            "center_long": map_obj.center_long,
            "map_type": map_obj.map_type,
            "base_layer": map_obj.base_layer,
            "highlight_color": map_obj.highlight_color,
            "layers": [],
        }

        for l in map_obj.idegeomaplayer_set.all():
            try:
                layer = Layers.objects.get(resourcebase_ptr=l.geonode_id)
                map_data["layers"].append(
                    {
                        "id": l.id,
                        "name": f"{layer.workspace}:{layer.name}",
                        "style": l.style,
                        'styles': [{
                            'name': style.name,
                            'sld_title': style.sld_title,
                            'workspace': style.workspace
                        } for style in layer.styles.all()],
                        "geonode_id": l.geonode_id,
                        "title": layer.resourcebase_ptr.title,
                        "abstract": layer.resourcebase_ptr.abstract,
                        "legend": f'{os.getenv("GEONODE_API_ROOT")}geoserver/ows?service=WMS&request=GetLegendGraphic&format=image/png&WIDTH=20&HEIGHT=20&LAYER=geonode:{layer.name}&STYLE={l.style}&version=1.3.0&sld_version=1.1.0&legend_options=fontAntiAliasing:true;fontSize:14;forceLabels:on;fontColor:808080&transparent=true',
                        "attributes": [
                            {
                                "attribute": a.attribute,
                                "visible": a.visible,
                                "label": a.attribute_label,
                            }
                            for a in layer.attributes
                        ],
                        'extent': layer.resourcebase_ptr.ll_bbox_polygon.extent,
                        'gwc_url': layer.ows_url.replace("ows","gwc/service/wms"),
                        'visibility': l.visibility,
                        'opacity': l.opacity,
                        'map_position': l.map_position,
                        'stack_order': l.stack_order,
                    }
                )
            except Layers.DoesNotExist:
                map_data["layers"].append(
                    {
                        "id": l.id,
                        "name": l.name,
                        "style": l.style,
                        "geonode_id": l.geonode_id,
                        'visibility': l.visibility,
                        'opacity': l.opacity,
                        'map_position': l.map_position,
                        'stack_order': l.stack_order,
                        "error": "Layer not found",
                    }
                )

        return JsonResponse({"success": True, "map_data": map_data})
    except IdegeoMap.DoesNotExist:
        return JsonResponse({"success": False, "message": "404 Map does not exists"})


@require_POST
@login_required
def update_map_data(request, map_id):
    try:
        map_obj = IdegeoMap.objects.get(id=map_id)

        updatable_fields = [
            "name",
            "slug",
            "map_type",
            "highlight_color",
            "base_layer",
            "center_lat",
            "center_long",
            "zoom",
        ]

        for field in updatable_fields:
            value = request.POST.get(field)
            if value is not None:
                setattr(map_obj, field, value)

        preview = request.FILES.get("preview")
        if preview:
            map_obj.preview = preview

        map_obj.save()

        return JsonResponse({"success": True, "message": "Map updated successfully"})
    except IdegeoMap.DoesNotExist:
        return JsonResponse({"success": False, "message": "404 Map does not exist"})


@require_POST
@login_required
def add_layers_to_map(request, map_id):
    try:
        map_obj = IdegeoMap.objects.get(id=map_id)

        value = request.POST.get("layersToAdd")
        if value is not None:
            for layer in json.loads(value):
                map_obj.idegeomaplayer_set.create(
                    style=layer["layerStyle"],
                    name=layer["layerName"],
                    geonode_id=layer["geonodeId"],
                )

        return JsonResponse(
            {"success": True, "message": "Map layers created successfully"}
        )
    except IdegeoMap.DoesNotExist:
        return JsonResponse({"success": False, "message": "404 Map does not exist"})
    

@require_POST
@login_required
def update_map_layers(request):
    try:
        values = request.POST.get("layersToUpdate")
        if values is not None:
            for layer in json.loads(values):
                layer_obj = IdegeoMapLayer.objects.get(id=layer['id'])

                if layer['delete']:
                    layer_obj.delete()
                else:
                    layer_obj.style = layer['style']
                    layer_obj.map_position = layer['map_position']
                    layer_obj.visibility = layer['visibility']
                    layer_obj.opacity = layer['opacity']
                    layer_obj.stack_order = layer['stack_order']

                    layer_obj.save()

        return JsonResponse(
            {"success": True, "message": "Map layers updated successfully"}
        )
    except IdegeoMap.DoesNotExist:
        return JsonResponse({"success": False, "message": "404 Map does not exist"})
