from django.contrib import admin
from idegeo.idegeo_maps.models import *


admin.site.register(IdegeoMap)
admin.site.register(IdegeoMapLayer)