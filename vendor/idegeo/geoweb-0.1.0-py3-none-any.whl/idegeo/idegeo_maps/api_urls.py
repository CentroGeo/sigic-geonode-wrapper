from django.urls import path, re_path
from . import views

urlpatterns = [
  path("list_maps/", views.list_maps, name="list_maps"),
  path("create_map/", views.create_map, name="create_map"),
  path("update_map_layers/", views.update_map_layers, name="update_map_layers"),
  re_path(r'^list_map_layers/(?P<map_id>[^/]*)$', views.list_map_layers, name="list_map_layers"),
  re_path(r'^delete_map/(?P<map_id>[^/]*)$', views.delete_map, name="delete_map"),
  re_path(r'^map_data/(?P<map_slug>[^/]*)$', views.map_data, name="map_data"),
  re_path(r'^update_map_data/(?P<map_id>[^/]*)$', views.update_map_data, name="update_map_data"),
  re_path(r'^add_layers_to_map/(?P<map_id>[^/]*)$', views.add_layers_to_map, name="add_layers_to_map"),
]