from django.apps import AppConfig


class GeoStoriesConfig(AppConfig):
    name = 'idegeo.idegeo_maps'
