from django.apps import AppConfig

class IdegeoBaseConfig(AppConfig):
    name = "idegeo.base"
    label = "idegeo_base"