import os

from django.db import models


def get_upload_path(instance, filename):
    return os.path.join("blog", filename)


class SiteStyle(models.Model):
    ALIGN = (
        ("left", "IZQUIERDA"),
        ("center", "CENTRADO"),
        ("right", "DERECHA"),
    )

    BASEMAPS = (
        ("osm", "Open Street Map"),
        ("gray", "Gris"),
        ("topographic", "Topográfico"),
        ("streets", "Carreteras"),
        ("oceans", "Oceanos"),
        ("shadedRelief", "Relieve"),
        ("imagery", "Satélite"),
        ("darkMatter", "Negro"),
        ("natGeo", "National Geographic"),
        ("satMutant", "Satélite de Google"),
    )

    color_gestion = models.CharField(
        verbose_name="Color de fondo de interfaz y geovisor",
        max_length=250,
        null=True,
        default="#cf8457",
    )
    color = models.CharField(
        verbose_name="Color de footer y botones",
        max_length=250,
        null=True,
        default="#cf8457",
    )

    color_font = models.CharField(
        verbose_name="Color de fondo en encabezados de tema público",
        max_length=250,
        null=True,
        default="rgb(255, 255, 255)",
    )
    logo = models.ImageField(
        verbose_name="Logo en gestión",
        help_text="Nota: El logo aparecerá en todos los encabezados de gestión",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )
    logo_themefst = models.ImageField(
        verbose_name="Primer logo en tema público",
        help_text="Nota: El logo aparecerá al inicio del encabezado de tema público",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )
    link_themefst = models.URLField(
        verbose_name="Enlace del primer logo en tema público", blank=True
    )
    blank_themefst = models.BooleanField(
        verbose_name="Abrir enlace en nueva pestaña", default=False
    )
    logo_themesec = models.ImageField(
        verbose_name="Segundo logo en tema público",
        help_text="Nota:",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )
    link_themesec = models.URLField(
        verbose_name="Enlace del segundo logo en tema público", blank=True
    )
    blank_themesec = models.BooleanField(
        verbose_name="Abrir enlace en nueva pestaña", default=False
    )
    title = models.CharField(
        verbose_name="Título en gestión",
        max_length=300,
        null=True,
        default="Plataforma Geoweb IDEGeo",
    )
    subtitle = models.CharField(
        verbose_name="Subtitulo de gestión",
        max_length=300,
        null=True,
        default="Servicios de Información Geoespacial",
    )
    title_theme = models.CharField(
        verbose_name="Título en tema público",
        max_length=300,
        null=True,
        default="Plataforma Geoweb IDEGeo",
    )
    subtitle_theme = models.CharField(
        verbose_name="Subtitulo en tema público",
        max_length=300,
        null=True,
        default="Servicios de Información Geoespacial",
    )
    font_color = models.CharField(
        verbose_name="Color de titulos y menús en tema público",
        max_length=250,
        null=True,
        default="#FFF",
    )
    text_align = models.CharField(
        verbose_name="Alineacion de titulos en tema público",
        choices=ALIGN,
        max_length=250,
        null=False,
        default="center",
    )
    degradation = models.BooleanField(
        verbose_name="Degradado en encabezado de tema público", default=True
    )
    pattern = models.BooleanField(
        verbose_name="Trama en encabezado de tema público", default=True
    )
    cms = models.BooleanField(
        verbose_name="Usar CMS como home de plataforma", default=False
    )
    cmsHome = models.ForeignKey(
        "content_handler.ManagmentContent",
        verbose_name="Nombre del CMS para home de plataforma",
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    cmsPublic = models.BooleanField(
        verbose_name="Usar menús de CMS para tema público", default=False
    )
    institutional_headband = models.BooleanField(
        verbose_name="Mostrar encabezado y pie de página gobierno de México",
        default=False,
    )
    cmsMenu = models.ForeignKey(
        "content_handler.ManagmentContent",
        verbose_name="Nombre del CMS para menús",
        related_name="menus",
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    vw_keywords = models.BooleanField(
        verbose_name="No mostrar palabras clave en visualizador", default=False
    )
    vw_center = models.CharField(
        verbose_name="Centro del visualizador", max_length=100, blank=False, null=True
    )
    vw_zoom = models.CharField(
        verbose_name="Zoom del visualizador", max_length=100, blank=False, null=True
    )
    basemap = models.CharField(
        verbose_name="Mapa Base",
        choices=BASEMAPS,
        default="osm",
        blank=False,
        max_length=200,
        null=True,
    )
