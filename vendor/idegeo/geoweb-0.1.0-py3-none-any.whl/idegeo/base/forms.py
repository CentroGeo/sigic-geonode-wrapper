from django import forms

from idegeo.base.models import SiteStyle

class InterfaceForm(forms.ModelForm):
    ALIGN = (
        ("left", "IZQUIERDA"),
        ("center", "CENTRADO"),
        ("right", "DERECHA"),
    )

    text_align=forms.ChoiceField(label="Alineacion del texto", choices=ALIGN, widget=forms.RadioSelect())
    class Meta:
        model = SiteStyle
        fields = "__all__"

    def __init__(self, *args, **kwargs):
        super(InterfaceForm, self).__init__(*args, **kwargs)
        self.fields['subtitle_theme'].required = False