import os
import requests
from requests.adapters import HTTPAdapter, Retry
import logging

from django.contrib.auth.backends import ModelBackend
from idegeo.people.models import User

logger = logging.getLogger(__name__)


def get_or_none(classmodel, **kwargs):
    try:
        return classmodel.objects.get(**kwargs)
    except classmodel.DoesNotExist:
        return None

class GeonodeBackend(ModelBackend):

    def create_user(self,username,token,oauth_token,token_expires,geonode_user_id):
        new_user = User.objects.create(
            username=username,
            token=token,
            oauth_token=oauth_token,
            token_expires=token_expires,
            geonode_user_id=geonode_user_id,
            is_staff=True,
            is_superuser=True if username == 'admin' else False,
            ide_access=True if username == 'admin' else False,
            dashboard_access=True if username == 'admin' else False,
            mviewer_access=True if username == 'admin' else False,
            cms_access=True if username == 'admin' else False,
            tmaps_access=True if username == 'admin' else False,
            geostories_access=True if username == 'admin' else False
        )

        return new_user

    def authenticate(self, request, **kwargs):
        session = requests.Session()
        retries = Retry(total=3, backoff_factor=1, status_forcelist=[500, 502, 503, 504])
        session.mount('http://', HTTPAdapter(max_retries=retries))
        session.mount('https://', HTTPAdapter(max_retries=retries))

        username = kwargs['username']
        password = kwargs['password']

        response = None

        try:

            geonode_on_same_host=bool(int(os.environ.get("SAME_HOST_GEONODE","1")))

            if geonode_on_same_host:
                response =  requests.post(
                    "http://host.docker.internal/api-token-auth/",
                    data= {
                        "username" : username,
                        "password" : password
                    },
                    headers={"Host": "127.0.0.1"}
                )
            else:
                response =  requests.post(
                    os.getenv("GEONODE_API_ROOT") + "api-token-auth/",
                    data= {
                        "username" : username,
                        "password" : password
                    },
                )

        except requests.exceptions.RequestException as e:
            logger.error(f"GeoNode auth failed due to network error: {e}")
            return None
        
        if response.status_code == 400:
            logger.warning(f"GeoNode authentication failed for {username}: bad credentials")
            return None

        elif response.status_code == 200:

            user_id = response.json()["user_id"]
            token = response.json()["token"]
            oauth_token = response.json()["geonode_token"]
            expires = response.json()["expires"]

            remote_user = get_or_none(User,geonode_user_id=user_id)

            if not remote_user:
                remote_user = get_or_none(User, username=username)
                if remote_user:
                    remote_user.geonode_user_id = user_id 
                    remote_user.save()

            if not remote_user:
                user = self.create_user(
                    username=username,
                    token=token,
                    oauth_token=oauth_token,
                    token_expires=expires,
                    geonode_user_id=user_id
                )

                return user


            remote_user.token = token
            remote_user.token_expires = expires
            remote_user.oauth_token = oauth_token
            remote_user.save()
            
            return remote_user

                

