import os
import json
from django.shortcuts import render
from django.contrib.auth.decorators import login_required


@login_required
def index(request):
  user = request.user
  is_auth = ''
  userSerialize = {};

  if user.is_authenticated and not user.is_anonymous:
    userSerialize['id'] = user.id
    userSerialize['username'] = user.username
    userSerialize['is_superuser'] = user.is_superuser
    userSerialize['is_staff'] = user.is_staff
    userSerialize['token'] = user.token
    is_auth = 'True'


  return render(request, 'layers_admin.html',{
    'user_isauth': 
    is_auth,'user': json.dumps(userSerialize),
    "apiUrl": os.environ.get("GEONODE_API_ROOT",""),
    "gs_token": os.environ.get("GEOSERVER_ACCESS_TOKEN",""),
  })