import os
from itertools import chain
from idegeo.base.models import SiteStyle
from idegeo.content_handler.models import Header, Style, Menu

def site_styles_processor(request):
    styles = SiteStyle.objects.all()
    site_style = None
    for i in styles:
        site_style = i
    
    public_header = [
        'geovisor',
        'panoramas',
        'catalogo',
        'documentos'
    ]
    if (
        any(view in request.path for view in public_header)
        and site_style is not None
        and site_style.cmsPublic 
        and site_style.cmsMenu is not None
    ):
        home = site_style.cmsMenu
        try:
            header = Header.objects.get(home=site_style.cmsMenu)
        except Header.DoesNotExist:
            pass
        try:
            style = Style.objects.get(header=header)
        except Style.DoesNotExist:
            pass
        topics = (
            Menu.objects.filter(parent_menu=None)
            .filter(home=site_style.cmsMenu)
            .filter(active=True)
            .filter(is_section=False)
            .order_by("stack_order")
        )
        sections = (
            Menu.objects.filter(parent_menu=None)
            .filter(home=site_style.cmsMenu)
            .filter(active=True)
            .filter(is_section=True)
            .order_by("stack_order")
        )
        second_menu = topics.filter(menu_side='2')
        items_list = list(chain(topics))
        return {
            'SiteStyle': site_style,
            'geonode_url': os.environ.get("GEONODE_API_ROOT",""),
            "topics": topics,
            "items_list": items_list,
            "style": style,
            "header": header,
            "home": home,
            "sections": sections,
            "second_menu": second_menu
        }
    else:
        return {
            'SiteStyle': site_style,
            'geonode_url': os.environ.get("GEONODE_API_ROOT",""),
        }
