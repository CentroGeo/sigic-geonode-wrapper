# -*- coding: utf-8 -*-
import os
import json
import requests

from django.http import HttpResponse, JsonResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required
from django.urls import reverse

from idegeo.GeonodeModels.models import Layers
from idegeo.mviewer.models import *
from idegeo.mviewer.forms import *


@login_required
def mviewer_list(request):
    mviewers = MViewer.objects.all()

    return render(request, "list/mviewer_list.html", {"items": mviewers})


def mviewer_public(request):
    mviewers = MViewer.objects.filter(is_public=True)

    return render(request, "list/mviewer_public_list.html", {"items": mviewers})


@login_required
def mviewer_create(request):
    if request.method == "POST":
        mv_form = MViewerForm(request.POST, request.FILES)
        if mv_form.is_valid():
            mv_instance = mv_form.save()
            return HttpResponseRedirect(
                reverse("mviewer_detail", args=[mv_instance.pk])
            )
    else:
        mv_form = MViewerForm()

    return render(
        request,
        "create/mviewer/create_mviewer.html",
        {
            "form": mv_form, 
            "mviewer": json.dumps({"bbox_x0": "a", "logo": "B"}),
            "api_url": os.environ.get("GEONODE_API_ROOT","")
        },
    )


@login_required
def mviewer_metadata(request, mv_id):
    mviewer = get_object_or_404(MViewer, id=mv_id)
    if request.method == "POST":
        mv_form = MViewerFormAll(request.POST, request.FILES, instance=mviewer)
        if mv_form.is_valid():
            mv_form.save()
            return HttpResponseRedirect(reverse("mviewer_detail", args=[mv_id]))
    else:
        mv_form = MViewerForm(instance=mviewer)

    jmviewer = {
        "bbox_x0": str(mviewer.bbox_x0),
        "bbox_y0": str(mviewer.bbox_y0),
        "bbox_x1": str(mviewer.bbox_x1),
        "bbox_y1": str(mviewer.bbox_y1),
        "logo": mviewer.logo,
        "limited_zoom": mviewer.limited_zoom,
        "custome_zoom": mviewer.custome_zoom,
    }

    return render(
        request,
        "create/mviewer/create_mviewer.html",
        {
            "form": mv_form, 
            "mv": mviewer, 
            "api_url": os.environ.get("GEONODE_API_ROOT",""),
            "mviewer": json.dumps(jmviewer)
        },
    )


@login_required
def scenes_list(request, mv_id):
    mviewer = get_object_or_404(MViewer, id=mv_id)
    if request.method == "POST":
        mv_form = SceneForm(request.POST, request.FILES)
        if 'scene' in request.POST:
            scene = MviewerScene.objects.get(id=request.POST['scene'])
            mv_form = SceneForm(request.POST, request.FILES, instance=scene)
        if mv_form.is_valid():
            temp = mv_form.save(commit=False)
            temp.mviewer = mviewer
            temp.save()
            return HttpResponseRedirect(reverse("scenes_list", args=[mv_id]))
    else:
        mv_form = SceneForm()

    return render(
        request,
        "scenes/index.html",
        {
            "mviewer": mviewer,
            "text_panel_size": mviewer.stories_layout_styles["text_panel"],
            "map_panel_size": mviewer.stories_layout_styles["map_panel"],
            "form": mv_form, 
        },
    )


def onoff_layers(user, topics):
    vis_dict = {}
    perm_dict = {}
    for top in topics:
        layer_ids = LayerTopic.objects.filter(topic=top)
        lay_dict = {}
        for e in layer_ids:
            visible = e.visible
            st_order = e.stack_order
            markers = False
            if e.markers.all():
                markers = True
            lay_dict[str(e.id) + "r" + str(st_order)] = {
                "vis": visible,
                "markers": markers,
            }
        vis_dict[top.id] = lay_dict
    return vis_dict, perm_dict


@login_required
def mviewer_detail(request, mv_id):
    mviewer = get_object_or_404(MViewer, id=mv_id)
    try:
        mviewer_header = get_object_or_404(MviewerHeader, mviewer=mviewer)
    except:
        mviewer_header = None
    topics = Topic.objects.filter(mviewer=mv_id).order_by("stack_order")
    sty_dict = {}

    top_index = 1
    for top in topics:
        # Actualiza los campos de LayerTopic
        top_lays = LayerTopic.objects.filter(topic=top).order_by("stack_order")
        index = 1
        for lay in top_lays:
            lay.save()
            index += 1

        top.stack_order = top_index
        top.save()
        top_index += 1

    return render(
        request,
        "detail/mviewer_detail.html",
        {
            "mviewer": mviewer,
            "mviewer_header": mviewer_header,
            "topics": topics,
            "api_url": os.environ.get("GEONODE_API_ROOT",""),
            "sty_dict": json.dumps(sty_dict),
        },
    )


@login_required
def mviewer_remove(request, mv_id, template="mviewer_remove.html"):
    mviewer = get_object_or_404(MViewer, id=mv_id)
    if request.method == "GET":
        return render(request, template, {"mviewer": mviewer})
    if request.method == "POST":
        mviewer.delete()
        return HttpResponseRedirect(reverse("mviewer_list"))
    else:
        return HttpResponse("Not allowed", status=403)


def microviewer(request, url_id):
    dir_conf = {}
    mviewer = get_object_or_404(MViewer, url_id=url_id)
    try:
        mviewer_header = get_object_or_404(MviewerHeader, mviewer=mviewer)
    except:
        mviewer_header = None
    if mviewer.cms:
        menus = mviewer.cms.menu_set.filter(
            parent_menu=None, active=True, is_section=False
        ).order_by("stack_order")
    else:
        menus = None

    topics = Topic.objects.filter(mviewer=mviewer.id).order_by("stack_order")
    tlay_ids = []

    for top in topics:
        tlay_ids += top.layertopic_set.all().values_list("id", flat=True).distinct()

    list_set = set(tlay_ids)
    user = request.user
    vis_dict, perm_dict = onoff_layers(user, topics)
    gjson = {}

    if mviewer.config:
        basemap = mviewer.config
    else:
        basemap = "darkMatter"

    if "Original" in mviewer.template_style:
        template = "panorama/classic/mviewer.html"
    elif "Alternativo" in mviewer.template_style:
        template = "panorama/alternative/mviewerAlt.html"
    else:
        template = "panorama/mviewer.html"

    scene_list = []
    if mviewer.stories_enabled:
        template = "panorama/scenes/index.html"

        for scene in mviewer.mviewerscene_set.all():
            layers = []
            for l in scene.layers.all():
                layers.append({
                    'id': l.id,
                    'name': l.name,
                    'geonode_id': l.layer,
                    'style':  l.style,
                    'ows_url': l.ows_url
                })

            scene_list.append({
                'id': scene.id,
                'zoom': scene.zoom,
                'lat': scene.map_center_lat,
                'lng': scene.map_center_long,
                'text_position': scene.text_position,
                'content': scene.text_content,
                'layers': layers
            })
            

    layers_attributes = {}
    for topic in topics:
        for layer_topic in topic.layertopic_set.all():
            try:
                layer = Layers.objects.get(resourcebase_ptr=layer_topic.layer)
                layers_attributes.update({
                    layer_topic.layer: [
                        {
                            'attribute': a.attribute, 
                            'visible': a.visible,
                            'label': a.attribute_label
                        } for a in layer.attributes
                    ]
                })
                
            except:
                pass
    
    if mviewer.layer_mask:

        if request.user:
            response = requests.get(
                os.environ.get("GEONODE_API_ROOT","") + "api/v2/datasets/" + mviewer.layer_mask,
                headers={
                    "Authorization": "Bearer " + request.user.token
                }
            )
        else:
            response = requests.get(
                os.environ.get("GEONODE_API_ROOT","") + "api/v2/datasets/" + mviewer.layer_mask
            )
        

        if response.status_code == 200 and "dataset" in response.json():
            layer_info = response.json()["dataset"]

            wfs_url = [x for x in layer_info["links"] if x["link_type"] == "OGC:WMS"][0]

            try:
                gjson_layer = requests.get(
                    wfs_url["url"],
                    headers={
                        "Authorization": "Bearer " + request.user.token
                    } if request.user else None,
                    params={
                        "service": "WFS",
                        "version": "1.0.0",
                        "request": "GetFeature",
                        "typename": layer_info["alternate"],
                        "outputFormat": "json",
                        "srs": "EPSG:4326",
                    },
                )

                gjson["gjson_layer"] = gjson_layer.json()

            except:
                print("No gjson found")
                pass

    return render(
        request,
        template,
        {
            "mviewer": mviewer,
            "layer_attributes": json.dumps(layers_attributes),
            "api_url": os.getenv("GEONODE_API_ROOT",""),
            "mviewer_header": mviewer_header,
            "topics": topics,
            "conf_specific": json.dumps(dir_conf),
            "vis_dict": json.dumps(vis_dict),
            "perm_dict": json.dumps(perm_dict),
            "basemap": json.dumps(basemap),
            "layer_mask": json.dumps(gjson),
            "menus": menus,
            "scene_list": json.dumps(scene_list)
        },
    )


def topic_create(request, mv_id):
    if request.method == "POST":
        topic_form = TopicForm(request.POST, request.FILES)
        if topic_form.is_valid():
            num = Topic.objects.filter(mviewer=mv_id).count()
            if num >= 7:
                try:
                    mv = get_object_or_404(MViewer, id=mv_id)
                    if mv.template_style in ["Alternativo_1", "Alternativo_2", "Alternativo_3", "Alternativo_4"]:
                        if num > 50:
                            return HttpResponse("Limite excedido")
                    else:
                        if (
                            mv.is_vertical != True
                        ):  # solamente si el panel no esta activado puedes pasar el límite de tematicas
                            return HttpResponse("Limite excedido")
                        else:
                            if (
                                num > 20
                            ):  # vamos a poner un límite de 15 tematicas para el panel izquierdo
                                return HttpResponse("Limite excedido")
                except:
                    pass
            index = num + 1
            new_topic = topic_form.save(commit=False)
            new_topic.mviewer = get_object_or_404(MViewer, id=mv_id)
            new_topic.stack_order = index
            new_topic.save()
            return HttpResponseRedirect(reverse("mviewer_detail", args=[mv_id]))
    else:
        topic_form = TopicForm()

    return render(request, "create/topic/topic_metadata.html", {"form": topic_form, "mvid": mv_id})


def topic_metadata(request, mv_id, top_id):
    topic = get_object_or_404(Topic, id=top_id)
    if request.method == "POST":
        topic_form = TopicForm(request.POST, request.FILES, instance=topic)
        if topic_form.is_valid():
            topic_form.save()
            return HttpResponseRedirect(reverse("mviewer_detail", args=[mv_id]))
    else:
        topic_form = TopicForm(instance=topic)
    return render(request, "create/topic/topic_metadata.html", {"form": topic_form, "mvid": mv_id})


def topic_remove(request, mv_id, top_id):
    topic = get_object_or_404(Topic, id=top_id)
    if request.method == "GET":
        topic.delete()
        return HttpResponseRedirect(reverse("mviewer_detail", args=[mv_id]))
    else:
        return HttpResponse("Not allowed", status=403)


def edit_layer_narrative(request, mv_id, reg_id):
    layerid = get_object_or_404(LayerTopic, id=reg_id)
    if request.method == "POST":
        layerid_form = LayerNarrativeForm(request.POST, instance=layerid)
        if layerid_form.is_valid():
            layerid_form.save()
            return HttpResponseRedirect(reverse("mviewer_detail", args=[mv_id]))
    else:
        layerid_form = LayerNarrativeForm(instance=layerid)
    return render(
        request,
        "create/layer_narrative/layer_narrative.html",
        {"form": layerid_form, "mvid": mv_id, "layerid": layerid},
    )


def add_layer_markers(request, mv_id, reg_id):
    layerid = get_object_or_404(LayerTopic, id=reg_id)
    marker_narrative_form = MarkerNarrativeForm()
    marker_icon_form = MarkerIconForm()
    markers = layerid.markers.all()
    markers_dict = []

    for m in markers:
        if m.options:
            options = json.loads(m.options)
            color = options["color"]
            if "shape" in options:
                shape = options["shape"]
            else:
                shape = "circle"
            if "transparent" in options:
                transparent = options["transparent"]
            else:
                transparent = "false"
        else:
            color = "#df1e1e"
            shape = "circle"
            transparent = "false"
        markers_dict.append(
            {
                "id": m.id,
                "lat": str(m.lat),
                "lng": str(m.lng),
                "title": m.title,
                "narrative": m.narrative,
                "icon_name": m.icon.name if m.icon else None,
                "icon_prefix": m.icon.style_prefix if m.icon else None,
                "color": color,
                "shape": shape,
                "transparent": transparent,
            }
        )

    lay_data = {
        "id": layerid.id,
        "layer_pk": layerid.layer,
        "name": layerid.name,
        "style": layerid.style,
        "ows": layerid.ows_url,
    }

    return render(
        request,
        "create/layer_markers/layerid_markers.html",
        {
            "layer": layerid.layer,
            "api_url": os.environ.get("GEONODE_API_ROOT",""),
            "form": marker_narrative_form,
            "icon_form": marker_icon_form,
            "mvid": mv_id,
            "layerid": json.dumps(lay_data),
            "markers": json.dumps(markers_dict),
        },
    )


### Vistas para Ajax ###
def add_topic_layers(request):
    if request.method == 'POST':
        add_data = json.load(request)
        topic_id = add_data["topic_id"]
        layer_data = add_data["layer_data"]
        added_ids = {}
        topic = get_object_or_404(Topic, id=topic_id)
        top_elem = LayerTopic.objects.filter(topic=topic)
        index = len(top_elem) + 1

        r = LayerTopic(
            topic=topic, 
            layer=layer_data["pk"], 
            name=layer_data["name"],
            title=layer_data["title"],
            ows_url=layer_data["ows_url"],
            style=layer_data["style"],
            style_title=layer_data["style_title"]
        )

        r.stack_order = index
        r.save()

        added_layer = {'layer_id': r.id, 'st_order': index, 'style': layer_data["style"], 'reg_id' : r.id, 'name': layer_data["title"] }


        return JsonResponse(added_layer)
    else:
        return HttpResponse("Not ajax request")


def remove_topic_layer(request):
    if request.method == 'POST':
        layer_id = json.load(request)["layer_id"]
        r = get_object_or_404(LayerTopic, id=layer_id)
        r.delete()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def set_layer_style(request):
    if request.method == 'POST':
        data = json.loads(request.body.decode('utf-8'))
        layer_id = data["layer_id"]
        style = data["style"]
        style_title = data["style_title"]
        r = get_object_or_404(LayerTopic, id=layer_id)
        r.style = style
        r.style_title = style_title
        r.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def tlayer_on(request):
    if request.method == 'POST':
        layer_id = json.load(request)["layer_id"]
        topic_layer = get_object_or_404(LayerTopic, id=layer_id)
        topic_layer.visible = True
        topic_layer.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def tlayer_off(request):
    if request.method == 'POST':
        layer_id = json.load(request)["layer_id"]
        topic_layer = get_object_or_404(LayerTopic, id=layer_id)
        topic_layer.visible = False
        topic_layer.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def sort_topic(request):
    if request.method == 'POST':
        sorted_ids = json.load(request)["sorted_ids"]
        st_order = 1
        for e in sorted_ids:
            topic = get_object_or_404(Topic, id=int(e))
            topic.stack_order = st_order
            topic.save()
            st_order += 1

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def sort_layer(request):
    if request.method == 'POST':
        sorted_ids = json.load(request)["sorted_ids"]
        st_order = 1
        for e in sorted_ids:
            layer = get_object_or_404(LayerTopic, id=int(e))
            layer.stack_order = st_order
            layer.save()
            st_order += 1

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def has_layer_tool(request):
    if request.method == 'GET':
        regid = request.GET["regid"]
        r = get_object_or_404(LayerTopic, id=regid)
        tools_flag = r.sos_layers_mv.all().exists()
        markers_flag = r.markers.all().exists()
        narrative_flag = False
        if r.narrative:
            narrative_flag = True

        flags_dict = {
            "tflag": tools_flag,
            "nflag": narrative_flag,
            "mflag": markers_flag,
        }

        return JsonResponse(flags_dict)
    else:
        return HttpResponse("Not ajax request")


def get_layer_narrative(request):
    if request.method == 'GET':
        regid = request.GET["regid"]
        r = get_object_or_404(LayerTopic, id=regid)
        narrative = r.narrative

        return JsonResponse({ "narrative": narrative })
    else:
        return HttpResponse("Not ajax request")


def add_layerid_marker(request):
    if request.method == 'GET':
        regid = request.GET["regid"]
        lat = request.GET["lat"]
        lng = request.GET["lng"]

        marker = LayeridMarker(lat=lat, lng=lng)
        marker.save()
        r = get_object_or_404(LayerTopic, id=regid)
        r.markers.add(marker)

        return JsonResponse({ "marker_id": marker.id })
    else:
        return HttpResponse("Not ajax request")


def remove_layerid_marker(request):
    if request.method == 'GET':
        regid = request.GET["regid"]
        marker_id = request.GET["marker_id"]

        marker = get_object_or_404(LayeridMarker, id=marker_id)
        r = get_object_or_404(LayerTopic, id=regid)
        r.markers.remove(marker)
        marker.delete()

        return JsonResponse({ "marker_id": marker.id })
    else:
        return HttpResponse("Not ajax request")


def add_marker_narrative(request):
    if request.method == 'POST':
        title = request.POST["title"]
        content = request.POST["content"]
        marker_id = request.POST["marker_id"]

        marker = get_object_or_404(LayeridMarker, id=marker_id)
        marker.title = title
        marker.narrative = content
        marker.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def change_marker_position(request):
    if request.method == 'GET':
        markid = request.GET["markid"]
        lat = request.GET["lat"]
        lng = request.GET["lng"]
        marker = get_object_or_404(LayeridMarker, id=markid)
        marker.lat = lat
        marker.lng = lng
        marker.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def change_icon_marker(request):
    if request.method == 'POST':
        marker_id = request.POST["marker_id"]
        icon = request.POST["icon"]
        color = request.POST["color"]
        shape = request.POST["shape"]
        transparent = request.POST["transparent"]

        marker = get_object_or_404(LayeridMarker, id=marker_id)
        marker.icon = icon
        marker.options = json.dumps(
            {"color": color, "shape": shape, "transparent": transparent}
        )
        marker.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def layerid_markers(request):
    if request.method == 'GET':
        regid = request.GET["regid"]

        layerid = get_object_or_404(LayerTopic, id=regid)
        markers = layerid.markers.all()
        markers_dict = []

        for m in markers:
            if m.options:
                options = json.loads(m.options)
                color = options["color"]
                if "shape" in options:
                    shape = options["shape"]
                else:
                    shape = "circle"
                if "transparent" in options:
                    transparent = options["transparent"]
                else:
                    transparent = "false"
            else:
                color = "#df1e1e"
                shape = "circle"
                transparent = "false"
            markers_dict.append(
                {
                    "id": m.id,
                    "lat": str(m.lat),
                    "lng": str(m.lng),
                    "title": m.title,
                    "narrative": m.narrative,
                    "icon_name": m.icon.name if m.icon else None,
                    "icon_prefix": m.icon.style_prefix if m.icon else None,
                    "color": color,
                    "shape": shape,
                    "transparent": transparent,
                }
            )

        return JsonResponse({ "markers": markers_dict })
    else:
        return HttpResponse("Not ajax request")


@login_required
def upload_mviewer_header(request, mv_id):
    mviewer = MViewer.objects.get(id=mv_id)
    if request.method == "POST":
        header_form = MviewerHeaderForm(request.POST, request.FILES)
        if header_form.is_valid():
            temp = header_form.save(commit=False)
            temp.mviewer = mviewer
            temp.save()
            return HttpResponseRedirect(reverse("mviewer_detail", args=[mv_id]))
    else:
        header_form = MviewerHeaderForm()
    return render(
        request, "create/header/mviewer_header.html", {"form": header_form, "mviewer": mviewer}
    )


@login_required
def edit_mviewer_header(request, header_id):
    header = MviewerHeader.objects.get(id=header_id)
    if request.method == "POST":
        header_form = MviewerHeaderForm(request.POST, request.FILES, instance=header)
        if header_form.is_valid():
            header_form.save()
            return HttpResponseRedirect(
                reverse("mviewer_detail", args=[header.mviewer.id])
            )
    else:
        header_form = MviewerHeaderForm(instance=header)
    return render(
        request, "create/header/mviewer_header.html", {"form": header_form, "header": header}
    )


@login_required
def create_text_topic(request, mv_id):
    mv_instance = get_object_or_404(MViewer, id=mv_id)
    top_elem = TopicText.objects.filter(mviewer=mv_instance)
    index = top_elem.count() + 1 

    if request.method == "POST":
        topicForm = TopicTextForm(request.POST, request.FILES)
        if topicForm.is_valid():
            tmp = topicForm.save(commit=False)
            tmp.mviewer = mv_instance
            tmp.stack_order = index
            tmp.save()
            return HttpResponseRedirect(
                reverse("mviewer_detail", args=[mv_instance.id])
            )
    else:
        topicForm = TopicTextForm()

    return render(
        request, "create/topic/topic_text.html", {"form": topicForm, "mvid": mv_instance.id}
    )


@login_required
def update_text_topic(request, topictext_id):
    topic_text_instance = TopicText.objects.get(id=topictext_id)
    if request.method == "POST":
        topicForm = TopicTextForm(
            request.POST, request.FILES, instance=topic_text_instance
        )
        if topicForm.is_valid():
            topicForm.save()
            return HttpResponseRedirect(
                reverse("mviewer_detail", args=[topic_text_instance.mviewer.id])
            )
    else:
        topicForm = TopicTextForm(instance=topic_text_instance)

    return render(
        request,
        "create/topic/topic_text.html",
        {"form": topicForm, "mvid": topic_text_instance.mviewer.id},
    )


@login_required
def delete_text_topic(request, topictext_id):
    mviewer_id = TopicText.objects.get(id=topictext_id).mviewer.id
    TopicText.objects.get(id=topictext_id).delete()

    return HttpResponseRedirect(reverse("mviewer_detail", args=[mviewer_id]))


@login_required
def create_text_topic_item(request, topictext_id):
    topic_text_instance = get_object_or_404(TopicText, id=topictext_id)
    
    existing_items_count = TopicTextItems.objects.filter(topic_text=topic_text_instance).count()
    index = existing_items_count + 1
    
    if request.method == "POST":
        topicForm = TopicTextItemForm(request.POST, request.FILES)
        if topicForm.is_valid():
            tmp = topicForm.save(commit=False)
            tmp.topic_text = topic_text_instance
            tmp.stack_order = index
            tmp.save()
            return HttpResponseRedirect(
                reverse("mviewer_detail", args=[topic_text_instance.mviewer.id])
            )
    else:
        topicForm = TopicTextItemForm()

    return render(
        request,
        "create/topic/topic_text_item.html",
        {"form": topicForm, "mvid": topic_text_instance.mviewer.id},
    )


@login_required
def update_text_topic_item(request, topictextitem_id):
    topic_text_instance = TopicTextItems.objects.get(id=topictextitem_id)
    if request.method == "POST":
        topicForm = TopicTextItemForm(
            request.POST, request.FILES, instance=topic_text_instance
        )
        if topicForm.is_valid():
            topicForm.save()
            return HttpResponseRedirect(
                reverse(
                    "mviewer_detail", args=[topic_text_instance.topic_text.mviewer.id]
                )
            )
    else:
        topicForm = TopicTextItemForm(instance=topic_text_instance)

    return render(
        request,
        "create/topic/topic_text_item.html",
        {"form": topicForm, "mvid": topic_text_instance.topic_text.mviewer.id},
    )


@login_required
def delete_text_topic_item(request, topictextitem_id):
    mviewer_id = TopicTextItems.objects.get(id=topictextitem_id).topic_text.mviewer.id
    TopicTextItems.objects.get(id=topictextitem_id).delete()

    return HttpResponseRedirect(reverse("mviewer_detail", args=[mviewer_id]))


def sort_text_topic(request):
    if request.method == 'POST':
        sorted_ids = json.load(request)["sorted_ids"]
        st_order = 1
        for e in sorted_ids:
            topic = get_object_or_404(TopicText, id=int(e))
            topic.stack_order = st_order
            topic.save()
            st_order += 1

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def sort_text_topic_item(request):
    if request.method == 'POST':
        sorted_ids = json.load(request)["sorted_ids"]
        st_order = 1
        for e in sorted_ids:
            topic = get_object_or_404(TopicTextItems, id=int(e))
            topic.stack_order = st_order
            topic.save()
            st_order += 1

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def create_external_layer(request):
    if request.method == 'POST':
        data = json.load(request)

        mviewer = get_object_or_404(MViewer, id=data["mviewer"])
        name = data["name"]
        url = data["url"]
        attribution = data["attribution"]
        wms_or_tile = data["wms_or_tile"]
        wms_layers = data["wms_layers"]
        at_start = data["at_start"]

        instance = ExternalWMS(
            mviewer=mviewer,
            name=name,
            url=url,
            attribution=attribution,
            wms_or_tile=wms_or_tile,
            wms_layers=wms_layers,
            at_start=at_start
        )
        instance.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")
    

def edit_external_layer(request):
    if request.method == 'POST':
        data = json.load(request)

        external_layer = get_object_or_404(ExternalWMS, id=data["id"])
        external_layer.name = data["name"]
        external_layer.url = data["url"]
        external_layer.attribution = data["attribution"]
        external_layer.wms_or_tile = data["wms_or_tile"]
        external_layer.wms_layers = data["wms_layers"]
        external_layer.at_start = data["at_start"]

        external_layer.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def delete_external_layer(request):
    if request.method == 'POST':
        data = json.load(request)
        external_layer = get_object_or_404(ExternalWMS, id=data['id'])
        
        external_layer.delete()
        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")
    

def enable_scenes(request,mv_id):
    mviewer = get_object_or_404(MViewer, id=mv_id)
    if request.method == "GET":
        mviewer.stories_enabled = True
        mviewer.save()
        return HttpResponseRedirect(reverse("mviewer_detail", args=[mv_id]))
    else:
        return HttpResponse("Not ajax request")
    
def disable_scenes(request,mv_id):
    mviewer = get_object_or_404(MViewer, id=mv_id)
    if request.method == "GET":
        mviewer.stories_enabled = False
        mviewer.save()
        return HttpResponseRedirect(reverse("mviewer_detail", args=[mv_id]))
    else:
        return HttpResponse("Not ajax request")


def delete_scene(request):
    if request.method == 'POST':
        data = json.load(request)
        scene = get_object_or_404(MviewerScene, id=data['id'])
        
        scene.delete()
        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def change_scene_order(request):
    if request.method == 'POST':
        data = json.load(request)
        scenes = data['scenes']
        
        for count, value in enumerate(scenes):
            scene = get_object_or_404(MviewerScene, id=value)
            scene.stack_order = count
            scene.save()
        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")


def add_layer_to_scene(request):
    if request.method == 'POST':
        data = json.load(request)

        scene = get_object_or_404(MviewerScene, id=data["id"])
        scene.map_center_lat = data["lat"]
        scene.map_center_long = data["lng"]
        scene.zoom = data["zoom"]

        layers = data["layers"]

        for l in scene.layers.all():
            if l.id not in layers:
                scene.layers.remove(l)

        for l in layers:
            layer = get_object_or_404(LayerTopic, id=l)
            if layer not in scene.layers.all():
                scene.layers.add(layer)

        scene.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")
    

def add_remove_tool_from_mviewer(request):
    if request.method == 'POST':
        data = json.load(request)

        mviewer = get_object_or_404(MViewer, id=data["id"])
        action = data["action"]

        if action == 'create':
            tool_name = data["tool"]
            mviewer_tool = MviewerTools(
                mviewer=mviewer,
                tool=tool_name
            )
            mviewer_tool.save()

        else:
            tool_name = data["tool"]
            tool = mviewer.mviewertools_set.get(tool=tool_name)
            tool.delete()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Not ajax request")

@login_required
@require_POST
def update_mviewer_scene_styles(request,mv_id):
    try:
        mv = MViewer.objects.get(id=mv_id)

        text_panel = int(request.POST.get("text-panel", 40))
        map_panel = int(request.POST.get("map-panel", 60))

        mv.stories_layout_styles = {
            "text_panel": text_panel,
            "map_panel": map_panel,
        }
        mv.save()

        return JsonResponse({"success": True})

    except MViewer.DoesNotExist:
        return JsonResponse({"success": False, "error": "Scene not found."}, status=404)
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=400)