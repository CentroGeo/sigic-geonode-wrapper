from django.contrib import admin
from .models import MViewer, Topic, LayerTopic, LayeridMarker,TopicText

admin.site.register(MViewer)
admin.site.register(Topic)
admin.site.register(LayerTopic)
admin.site.register(LayeridMarker)
admin.site.register(TopicText)