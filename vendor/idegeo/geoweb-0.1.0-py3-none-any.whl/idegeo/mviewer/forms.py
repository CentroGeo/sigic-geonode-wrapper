
from django.forms import ModelForm
from django import forms
from ckeditor_uploader.widgets import CKEditorUploadingWidget
from idegeo.middleware import UserMiddleware
from idegeo.mviewer.models import (
    MViewer,
    Topic,
    LayerTopic,
    LayeridMarker,
    MviewerHeader,
    TopicText,
    TopicTextItems,
    MviewerScene
)

class MViewerForm(ModelForm):
    template_style = forms.ChoiceField(
        label='Seleccionar el tema del panorama',
        choices=MViewer.TEMA
    )
    template_use = forms.ChoiceField(
        label='Seleccione la configuracion del panorama',
        choices=MViewer.USE
    )
    
    description = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'), required=False)
    extra_info = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        user = UserMiddleware.get_current_user()

        self.fields['bbox_x0'].widget.attrs['readonly'] = True
        self.fields['bbox_y0'].widget.attrs['readonly'] = True
        self.fields['bbox_x1'].widget.attrs['readonly'] = True
        self.fields['bbox_y1'].widget.attrs['readonly'] = True

        if user and user.is_superuser:
            self.fields['description'].widget = CKEditorUploadingWidget(config_name='default')
            self.fields['extra_info'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = MViewer
        exclude = ['logo', 'wms_services', 'limited_zoom', 'stories_enabled', 'stories_layout_styles']


class TopicForm(ModelForm):
    class Meta:
        model = Topic
        exclude = ['mviewer', 'layer_ids', 'stack_order']


class MViewerFormAll(ModelForm):
    description = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'), required=False)
    extra_info = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        user = UserMiddleware.get_current_user()
        self.fields['bbox_x0'].widget.attrs['readonly'] = True
        self.fields['bbox_y0'].widget.attrs['readonly'] = True
        self.fields['bbox_x1'].widget.attrs['readonly'] = True
        self.fields['bbox_y1'].widget.attrs['readonly'] = True
        
        if user and user.is_superuser:
            self.fields['description'].widget = CKEditorUploadingWidget(config_name='default')
            self.fields['extra_info'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = MViewer
        exclude = ['stories_enabled', 'stories_layout_styles']


class LayerNarrativeForm(ModelForm):
    narrative = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['narrative'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = LayerTopic
        fields = ('narrative',)


class MarkerNarrativeForm(ModelForm):
    narrative = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['narrative'].widget = CKEditorUploadingWidget(config_name='default')
    class Meta:
        model = LayeridMarker
        fields = ('title', 'narrative')


class MarkerIconForm(ModelForm):
    class Meta:
        model = LayeridMarker
        fields = ('icon',)


class MviewerHeaderForm(ModelForm):
    class Meta:
        model = MviewerHeader
        exclude = ['mviewer']


class TopicTextForm(ModelForm):
    class Meta:
        model = TopicText
        exclude = ['mviewer','stack_order']

class TopicTextItemForm(ModelForm):
    contents = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['contents'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = TopicTextItems
        exclude = ['topic_text','stack_order'] 

        
class SceneForm(ModelForm):
    text_content = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['text_content'].widget = CKEditorUploadingWidget(config_name='default')
    class Meta:
        model = MviewerScene
        fields = (
            'name',
            'text_content',
            'text_position',
        )