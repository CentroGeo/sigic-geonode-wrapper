from django.urls import re_path

from . import views

urlpatterns = [
    re_path(r"^$", views.mviewer_list, name="mviewer_list"),
    re_path(r"^public/$", views.mviewer_public, name="mviewer_public"),
    re_path(r"^create/$", views.mviewer_create, name="mviewer_create"),
    re_path(
        r"^header/(?P<mv_id>\d+)$",
        views.upload_mviewer_header,
        name="upload_mviewer_header",
    ),
    re_path(
        r"^editar_encabezado/(?P<header_id>\d+)$",
        views.edit_mviewer_header,
        name="edit_mviewer_header",
    ),
    re_path(r"^metadata/(?P<mv_id>\d+)$", views.mviewer_metadata, name="mviewer_metadata"),
    re_path(r"^detail/(?P<mv_id>\d+)$", views.mviewer_detail, name="mviewer_detail"),
    re_path(r"^remove/(?P<mv_id>\d+)$", views.mviewer_remove, name="mviewer_remove"),
    re_path(r"^(?P<url_id>[-\w]+)$", views.microviewer, name="microviewer"),
    re_path(r"^topic_create/(?P<mv_id>\d+)$", views.topic_create, name="topic_create"),
    re_path(
        r"^topic_metadata/(?P<mv_id>\d+)/(?P<top_id>\d+)$",
        views.topic_metadata,
        name="topic_metadata",
    ),
    re_path(
        r"^topic_remove/(?P<mv_id>\d+)/(?P<top_id>\d+)$",
        views.topic_remove,
        name="topic_remove",
    ),
    re_path(
        r"^edit_layer_narrative/(?P<mv_id>\d+)/(?P<reg_id>\d+)$",
        views.edit_layer_narrative,
        name="edit_layer_narrative",
    ),
    re_path(
        r"^add_layer_markers/(?P<mv_id>\d+)/(?P<reg_id>\d+)$",
        views.add_layer_markers,
        name="add_layer_markers",
    ),
    re_path(
        r"^topic_text_create/(?P<mv_id>\d+)$",
        views.create_text_topic,
        name="create_text_topic",
    ),
    re_path(
        r"^topic_text_update/(?P<topictext_id>\d+)$",
        views.update_text_topic,
        name="update_text_topic",
    ),
    re_path(
        r"^topic_text_remove/(?P<topictext_id>\d+)$",
        views.delete_text_topic,
        name="delete_text_topic",
    ),
    re_path(
        r"^topic_text_item_create/(?P<topictext_id>\d+)$",
        views.create_text_topic_item,
        name="create_text_topic_item",
    ),
    re_path(
        r"^topic_text_item_update/(?P<topictextitem_id>\d+)$",
        views.update_text_topic_item,
        name="update_text_topic_item",
    ),
    re_path(
        r"^topic_text_item_remove/(?P<topictextitem_id>\d+)$",
        views.delete_text_topic_item,
        name="delete_text_topic_item",
    ),
    # Vistas Ajax
    re_path(r"^add_topic_layers/$", views.add_topic_layers, name="add_topic_layers"),
    re_path(r"^remove_topic_layer/$", views.remove_topic_layer, name="remove_topic_layer"),
    re_path(r"^tlayer_on/$", views.tlayer_on, name="tlayer_on"),
    re_path(r"^tlayer_off/$", views.tlayer_off, name="tlayer_off"),
    re_path(r"^set_layer_style/$", views.set_layer_style, name="set_layer_style"),
    re_path(r"^sort_topic/$", views.sort_topic, name="sort_topic"),
    re_path(r"^sort_layer/$", views.sort_layer, name="sort_layer"),
    re_path(r"^has_layer_tool/$", views.has_layer_tool, name="has_layer_tool"),
    re_path(r"^get_layer_narrative/$", views.get_layer_narrative, name="get_layer_narrative"),
    re_path(r"^add_layerid_marker/$", views.add_layerid_marker, name="add_layerid_marker"),
    re_path(
        r"^remove_layerid_marker/$",
        views.remove_layerid_marker,
        name="remove_layerid_marker",
    ),
    re_path(
        r"^add_marker_narrative/$", views.add_marker_narrative, name="add_marker_narrative"
    ),
    re_path(r"^change_icon_marker/$", views.change_icon_marker, name="change_icon_marker"),
    re_path(
        r"^change_marker_position/$",
        views.change_marker_position,
        name="change_marker_position",
    ),
    re_path(r"^layerid_markers/$", views.layerid_markers, name="layerid_markers"),
    re_path(r"^sort_text_topic/$", views.sort_text_topic, name="sort_text_topic"),
    re_path(
        r"^sort_text_topic_element/$",
        views.sort_text_topic_item,
        name="sort_text_topic_item",
    ),
    re_path(r"^create_external_layer/$", views.create_external_layer, name="create_external_layer"),
    re_path(r"^edit_external_layer/$", views.edit_external_layer, name="edit_external_layer"),
    re_path(r"^delete_external_layer/$", views.delete_external_layer, name="delete_external_layer"),
    re_path(r"^enable_scenes/(?P<mv_id>\d+)$", views.enable_scenes, name="enable_scenes"),
    re_path(r"^update-scene-styles/(?P<mv_id>\d+)$", views.update_mviewer_scene_styles, name="update_mviewer_scene_styles"),
    re_path(r"^disable_scenes/(?P<mv_id>\d+)$", views.disable_scenes, name="disable_scenes"),
    re_path(r"^escenas/(?P<mv_id>\d+)$", views.scenes_list, name="scenes_list"),
    re_path(r"^add_layer_to_scene/$", views.add_layer_to_scene, name="add_layer_to_scene"),
    re_path(r"^delete_scene/$", views.delete_scene, name="delete_scene"),
    re_path(r"^change_scene_order/$", views.change_scene_order, name="change_scene_order"),
    re_path(r"^add_remove_tool_from_mviewer/$", views.add_remove_tool_from_mviewer, name="add_remove_tool_from_mviewer"),
]
