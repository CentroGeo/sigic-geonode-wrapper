from django.urls import re_path

from . import views

urlpatterns = [
    re_path(r"^(?P<url_id>[-\w]+)$", views.tmap, name="tmap"),
    re_path(r"^$", views.tmaps_list, name="tmaps_list"),
    re_path(r"^create/$", views.tmap_create, name="tmap_create"),
    re_path(r"^metadata/(?P<mv_id>\d+)$", views.tmap_metadata, name="tmap_metadata"),
    re_path(r"^detail/(?P<mv_id>\d+)$", views.tmap_detail, name="tmap_detail"),
    re_path(r"^remove/(?P<mv_id>\d+)$", views.tmap_remove, name="tmap_remove"),
    re_path(r"^header/(?P<mv_id>\d+)$", views.tmap_create_header, name="tmap_create_header"),
    re_path(
        r"^edit_header/(?P<header_id>\d+)$", views.tmap_edit_header, name="tmap_edit_header"
    ),
    re_path(
        r"^topic_create/(?P<mv_id>\d+)$", views.tmap_topic_create, name="tmap_topic_create"
    ),
    re_path(
        r"^topic_metadata/(?P<mv_id>\d+)/(?P<top_id>\d+)$",
        views.tmap_topic_metadata,
        name="tmap_topic_metadata",
    ),
    re_path(
        r"^topic_remove/(?P<mv_id>\d+)/(?P<top_id>\d+)$",
        views.tmap_topic_remove,
        name="tmap_topic_remove",
    ),
    re_path(
        r"^edit_narrative/(?P<mv_id>\d+)/(?P<reg_id>\d+)$",
        views.tmap_edit_narrative,
        name="tmap_edit_narrative",
    ),
    re_path(
        r"^add_markers/(?P<mv_id>\d+)/(?P<reg_id>\d+)$",
        views.tmap_add_markers,
        name="tmap_add_markers",
    ),
    re_path(
        r"^add_doc_related/(?P<mv_id>\d+)/(?P<reg_id>\d+)$",
        views.tmap_add_doc,
        name="tmap_add_doc",
    ),
    # Vistas Ajax
    re_path(r"^add_topic_maps/$", views.add_topic_maps, name="add_topic_maps"),
    re_path(r"^remove_topic_map/$", views.remove_topic_map, name="remove_topic_map"),
    re_path(r"^tmap_on/$", views.tmap_on, name="tmap_on"),
    re_path(r"^tmap_sort_topic/$", views.tmap_sort_topic, name="tmap_sort_topic"),
    re_path(r"^sort_map/$", views.sort_map, name="sort_map"),
    re_path(r"^get_tmap_narrative/$", views.get_tmap_narrative, name="get_tmap_narrative"),
    re_path(r"^add_mapid_marker/$", views.add_mapid_marker, name="add_mapid_marker"),
    re_path(r"^remove_mapid_marker/$", views.remove_mapid_marker, name="remove_mapid_marker"),
    re_path(
        r"^add_tmap_marker_narrative/$",
        views.add_tmap_marker_narrative,
        name="add_tmap_marker_narrative",
    ),
    re_path(
        r"^change_tmap_icon_marker/$",
        views.change_tmap_icon_marker,
        name="change_tmap_icon_marker",
    ),
    re_path(
        r"^change_tmap_marker_position/$",
        views.change_tmap_marker_position,
        name="change_tmap_marker_position",
    ),
    re_path(r"^mapid_markers/$", views.mapid_markers, name="mapid_markers"),
]
