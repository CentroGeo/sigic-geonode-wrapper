# -*- coding: utf-8 -*-
from django.core import validators
from django.db import models
from fontawesome_6.fields import IconField
from ckeditor_uploader.fields import RichTextUploadingField

from idegeo.GeonodeModels.models import Map
from idegeo.base.related import GeonodeForeignKey
from idegeo.content_handler.models import ManagmentContent

class TMap(models.Model):

    TEMA = (
        ('Alternativo_2', 'Oscuro sin nombre de temática'),
        ('Alternativo_1', 'Oscuro con nombre de temática'),
        ('Alternativo_4', 'Claro sin nombre de temática'),
        ('Alternativo_3', 'Claro con nombre de temática')
    )
    
    USE = (
        ('light', 'Sin título y menú'), 
        ('normal', 'Solo título'), 
        ('full', 'Con título y menú')
    )
    
    name = models.CharField(
        verbose_name="Nombre",
        max_length=200
    )

    url_id = models.CharField(
        validators=[validators.validate_slug],
        verbose_name="Identificador de la colección de mapas (/tmaps/[identificador])",
        help_text='El identificador no puede tener espacios, caracteres especiales, ni arrobas',
        max_length=20, unique=True, blank=False, null=True
    )
    
    is_public = models.BooleanField(
        default=False,
        verbose_name="Es público",
        help_text='Activar para publicar la colección de mapas.'
    )
    
    template_style = models.CharField(
        max_length=250,
        default='Alternativo_1',
        verbose_name="Seleccionar el tema de la interfaz gráfica de la colección."
    )
    
    icon_title = models.BooleanField(
        default=False,
        verbose_name="Mostrar nombre de temática"
    )

    image = models.ImageField(
        verbose_name="Imagen",
        upload_to="images/",
        null=True,
        blank=True
    )

    template_use = models.CharField(
        max_length=250,
        default='normal',
        verbose_name="Seleccione la configuración del panorama"
    )

    cms = models.ForeignKey(
        ManagmentContent,
        verbose_name="CMS asociado",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )

    description = RichTextUploadingField(
        verbose_name="Descripcion",
        blank=True,
        null=True
    )

    creation_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.name


class Topic(models.Model):

    tmap = models.ForeignKey(
        TMap,
        verbose_name="Mapa por categorias",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )

    name = models.CharField(
        verbose_name="Nombre",
        max_length=40
    )

    description = models.TextField(
        verbose_name="Descripcion",
        max_length=200
    )

    icon = IconField(
        default='info',
        verbose_name="Icono"
    )

    custom_icon = models.ImageField(
        verbose_name="Icono Personalizado",
        upload_to="images/",
        null=True,
        blank=True
    )

    stack_order = models.IntegerField(
        null=True,
        blank=True
    )

    creation_date = models.DateField(auto_now_add=True, null=True)

    def __str__(self):
        return self.name


class TopicText(models.Model):

    tmap = models.ForeignKey(
        TMap,
        verbose_name="Mapa por categorias",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )

    name = models.CharField(
        verbose_name="Nombre",
        max_length=40
    )

    icon = IconField(
        default='info',
        verbose_name="Icono"
    )

    custom_icon = models.ImageField(
        verbose_name="Icono Personalizado",
        upload_to="images/",
        null=True,
        blank=True
    )

    stack_order = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return self.name


class TopicTextItems(models.Model):

    topic_text = models.ForeignKey(
        TopicText,
        verbose_name="Tematica texto",
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
    )

    name = models.CharField(
        verbose_name="Nombre",
        max_length=250
    )

    contents = RichTextUploadingField(
        verbose_name="Contenido",
        blank=True,null=True
    )

    stack_order = models.IntegerField(null=True, blank=True)


    def __str__(self):
        return self.name


class TMapidMarker(models.Model):

    lat = models.DecimalField(
        max_digits=19,
        decimal_places=10,
        blank=True,
        null=True
    )

    lng = models.DecimalField(
        max_digits=19,
        decimal_places=10,
        blank=True,
        null=True
    )

    title = models.CharField(
        verbose_name='Titulo',
        null=True,
        max_length=200
    )

    narrative = RichTextUploadingField(
        verbose_name="Narrativa de Marcador",
        blank=True,
        null=True
    )

    icon = IconField(
        default='info',
        verbose_name="Icono"
    )

    options = models.CharField(
        verbose_name="Opciones del marcador",
        max_length=500,
        null=True,
        blank=True
    )

    def __str__(self):
        return str(self.pk)


class TMapIds(models.Model):

    topic = models.ForeignKey(
        Topic,
        related_name="map_ids",
        db_column='topic_id',
        on_delete=models.CASCADE,
    )

    map = models.IntegerField(
        verbose_name="Mapa",
        null=True,
        blank=True,
        db_column='map_id'
    )

    map_on = models.BooleanField(default=False)

    name = models.CharField(
        null=True,
        max_length=200
    )

    title = models.CharField(
        null=True,
        max_length=200
    )

    stack_order = models.IntegerField(null=True, blank=True)

    narrative = RichTextUploadingField(
        verbose_name="Narrativa de Mapa",
        blank=True,
        null=True
    )

    doc_related = models.URLField(
        verbose_name="Documento relacionado",
        blank=True,
        null=True
    )

    markers = models.ManyToManyField(
        TMapidMarker,
        blank=True
    )

    class Meta:
        db_table = "topic_maps_mapids"

    def __str__(self):
        return str(self.map)


class TMapHeader(models.Model):

    FONTS = (
        ('Times New Roman', 'Times New Roman'),
        ('Georgia', 'Georgia'),
        ('Lucida Sans', 'Lucida Sans'),
        ('HelveticaNeue', 'HelveticaNeue'),
        ('Arial', 'Arial'),
        ('Montserrat', 'Montserrat'),
        ('Poppins', 'Poppins'),
        ('Source Sans Pro', 'Source Sans Pro'),
    )

    tmap = models.ForeignKey(
        TMap,
        verbose_name="Mapa por categoria", 
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )

    title = models.CharField(
        verbose_name="Título del Mapa",
        null=True, 
        max_length=200
    )

    logo_1 = models.ImageField(
        verbose_name="Logo 1",
        help_text='Este logo aparecerá en el encabezado.',
        upload_to="images/",
        blank=True,
        null=True,
        default=None
    )
    
    link_1 = models.URLField(
        verbose_name="URL logo 1",
        blank=True,
        default=None
    )

    alt_1 = models.CharField(
        verbose_name="Título 1",
        max_length=50,
        blank=True,
        null=True
    )

    logo_2 = models.ImageField(
        verbose_name="Logo 2",
        help_text='Este logo aparecerá en el encabezado.',
        upload_to="images/",
        blank=True,
        null=True,
        default=None
    )
    
    link_2 = models.URLField(
        verbose_name="URL logo 2",
        blank=True,
        default=None
    )

    alt_2 = models.CharField(
        verbose_name="Título 2",
        max_length=50,
        blank=True,
        null=True
    )

    logo_3 = models.ImageField(
        verbose_name="Logo 3",
        help_text='Este logo aparecerá en el encabezado.',
        upload_to="images/",
        blank=True,
        null=True,
        default=None
    )
    
    link_3 = models.URLField(
        verbose_name="URL logo 3",
        blank=True,
        default=None
    )

    alt_3 = models.CharField(
        verbose_name="Título 3",
        max_length=50,
        blank=True,
        null=True
    )

    logo_4 = models.ImageField(
        verbose_name="Logo 4",
        help_text='Este logo aparecerá en el encabezado.',
        upload_to="images/",
        blank=True,
        null=True,
        default=None
    )
    
    link_4 = models.URLField(
        verbose_name="URL logo 4",
        blank=True,
        default=None
    )

    alt_4 = models.CharField(
        verbose_name="Título 4",
        max_length=50,
        blank=True, 
        null=True
    )

    logo_5 = models.ImageField(
        verbose_name="Logo 5",
        help_text='Este logo aparecerá en el encabezado.',
        upload_to="images/",
        blank=True,
        null=True,
        default=None
    )
    
    link_5 = models.URLField(
        verbose_name="URL logo 5",
        blank=True,
        default=None
    )

    alt_5 = models.CharField(
        verbose_name="Título 5",
        max_length=50,
        blank=True,
        null=True
    )

    title_color = models.CharField(
        verbose_name="Color de Texto (Este color se aplicará solamente al texto del encabezado)",
        max_length=40,
        blank=True,
        null=True
    )
    
    title_size = models.IntegerField(
        verbose_name="Tamaño de fuente (px)",
        null=True,
        default="28"
    )

    title_font = models.CharField(
        verbose_name="Tipo de letra",
        max_length=40, 
        choices=FONTS,
        blank=True,
        null=True,
        default='Montserrat'
    )
    
    header_color = models.CharField(
        verbose_name="Color de Fondo (Este color se aplicará al fondo del encabezado)",
        max_length=40,
        blank=True,
        null=True
    )

    def __str__(self):
        return self.title

