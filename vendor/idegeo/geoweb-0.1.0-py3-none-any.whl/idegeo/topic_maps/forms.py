# -*- coding: utf-8 -*-
from django.forms import ModelForm
from django import forms
from .models import TMap, Topic, TMapIds, TMapidMarker, TMapHeader, TopicText, TopicTextItems


class TMapForm(ModelForm):
    template_style = forms.ChoiceField(
        label='Seleccionar el tema de la interfaz gráfica',
        choices=TMap.TEMA
    )

    template_use = forms.ChoiceField(
        label='Seleccione la configuracion del panorama',
        choices=TMap.USE
    )

    def __init__(self, *args, **kwargs):
        super(TMapForm, self).__init__(*args, **kwargs)

    class Meta:
        model = TMap
        exclude = ['stack_order']


class TopicForm(ModelForm):
    class Meta:
        model = Topic
        exclude = ['tmap', 'map_ids', 'stack_order']


class TMapNarrativeForm(ModelForm):
    class Meta:
        model = TMapIds
        fields = ('narrative',)


class TMapDocRelatedForm(ModelForm):
    class Meta:
        model = TMapIds
        fields = ('doc_related',)


class MarkerNarrativeForm(ModelForm):
    class Meta:
        model = TMapidMarker
        fields = ('title', 'narrative')


class MarkerIconForm(ModelForm):
    class Meta:
        model = TMapidMarker
        fields = ('icon',)


class TMapHeaderForm(ModelForm):
    class Meta:
        model = TMapHeader
        exclude = ['tmap']


class TopicTextForm(ModelForm):
    class Meta:
        model = TopicText
        exclude = ['mviewer', 'stack_order']


class TopicTextItemForm(ModelForm):
    class Meta:
        model = TopicTextItems
        exclude = ['topic_text','stack_order'] 