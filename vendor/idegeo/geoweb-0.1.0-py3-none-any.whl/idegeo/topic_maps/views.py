# -*- coding: utf-8 -*-
import json

from django.http import HttpResponse, JsonResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from django.urls import reverse

from idegeo.GeonodeModels.models import Map

from idegeo.topic_maps.models import *
from idegeo.topic_maps.forms import *


@login_required
def tmaps_list(request):
    tmaps = TMap.objects.all()

    return render(request, "list/tmaps_list.html", {"items": tmaps})


@login_required
def tmap_create(request):
    if request.method == 'POST':
        mv_form = TMapForm(request.POST, request.FILES)
        if mv_form.is_valid():
            mv_instance = mv_form.save()
            return HttpResponseRedirect(reverse('tmap_detail', args=[mv_instance.pk]))
    else:
        mv_form = TMapForm()
    return render(request, "create/tmap/tmap_metadata.html", {'form': mv_form})

@login_required
def tmap_detail(request, mv_id):
    tmap = get_object_or_404(TMap, id=mv_id)
    try:
        tmap_header = get_object_or_404(TMapHeader, tmap=tmap)
    except:
        tmap_header = None
    topics = Topic.objects.filter(tmap=mv_id).order_by('stack_order')
    sty_dict = {}

    for top in topics:
        top.maps = {}
        for mid in top.map_ids.all():
            map_instance = Map.objects.get(id=mid.map)
            setattr(mid, 'map', map_instance)
            # top.maps[mid.id] = {
            #     'map': map_instance,
            #     'tmap': mid,
            #     'order': mid.stack_order
            # }

    return render(
        request, 
        "detail/tmap_detail.html", {
            'mviewer': tmap,
            'mviewer_header': tmap_header,
            'topics': topics,
            'sty_dict': json.dumps(sty_dict)
        })


@login_required
def tmap_metadata(request, mv_id):
    tmap = get_object_or_404(TMap, id=mv_id)
    if request.method == 'POST':
        mv_form = TMapForm(request.POST, request.FILES, instance=tmap)
        if mv_form.is_valid():
            mv_form.save()
            return HttpResponseRedirect(reverse('tmap_detail', args=[mv_id]))
    else:
        mv_form = TMapForm(instance=tmap)

    return render(request, "create/tmap/tmap_metadata.html", {'form': mv_form, 'mv': tmap})


@login_required
def tmap_remove(request, mv_id, template='tmap_remove.html'):
    tmap = get_object_or_404(TMap, id=mv_id)
    if request.method == 'GET':
        return render(request, template, RequestContext(request, {"mviewer": tmap}))
    if request.method == 'POST':
        tmap.delete()
        return HttpResponseRedirect(reverse("tmaps_list"))
    else:
        return HttpResponse("Not allowed", status=403)


def onoff_maps(user, topics):
    vis_dict = {}
    perm_dict={}
    for top in topics:
        layer_ids = TMapIds.objects.filter(topic=top)
        lay_dict = {}
        for e in layer_ids:
            map = get_object_or_404(Map, id=e.map)
            perm_dict[map.id]= False
            visible = e.map_on
            st_order = e.stack_order
            lay_dict[str(e.map)+'r'+str(st_order)] = visible
        vis_dict[top.id] = lay_dict
    return vis_dict, perm_dict


def tmap(request, url_id):
    tmap = get_object_or_404(TMap, url_id=url_id)
    try:
        tmap_header = get_object_or_404(TMapHeader, tmap=tmap)
    except:
        tmap_header = None

    if tmap.cms:
        menus = tmap.cms.menu_set.filter(parent_menu=None, active=True, is_section=False).order_by('stack_order')
    else:
        menus = None

    topics = Topic.objects.filter(tmap=tmap.id).order_by('stack_order')
    tlay_ids = []

    initial_map = 0
    for top in topics:
        mapids=top.map_ids.all()
        top.maps = []
        for mid in mapids:
            map_instance = Map.objects.get(id=mid.map)
            top.maps.append(map_instance)
            if mid.map_on:
                initial_map = mid.id
        tlay_ids += top.map_ids.values_list('map', flat=True)
    list_set = set(tlay_ids)
    lays_ids = (list(list_set))
    lays = Map.objects.filter(id__in=lays_ids)
    user = request.user
    vis_dict, perm_dict = onoff_maps(user, topics)

    basemap = 'darkMatter'

    if 'Alternativo' in tmap.template_style:
        template = 'tmap/tmapAlt.html'
    else:
        template = 'tmap/tmap.html'

    return render(
        request,
        template,
        {
            'mviewer': tmap,
            'mviewer_header': tmap_header,
            'topics': topics,
            'lays': lays,
            'initial_map': initial_map,
            'vis_dict': json.dumps(vis_dict),
            'perm_dict': json.dumps(perm_dict),
            'basemap': json.dumps(basemap),
            'menus': menus
        },
    )


def tmap_on(request):
    if request.method == "POST":
        data = json.loads(request.POST['data'])
        reg_id = data['reg_id']
        regid_to_off = data['regid_to_off']
        if regid_to_off != 0:
            map_to_off = get_object_or_404(TMapIds, id=regid_to_off)
            map_to_off.map_on = False
            map_to_off.save()
        map_to_on = get_object_or_404(TMapIds, id=reg_id)
        map_to_on.map_on = True
        map_to_on.save()

        return JsonResponse({'ok':'ok'})
    else:
        return HttpResponse("Bad request")


def tmap_off(request):
    if request.method == "POST":
        data = json.loads(request.POST['data'])
        reg_id = data['reg_id']
        topic_layer = get_object_or_404(TMapIds, id=reg_id)
        topic_layer.map_on = False
        topic_layer.save()

        return JsonResponse({'ok':'ok'})
    else:
        return HttpResponse("Bad request")


def tmap_sort_topic(request):
    if request.method == "POST":
        sorted_ids = json.loads(request.POST['sorted_ids'])
        st_order=1
        for e in sorted_ids:
            topic = get_object_or_404(Topic, id=int(e))
            topic.stack_order = st_order
            topic.save()
            st_order += 1

        return JsonResponse({'ok':'ok'})
    else:
        return HttpResponse("Bad request")


def sort_map(request):
    if request.method == "POST":
        sorted_ids = json.loads(request.POST['sorted_ids'])
        st_order=1
        for e in sorted_ids:
            tmapid = get_object_or_404(TMapIds, id=int(e))
            tmapid.stack_order = st_order
            tmapid.save()
            st_order += 1

        return JsonResponse({'ok':'ok'})
    else:
        return HttpResponse("Bad request")


@login_required
def tmap_create_header(request, mv_id):
    tmap = TMap.objects.get(id=mv_id)
    if request.method == 'POST':
        header_form = TMapHeaderForm(request.POST, request.FILES)
        if header_form.is_valid():
            temp = header_form.save(commit=False)
            temp.tmap = tmap
            temp.save()
            return HttpResponseRedirect(reverse('tmap_detail', args=[mv_id]))
    else:
        header_form = TMapHeaderForm()
    return render(request, 'create/header/tmap_header.html', {'form': header_form, 'mviewer': tmap})


@login_required
def tmap_edit_header(request, header_id):
    header = TMapHeader.objects.get(id=header_id)
    if request.method == 'POST':
        header_form = TMapHeaderForm(request.POST, request.FILES, instance=header)
        if header_form.is_valid():
            header_form.save()
            return HttpResponseRedirect(reverse('tmap_detail', args=[header.tmap.id]))
    else:
        header_form = TMapHeaderForm(instance=header)
    return render(request, 'create/header/tmap_header.html', {'form': header_form, 'header': header})


###### TMAP TOPICS  VIEWS ######

def tmap_topic_create(request, mv_id):
    if request.method == 'POST':
        topic_form = TopicForm(request.POST, request.FILES)
        if topic_form.is_valid():
            num = Topic.objects.filter(tmap=mv_id).count()
            if num >= 7:
                try:
                    mv = get_object_or_404(TMap, id=mv_id)
                    if mv.template_style == 'Alternativo':
                        if num > 50:
                            return HttpResponse('Limite excedido')
                    else:
                        if not mv.is_vertical: # solamente si el panel no esta activado puedes pasar el límite de tematicas
                                return HttpResponse('Limite excedido')
                        else:
                            if num > 20:# vamos a poner un límite de 15 tematicas para el panel izquierdo
                                return HttpResponse('Limite excedido')
                except:
                    pass
            index = num + 1
            new_topic = topic_form.save(commit=False)
            new_topic.tmap = get_object_or_404(TMap, id=mv_id)
            new_topic.stack_order = index
            new_topic.save()
            return HttpResponseRedirect(reverse('tmap_detail', args=[mv_id]))
    else:
        topic_form = TopicForm()

    return render(request, 'create/topic/tmap_topic_metadata.html', {'form': topic_form, 'mvid':mv_id})

def tmap_topic_metadata(request, mv_id, top_id):
    topic = get_object_or_404(Topic, id=top_id)
    if request.method == 'POST':
        topic_form = TopicForm(request.POST, request.FILES, instance=topic)
        if topic_form.is_valid():
            topic_form.save()
            return HttpResponseRedirect(reverse('tmap_detail', args=[mv_id]))
    else:
        topic_form = TopicForm(instance=topic)
    return render(request, 'create/topic/tmap_topic_metadata.html', {'form': topic_form, 'mvid':mv_id})

def tmap_topic_remove(request, mv_id, top_id):
    topic = get_object_or_404(Topic, id=top_id)
    if request.method == 'GET':
        topic.delete()
        return HttpResponseRedirect(reverse("tmap_detail", args=[mv_id]))
    else:
        return HttpResponse("Not allowed", status=403)


def tmap_edit_narrative(request, mv_id, reg_id):
    layerid = get_object_or_404(TMapIds, id=reg_id)
    if request.method == 'POST':
        layerid_form = TMapNarrativeForm(request.POST, instance=layerid)
        if layerid_form.is_valid():
            layerid_form.save()
            return HttpResponseRedirect(reverse('tmap_detail', args=[mv_id]))
    else:
        layerid_form = TMapNarrativeForm(instance=layerid)
    return render(request, 'tmap_narrative.html', {'form': layerid_form, 'mvid': mv_id, 'layerid': layerid})

def tmap_add_doc(request, mv_id, reg_id):
    layerid = get_object_or_404(TMapIds, id=reg_id)
    if request.method == 'POST':
        layerid_form = TMapDocRelatedForm(request.POST, instance=layerid)
        if layerid_form.is_valid():
            layerid_form.save()
            return HttpResponseRedirect(reverse('tmap_detail', args=[mv_id]))
    else:
        layerid_form = TMapDocRelatedForm(instance=layerid)
    return render(request, 'tmap_addDoc.htm', {'form': layerid_form, 'mvid': mv_id, 'layerid': layerid})

def tmap_add_markers(request, mv_id, reg_id):
    layerid = get_object_or_404(TMapIds, id=reg_id)
    marker_narrative_form = MarkerNarrativeForm()
    marker_icon_form = MarkerIconForm()
    markers = layerid.markers.all()
    markers_dict = []

    for m in markers:
        if m.options:
            options = json.loads(m.options)
            color = options['color']
            if 'shape' in options:
                shape = options['shape']
            else:
                shape = 'circle'
            if 'transparent' in options:
                transparent = options['transparent']
            else:
                transparent = 'false'
        else:
            color = '#df1e1e'
            shape = 'circle'
            transparent = 'false'
        markers_dict.append({'id': m.id, 'lat': str(m.lat), 'lng': str(m.lng), 'title': m.title, 'narrative': m.narrative,
                             "icon_name": m.icon.name if m.icon else None, "icon_prefix": m.icon.style_prefix if m.icon else None, 'color': color, 'shape': shape, 'transparent': transparent})

    lay_data = {
        'id': layerid.id,
        'name': layerid.name,
    }

    return render(request, 'tmapid_markers.html', {
        'form': marker_narrative_form,
        'icon_form': marker_icon_form,
        'mvid': mv_id,
        'layerid': json.dumps(lay_data),
        'markers': json.dumps(markers_dict)
    })


### Vistas para Ajax ###
def add_topic_maps(request):
    if request.method == "POST":
        add_data = json.load(request)
        topic_id = add_data['topic_id']
        id_list = add_data['id_list']
        added_ids = {}
        topic = get_object_or_404(Topic, id=topic_id)

        index = TMapIds.objects.filter(topic=topic).count() + 1

        for id in id_list:
            map = get_object_or_404(Map, id=id)
            r = TMapIds(topic=topic, map=id)
            r.title = map.title
            r.stack_order = index
            r.save()

            added_ids[id] = {'layer_id': id, 'st_order': index, 'reg_id' : r.id, 'name': map.title }
            index += 1

        return JsonResponse(added_ids)
    else:
        return HttpResponse("Bad request")


def remove_topic_map(request):
    if request.method == "POST":
        rmv_data = json.loads(request.POST['rmv_data'])
        reg_id = rmv_data['reg_id']
        r = get_object_or_404(TMapIds, id=reg_id)
        r.delete()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Bad request")


def get_tmap_narrative(request):
    if request.method == "POST":
        regid = request.GET['regid']
        r = get_object_or_404(TMapIds, id=regid)
        narrative = r.narrative

        return JsonResponse({ "narrative": narrative })
    else:
        return HttpResponse("Bad request")


def add_mapid_marker(request):
    if request.method == "POST":
        regid = request.GET['regid']
        lat = request.GET['lat']
        lng = request.GET['lng']

        marker = TMapidMarker(lat=lat, lng=lng)
        marker.save()
        r = get_object_or_404(TMapIds, id=regid)
        r.markers.add(marker)

        return JsonResponse({ "marker_id": marker.id })
    else:
        return HttpResponse("Bad request")


def remove_mapid_marker(request):
    if request.method == "POST":
        regid = request.GET['regid']
        marker_id = request.GET['marker_id']

        marker = get_object_or_404(TMapidMarker, id=marker_id)
        r = get_object_or_404(TMapIds, id=regid)
        r.markers.remove(marker)
        marker.delete()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Bad request")


def add_tmap_marker_narrative(request):
    if request.method == "POST":
        title = request.POST['title']
        content = request.POST['content']
        marker_id = request.POST['marker_id']

        marker = get_object_or_404(TMapidMarker, id=marker_id)
        marker.title = title
        marker.narrative = content
        marker.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Bad request")


def change_tmap_marker_position(request):
    if request.method == "POST":
        markid = request.GET['markid']
        lat = request.GET['lat']
        lng = request.GET['lng']
        marker = get_object_or_404(TMapidMarker, id=markid)
        marker.lat = lat
        marker.lng = lng
        marker.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Bad request")


def change_tmap_icon_marker(request):
    if request.method == "POST":
        marker_id = request.POST['marker_id']
        icon = request.POST['icon']
        color = request.POST['color']
        shape = request.POST['shape']
        transparent = request.POST['transparent']

        marker = get_object_or_404(TMapidMarker, id=marker_id)
        marker.icon = icon
        marker.options = json.dumps({'color': color, 'shape': shape, 'transparent': transparent})
        marker.save()

        return JsonResponse({"ok": "ok"})
    else:
        return HttpResponse("Bad request")


def mapid_markers(request):
    if request.method == "GET":
        regid = request.GET['regid']
        layerid = get_object_or_404(TMapIds, id=regid)
        markers = layerid.markers.all()
        markers_dict = []
        for m in markers:
            if m.options:
                options = json.loads(m.options)
                color = options['color']
                if 'shape' in options:
                    shape = options['shape']
                else:
                    shape = 'circle'
                if 'transparent' in options:
                    transparent = options['transparent']
                else:
                    transparent = 'false'
            else:
                color = '#df1e1e'
                shape = 'circle'
                transparent = 'false'
            markers_dict.append({'id': m.id, 'lat': str(m.lat), 'lng': str(m.lng), 'title': m.title, 'narrative': m.narrative,
                                 "icon_name": m.icon.name if m.icon else None, "icon_prefix": m.icon.style_prefix if m.icon else None, 'color': color, 'shape': shape, 'transparent': transparent})

        return JsonResponse({ "markers": markers_dict })
    else:
        return HttpResponse("Not ajax request")

