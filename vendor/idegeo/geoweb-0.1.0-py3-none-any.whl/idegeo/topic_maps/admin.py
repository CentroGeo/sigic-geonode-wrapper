from django.contrib import admin
from .models import TMap, Topic

admin.site.register(TMap)
admin.site.register(Topic)