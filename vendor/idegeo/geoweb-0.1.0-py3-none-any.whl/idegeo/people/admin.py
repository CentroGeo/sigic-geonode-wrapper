from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import Group
from django.utils.translation import gettext_lazy as _
from .models import User

class CustomUserAdmin(UserAdmin):
    def has_add_permission(self, request, obj=None):
        return False
    fieldsets = (
        (
            _('Personal info'), {
                'fields': ('first_name', 'last_name')
            }
        ),
        (_('Permissions'), {
            'fields': ('is_active', 'is_staff', 'is_superuser'),
        }),
        (_('Accesos IDE'), {
            'fields': (
                'ide_access',
                'dashboard_access',
                'mviewer_access',
                'cms_access',
                'tmaps_access',
                'geostories_access',
            ),
        }),
        (_('Important dates'), {
            'fields': ('last_login', 'date_joined'),
        }),
    )
    readonly_fields = ('last_login', 'date_joined')

admin.site.register(User, CustomUserAdmin)
admin.site.unregister(Group)