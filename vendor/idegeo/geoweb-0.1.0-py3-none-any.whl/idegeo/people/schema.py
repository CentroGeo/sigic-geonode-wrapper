from ninja import ModelSchema
from django.contrib.auth import get_user_model

User = get_user_model()


class DefaultUserSchema(ModelSchema):
    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name']