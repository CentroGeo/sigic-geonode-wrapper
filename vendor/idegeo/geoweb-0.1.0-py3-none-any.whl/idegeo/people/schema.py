from ninja import ModelSchema
from .models import User

class DefaultUserSchema(ModelSchema):
    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name']