from django.apps import AppConfig

class IdegeoPeopleConfig(AppConfig):
    name = "idegeo.people"
    label = "idegeo_people"