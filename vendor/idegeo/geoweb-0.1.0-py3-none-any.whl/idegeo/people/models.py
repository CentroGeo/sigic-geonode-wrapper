from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):

    username = models.CharField(
        verbose_name="Nombre de usuario",
        max_length=500,
        unique=True)

    password = models.CharField(max_length=250,default="",blank=True,null=True)

    token = models.CharField(max_length=500)

    oauth_token = models.CharField(max_length=500,null=True)

    token_expires = models.DateTimeField(null=True)

    geonode_user_id = models.BigIntegerField(null=True)
    
    ide_access = models.BooleanField('Acceso a gestión de la plataforma', default=False,
                                     help_text='El usuario tiene acceso a la gestión de la plataforma')
    
    dashboard_access = models.BooleanField('Acceso a dashboard', default=False,
                                     help_text='El usuario tiene acceso a la creación de Dashboard')
    
    mviewer_access = models.BooleanField('Acceso a panoramas', default=False,
                                     help_text='El usuario tiene acceso a la creación de panoramas')
    
    cms_access = models.BooleanField('Acceso a CMS', default=False,
                                     help_text='El usuario tiene acceso a la creación de CMS')
    
    tmaps_access = models.BooleanField('Acceso a tmaps', default=False,
                                     help_text='El usuario tiene acceso a la creación de tmaps')
    
    geostories_access = models.BooleanField('Acceso a GeoHistorias', default=False,
                                     help_text='El usuario tiene acceso a la creación de GeoHistorias')
    
    def __str__(self):
        return self.username