# -*-encoding:utf-8-*-
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse

from idegeo.people.models import User
from idegeo.content_handler.models import ManagmentContent, Header
from idegeo.content_handler.forms import HeaderForm


@login_required
def upload_header(request, ch_id):
    """
    Crea el header del cms, con el
    titulo del cms, los logos que deben aparecer
    en el header y sus urls. Toma ch_id como
    argumento, que es el id del cms.
    """
    home = get_object_or_404(ManagmentContent, id=ch_id)
    us = request.user
    if request.method == "POST":
        header = HeaderForm(request.POST, request.FILES or None)
        if header.is_valid():
            temp_header = header.save(commit=False)
            temp_header.home = home
            temp_header.user = us
            temp_header.is_burger = False
            temp_header.is_search = False
            temp_header.save()
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    else:
        header = HeaderForm()
    profile = get_object_or_404(User, username=us)
    return render(
        request,
        "hd_header_form.html",
        {"form": header, "profile": profile, "home": home},
    )


@login_required
def update_header(request, ch_id, h_id):
    """
    Actualiza el header del cms. Toma ch_id
    como argumento, que es el id del cms, y
    h_id que corresponde al id del header.
    """
    obj = get_object_or_404(Header, id=h_id)
    header = HeaderForm(request.POST or None, request.FILES or None, instance=obj)
    profile = get_object_or_404(User, username=request.user)
    if request.method == "POST":
        if header.is_valid():
            header.save()
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    return render(
        request,
        "hd_header_update.html",
        {"form": header, "profile": profile, "obj": obj},
    )


@login_required
def remove_header(request, h_id, template="hd_header_remove.html"):
    """
    Elimina el header, tomanto h_id como
    argumento, que corresponde al id del
    header.
    """
    try:
        head = get_object_or_404(Header, id=h_id)
        if request.method == "GET":
            return render(request, template, {"head": head})
        if request.method == "POST":
            head.delete()
            return HttpResponseRedirect(reverse("content_handler_list"))
        else:
            return HttpResponse("Not allowed", status=403)

    except PermissionDenied:
        return HttpResponse(
            "You are not allowed to delete this content_handler_list",
            mimetype="text/plain",
            status=401,
        )
