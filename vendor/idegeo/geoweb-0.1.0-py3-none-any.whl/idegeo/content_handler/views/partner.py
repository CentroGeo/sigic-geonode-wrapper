# -*-encoding:utf-8-*-
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse

from idegeo.people.models import User
from idegeo.content_handler.models import ManagmentContent, Menu, Partner
from idegeo.content_handler.forms import (
    PartnerUpdate,
    MenuFormSectionContent,
    UpdatePartnerSection,
)


@login_required
def upload_partner(request, ch_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    ms_form = MenuFormSectionContent()
    instance = ms_form.save(commit=False)
    instance.home = home
    instance.is_section = True
    instance.is_institution = True
    instance.save()

    return HttpResponseRedirect(reverse("section_list", args=[ch_id]))


@login_required
def upload_institution(request, ch_id, menu_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    menu = get_object_or_404(Menu, id=menu_id)
    if request.method == "POST":
        menu_form = UpdatePartnerSection(request.POST, request.FILES)
        if menu_form.is_valid():
            instance = menu_form.save(commit=False)
            count_menu = (
                Menu.objects.filter(home=ch_id)
                .filter(is_section=True)
                .filter(is_institution=True)
                .count()
            )
            instance.home = home
            instance.parent_menu = menu
            instance.stack_order = count_menu
            instance.save()
            return HttpResponseRedirect(reverse("section_list", args=[ch_id]))
    else:
        menu_form = UpdatePartnerSection()
    profile = get_object_or_404(User, username=request.user)
    return render(
        request,
        "hd_subsection_form.html",
        {"form": menu_form, "profile": profile, "home": home, "menu": menu},
    )


@login_required
def update_partner(request, ch_id, partner_id):
    obj = get_object_or_404(Partner, id=partner_id)
    menu_form = PartnerUpdate(request.POST or None, request.FILES or None, instance=obj)
    profile = get_object_or_404(User, username=request.user)
    institution = Partner.objects.filter(home_id=obj.home_id)
    if request.method == "POST":
        if menu_form.is_valid():
            temp = menu_form.save(commit=False)
            return HttpResponseRedirect(reverse("section_list", args=[ch_id]))
    return render(
        request,
        "partner_form.html",
        {"form": menu_form, "profile": profile, "obj": obj, "institution": institution},
    )


@login_required
def remove_partner(request, ch_id, partner_id, template="partner_remove.html"):
    try:
        menu = get_object_or_404(Partner, id=partner_id)
        if request.method == "GET":
            return render(request, template, {"menu": menu, "home": ch_id})
        if request.method == "POST":
            menu.delete()
            return HttpResponseRedirect(reverse("section_list", args=[ch_id]))
        else:
            return HttpResponse("Not allowed", status=403)

    except PermissionDenied:
        return HttpResponse(
            "You are not allowed to delete this content_handler_list",
            mimetype="text/plain",
            status=401,
        )
