# -*-encoding:utf-8-*-
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.urls import reverse

from idegeo.people.models import User
from idegeo.content_handler.models import (
    Style,
    ManagmentContent,
    Menu,
    Header,
    HeaderSectionStyle,
    HeaderStyle,
)
from idegeo.content_handler.forms import (
    StyleForm,
    StylUpdateForm,
    StylFooterForm,
    HeaderSectionForm,
    StyleMainHeaderForm,
    HeaderStyleForm,
)


@login_required
def upload_style_header(request, ch_id, header_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    header = get_object_or_404(Header, id=header_id)
    form = StyleForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        temp = form.save(commit=False)
        temp.header = header
        temp.save()
        return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    else:
        form = StylUpdateForm()
    profile = get_object_or_404(User, username=request.user)
    return render(
        request,
        "style_header_form.html",
        {"form": form, "profile": profile, "home": home},
    )


@login_required
def update_style_header(request, ch_id, id_style):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    obj = get_object_or_404(Style, id=id_style)
    ms_form = StylUpdateForm(request.POST or None, request.FILES or None, instance=obj)
    if request.method == "POST":
        if ms_form.is_valid():
            ms_form.save()
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    return render(
        request, "style_header_form.html", {"form": ms_form, "obj": obj, "home": home}
    )


@login_required
def upload_style_footer(request, ch_id, foo_id):
    try:
        styl = Style.objects.get(footer=foo_id)
        # no debe de existir más de un footer para un contenido
        if styl:
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    except Style.DoesNotExist:
        pass
    if request.method == "POST":
        # header = request.POST.get('header')
        primary_color = request.POST.get("primary_color")
        second_color = request.POST.get("second_color")
        background = request.POST.get("background")
        plot = request.POST.get("plot")
        all = request.POST.get("all")
        status = request.POST.get("status")
        form = StyleForm(
            {
                "footer": foo_id,
                "primary_color": primary_color,
                "plot": plot,
                "second_color": second_color,
                "background": background,
                "all": all,
                "status": status,
            },
            request.FILES,
        )
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    else:
        form = StylFooterForm()
    profile = get_object_or_404(User, username=request.user)
    return render(request, "style_header_form.html", {"form": form, "profile": profile})


@login_required
def update_style_footer(request, ch_id, id_style):
    obj = get_object_or_404(Style, id=id_style)
    ms_form = StylFooterForm(request.POST or None, request.FILES or None, instance=obj)
    if request.method == "POST":
        if ms_form.is_valid():
            ms_form.save()
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    return render(request, "style_header_form.html", {"form": ms_form, "obj": obj})


@login_required
def header_section_style(request, ch_id, menu_id):
    subsect = get_object_or_404(Menu, id=menu_id)
    try:
        ms_form = HeaderSectionForm(
            request.POST or None,
            request.FILES or None,
            instance=subsect.headersectionstyle,
        )
    except:
        ms_form = HeaderSectionForm(
            request.POST or None, request.FILES or None, initial={"text_align": "center"}
        )
    if request.method == "POST":
        if ms_form.is_valid():
            header = ms_form.save(commit=False)
            header.section = subsect
            header.save()
            return HttpResponseRedirect(reverse("section_list", args=[ch_id]))
    return render(request, "header_style.html", {"form": ms_form, "subsect": subsect})


@login_required
def header_menu_style(request, menu_id, ch_id=""):
    subsect = get_object_or_404(Menu, id=menu_id)
    try:
        ms_form = HeaderSectionForm(
            request.POST or None,
            request.FILES or None,
            instance=subsect.headersectionstyle,
        )
    except:
        ms_form = HeaderSectionForm(
            request.POST or None, request.FILES or None, initial={"text_align": "center"}
        )
    if request.method == "POST":
        if ms_form.is_valid():
            header = ms_form.save(commit=False)
            header.section = subsect
            header.save()
            return HttpResponseRedirect(
                reverse("content_handler_detail", args=[subsect.home.id])
            )
    return render(request, "header_style.html", {"form": ms_form, "subsect": subsect})


@login_required
def main_menu_add_style(request, home_id):
    homeHeader = get_object_or_404(ManagmentContent, id=home_id)
    header_form = StyleMainHeaderForm(request.POST or None, request.FILES or None)
    if header_form.is_valid():
        temp = header_form.save(commit=False)
        temp.header_style = homeHeader
        temp.save()
        return HttpResponseRedirect(reverse("content_handler_detail", args=[home_id]))
    return render(
        request, "menu_style.html", {"form": header_form, "homeHeader": homeHeader}
    )


@login_required
def main_menu_edit_style(request, home_id):
    obj = get_object_or_404(HeaderSectionStyle, header_style=home_id)
    header_style_form = StyleMainHeaderForm(
        request.POST or None, request.FILES or None, instance=obj
    )
    if request.method == "POST":
        if header_style_form.is_valid():
            header_style_form.save()
            return HttpResponseRedirect(
                reverse("content_handler_detail", args=[home_id])
            )
    return render(request, "menu_style.html", {"form": header_style_form, "obj": obj})


@login_required
def header_style_add(request, home_id):
    homeHeader = get_object_or_404(ManagmentContent, id=home_id)
    header_style_form = HeaderStyleForm(request.POST or None, request.FILES or None)
    if header_style_form.is_valid():
        temp = header_style_form.save(commit=False)
        temp.header_style = homeHeader
        temp.save()
        return HttpResponseRedirect(reverse("content_handler_detail", args=[home_id]))
    return render(
        request, "header_style_form.html", {"form": header_style_form, "homeHeader": homeHeader}
    )


@login_required
def header_style_edit(request, home_id):
    obj = get_object_or_404(HeaderStyle, header_style=home_id)
    header_style_form = HeaderStyleForm(request.POST or None, request.FILES or None, instance=obj)
    if request.method == 'POST':
        if header_style_form.is_valid():
            header_style_form.save()
            return HttpResponseRedirect(
                reverse("content_handler_detail", args=[home_id])
            )
    return render(request, "header_style_form.html", {"form":header_style_form, "obj":obj})