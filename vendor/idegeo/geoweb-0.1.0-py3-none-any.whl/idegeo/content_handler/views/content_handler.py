# -*-encoding:utf-8-*-
import random
from itertools import chain
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.clickjacking import xframe_options_exempt
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.core.exceptions import PermissionDenied
from django.urls import reverse

from idegeo.settings import SITEURL, LOGIN_URL
from django.contrib.auth import get_user_model
User = get_user_model()
from idegeo.content_handler.models import (
    Partner,
    Content,
    Style,
    Menu,
    Footer,
    Header,
    ManagmentContent,
)

from idegeo.content_handler.forms import ManagmentContentForm, ManagmentContentUpdate


@login_required
def content_handler_list(request):
    """
    Muestra al usuario una lista de los
    cms disponibles.
    """
    site = SITEURL + "hd/"

    ms = ManagmentContent.objects.all()

    return render(request, "home_list.html", {"items": ms, "site": site})


@login_required
def content_handler_detail(request, ch_id):
    """
    Renderiza la vista de detalle del cms.
    El parametro ch_id representa el id del
    cms a renderizar. La vista de detalle
    corresponde a la vista de configuracion
    del cms.
    """

    header = None
    style = None
    footer = None
    style_footer = None
    site = SITEURL + "/cms/"
    ch = get_object_or_404(ManagmentContent, id=ch_id)
    menus = (
        Menu.objects.filter(home=ch_id)
        .filter(parent_menu=None)
        .filter(is_section=False)
        .order_by("stack_order")
    )
    sections = (
        Menu.objects.filter(active=True)
        .filter(home=ch_id)
        .filter(parent_menu=None)
        .filter(is_section=True)
        .order_by("stack_order")
    )
    content = Content.objects.filter(active=True).order_by("stack_order")
    try:
        header = Header.objects.get(home=ch_id)
    except Exception as e:
        print(e)
    try:
        style = Style.objects.get(header=header)
    except Exception as e:
        print(e)
    try:
        footer = Footer.objects.get(home=ch.id)
    except Exception as e:
        print(e)
    if footer:
        try:
            style_footer = Style.objects.get(footer=footer)
        except Exception as e:
            print(e)
    return render(
        request,
        "home_detail.html",
        {
            "ms": ch,
            "site": site,
            "header": header,
            "menus": menus,
            "sections": sections,
            "content": content,
            "style": style,
            "footer": footer,
            "style_footer": style_footer,
        },
    )


@xframe_options_exempt
def handler_home(request, msurlname=None):
    """
    Renderiza el home del cms. Toma como argumento
    el slug para buscar con ello el cms en la db.
    """
    style = None
    footer = None
    style_footer = None
    try:
        config = ManagmentContent.objects.get(url_name=msurlname)
        template = ("styles/handler_1/style_1.html")
    except ManagmentContent.DoesNotExist as e:
        raise Http404
    if not config.public and not request.user.is_authenticated:
        return HttpResponseRedirect(LOGIN_URL)

    try:
        header = Header.objects.get(home=config)
    except Header.DoesNotExist as e:
        print(e)
        raise Http404
    try:
        style = Style.objects.get(header=header)
    except Style.DoesNotExist as e:
        print(e)
        pass

    topics = (
        Menu.objects.filter(parent_menu=None)
        .filter(home=config)
        .filter(active=True)
        .filter(is_section=False)
        .order_by("stack_order")
    )
    sections = (
        Menu.objects.filter(parent_menu=None)
        .filter(home=config)
        .filter(active=True)
        .filter(is_section=True)
        .order_by("stack_order")
    )

    second_menu = topics.filter(menu_side='2')

    is_select = 0
    for t in sections:
        print(t.id)
        if t.id > is_select:
            is_select = t.id

    items_list = list(chain(topics))
    random.shuffle(items_list)
    content = (
        Content.objects.filter(active=True).filter(home=config).order_by("stack_order")
    )
    partner = Partner.objects.filter(home=config)

    try:
        footer = Footer.objects.get(home=config.id)
    except Footer.DoesNotExist as e:
        print(e)
        pass
    if footer:
        try:
            style_footer = Style.objects.get(footer=footer)
        except Style.DoesNotExist as e:
            print(e)
            pass

    return render(
        request,
        template,
        {
            "site": SITEURL,
            "topics": topics,
            "partner": partner,
            "items_list": items_list,
            "content": content,
            "style": style,
            "header": header,
            "home": config,
            "is_select": is_select,
            "sections": sections,
            "footer": footer,
            "style_footer": style_footer,
            "second_menu": second_menu
        },
    )


@login_required
def create_or_update_handler(request, ch_id=""):
    """
    Crea o actualiza un cms. El parametro ch_id
    es el id del cms. Si el request no incluye el
    parametro. Entonces se renderiza la vista de
    creacion de un nuevo cms.
    """
    try:
        obj = ManagmentContent.objects.get(id=ch_id)
        ms_form = ManagmentContentUpdate(
            request.POST or None, request.FILES or None, instance=obj
        )
        profile = get_object_or_404(User, username=request.user)
        if request.method == "POST":
            if ms_form.is_valid():
                ms_form.save()
            return HttpResponseRedirect("../")
        return render(
            request, "home_form.html", {"form": ms_form, "profile": profile, "obj": obj}
        )
    except:
        if request.method == "POST":
            mc_form = ManagmentContentForm(request.POST, request.FILES)
            if mc_form.is_valid():
                mc_form.save()
                return HttpResponseRedirect("../")
        else:
            mc_form = ManagmentContentForm()
        profile = get_object_or_404(User, username=request.user)
        return render(request, "home_form.html", {"form": mc_form, "profile": profile})


@login_required
def remove_handler(request, ch_id, template="home_remove.html"):
    """
    Elimina un cms tomando el parametro ch_id como el
    id del cms a eliminar. Esto solo si el usuario tiene
    permisos suficientes para poder realizar la accion.
    """
    try:
        mc = get_object_or_404(ManagmentContent, id=ch_id)
        if request.method == "GET":
            return render(request, template, {"mc": mc})
        if request.method == "POST":
            mc.delete()
            return HttpResponseRedirect(reverse("content_handler_list"))
        else:
            return HttpResponse("Not allowed", status=403)

    except PermissionDenied:
        return HttpResponse(
            "You are not allowed to delete this ms_gestor_list",
            mimetype="text/plain",
            status=401,
        )
