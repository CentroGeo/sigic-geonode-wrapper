# -*-encoding:utf-8-*-
import json

from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.views.decorators.clickjacking import xframe_options_exempt
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.conf import settings
from idegeo.content_handler.models import (
    ManagmentContent,
    Menu,
    Header,
    Content,
    Style,
    Footer,
)
from idegeo.content_handler.forms import ContentForm, SimpleContent, ManagmentColorsForm

User = get_user_model()
SITEURL = settings.SITEURL


@xframe_options_exempt
def content_multimedia(request, msurlname, slug):
    style = None
    footer = None
    style_footer = None
    try:
        config = ManagmentContent.objects.get(url_name=msurlname)
        template = ("styles/handler_1/multimedia_1.html")
    except ManagmentContent.DoesNotExist as e:
        raise Http404
    try:
        menu = Menu.objects.get(slug=slug)
        template = ("styles/handler_1/multimedia_1.html")
    except ManagmentContent.DoesNotExist as e:
        raise Http404

    try:
        header = Header.objects.get(home=config)
    except Header.DoesNotExist as e:
        print(e)
        raise Http404

    topics = (
        Menu.objects.filter(parent_menu=None)
        .filter(home=config)
        .filter(active=True)
        .filter(is_section=False)
        .order_by("stack_order")
    )

    second_menu = topics.filter(menu_side='2')

    sections = (
        Menu.objects.filter(parent_menu=None)
        .filter(home=config)
        .filter(active=True)
        .filter(is_section=True)
        .order_by("stack_order")
    )

    is_select = 0
    for t in sections:
        if t.id > is_select:
            is_select = t.id
    print(is_select)

    try:
        style = Style.objects.get(header=header)
    except Style.DoesNotExist as e:
        print(e)
        pass
    print(config.id)
    print("aqui es", config.id)
    try:
        footer = Footer.objects.get(home=config)
    except Footer.DoesNotExist as e:
        print(e)
        pass
    if footer:
        try:
            style_footer = Style.objects.get(footer=footer)
        except Style.DoesNotExist as e:
            print(e)
            pass

    return render(
        request,
        template,
        {
            "topics": topics,
            "menu": menu,
            "style": style,
            "header": header,
            "home": config,
            "is_select": is_select,
            "sections": sections,
            "footer": footer,
            "style_footer": style_footer,
            "second_menu": second_menu
        },
    )


@login_required
def upload_content(request, ch_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    if request.method == "POST":
        content = request.POST.get("content", False)
        stack_order = request.POST.get("stack_order", False)
        active = request.POST.get("active", False)
        created_at = request.POST.get("timestamp")

        ms_form = ContentForm(
            {
                "home": ch_id,
                "content": content,
                "stack_order": stack_order,
                "active": active,
                "created_at": created_at,
            },
            request.FILES or None,
        )
        if ms_form.is_valid():
            ms_form.save()
            return HttpResponseRedirect("../content_list/" + ch_id)
    else:
        ms_form = SimpleContent()
    profile = get_object_or_404(User, username=request.user)
    return render(
        request,
        "content_form.html",
        {"form": ms_form, "profile": profile, "home": home},
    )


@login_required
def update_content(request, ch_id, content_id):
    obj = get_object_or_404(Content, id=content_id)
    menu_form = SimpleContent(request.POST or None, request.FILES or None, instance=obj)
    profile = get_object_or_404(User, username=request.user)
    if request.method == "POST":
        if menu_form.is_valid():
            menu_form.save()
            return HttpResponseRedirect("../../content_list/" + ch_id)
    return render(
        request,
        "content_form.html",
        {"form": menu_form, "profile": profile, "obj": obj},
    )


@login_required
def remove_content(request, ch_id, content_id, template="content_remove.html"):
    try:
        content = get_object_or_404(Content, id=content_id)
        if request.method == "GET":
            return render(request, template, {"content": content, "home": ch_id})
        if request.method == "POST":
            content.delete()
            return HttpResponseRedirect("../../content_list/" + ch_id)
        else:
            return HttpResponse("Not allowed", status=403)

    except PermissionDenied:
        return HttpResponse(
            "You are not allowed to delete this content_handler_list",
            mimetype="text/plain",
            status=401,
        )


def hd_grays_managment(request):
    if request.is_ajax():
        query_data = json.loads(request.POST["query_data"])
        id_ms = query_data["id_ms"]
        grays = query_data["grays"]
        obj = get_object_or_404(ManagmentContent, id=id_ms)
        obj.gray_colors = grays
        obj.save()

        return HttpResponse(
            json.dumps({"exito": "si"}), content_type="application/json"
        )
    else:
        return HttpResponse("Solo Ajax")


def hd_save_color(request):
    if request.is_ajax():
        data_list = []
        query_data = json.loads(request.POST["query_data"])
        id_ms = query_data["id_ms"]
        id_color = query_data["id_color"]
        try:
            obj = get_object_or_404(ManagmentContent, id=id_ms)
            data_list.append(obj.url_name)
            colors_form = ManagmentColorsForm({"color": id_color}, instance=obj)
            if colors_form.is_valid():
                colors_form.save()
            return HttpResponse(json.dumps(data_list), content_type="application/json")
        except ManagmentContent.DoesNotExist:
            print("Error No existe el objeto")
            return HttpResponse(json.dumps(data_list), content_type="application/json")
    else:
        return HttpResponse("Solo Ajax")


@login_required
def hd_publish(request):
    if request.is_ajax():
        data_list = []
        query_data = json.loads(request.POST["query_data"])
        ch_id = query_data["home"]
        try:
            ms = get_object_or_404(ManagmentContent, id=ch_id)
            ms.public = True
            ms.save()
            return HttpResponse(json.dumps(data_list), content_type="application/json")
        except ManagmentContent.DoesNotExist:
            print("Error No existe el objeto")
            return HttpResponse(json.dumps(data_list), content_type="application/json")
    else:
        return HttpResponse("Solo Ajax")


@login_required
def hd_publish_managment(request, ch_id):
    ms = get_object_or_404(ManagmentContent, id=ch_id)
    ms.public = True
    ms.save()
    return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))


@login_required
def hd_unpublish_managment(request, ch_id):
    ms = get_object_or_404(ManagmentContent, id=ch_id)
    ms.public = False
    ms.save()
    return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))


@login_required
def hd_content_list(request, ch_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    content = (
        Content.objects.filter(home=ch_id).filter(active=True).order_by("stack_order")
    )
    site = SITEURL + "handler/"
    return render(
        request, "content.html", {"ms": home, "site": site, "content": content}
    )
