# -*-encoding:utf-8-*-
import json
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, JsonResponse

from idegeo.content_handler.models import (
    Menu,
    ManagmentContent,
    Partner,
    Content,
)
from idegeo.content_handler.forms import (
    ManagmentHexadecimalForm,
    ManagmentSectionTypeFrom,
)



def sort_sections_handler(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        st_order = 1
        for e in data:
            section = get_object_or_404(Menu, id=int(e))
            section.stack_order = st_order
            section.save()
            st_order += 1

        return JsonResponse({'success': True})
    else:
        return JsonResponse({'error': 'Invalid request method.'})


def sort_partner(request):
    if request.is_ajax():
        sorted_ids = json.loads(request.POST["sorted_ids"])
        st_order = 1
        for e in sorted_ids:
            section = get_object_or_404(Partner, id=int(e))
            section.stack_order = st_order
            section.save()
            st_order += 1

        return HttpResponse(json.dumps({"ok": "ok"}), mimetype="application/json")
    else:
        return HttpResponse("Not ajax request")


def sort_content(request):
    if request.is_ajax():
        sorted_ids = json.loads(request.POST["sorted_ids"])
        st_order = 1
        for e in sorted_ids:
            section = get_object_or_404(Content, id=int(e))
            section.stack_order = st_order
            section.save()
            st_order += 1

        return HttpResponse(json.dumps({"ok": "ok"}), mimetype="application/json")
    else:
        return HttpResponse("Not ajax request")


def hd_save_section_type(request):
    if request.is_ajax():
        data_list = []
        query_data = json.loads(request.POST["query_data"])
        id_ms = query_data["id_ms"]
        id_tematics = query_data["id_tematics"]
        print(id_tematics)
        try:
            obj = get_object_or_404(ManagmentContent, id=id_ms)
            data_list.append(obj.url_name)
            colors_form = ManagmentSectionTypeFrom(
                {"template": id_tematics}, instance=obj
            )
            if colors_form.is_valid():
                colors_form.save()
                print("guardo")
            else:
                print("no guardo")
            return HttpResponse(json.dumps(data_list), content_type="application/json")
        except ManagmentContent.DoesNotExist:
            print("Error No existe el objeto")
            return HttpResponse(json.dumps(data_list), content_type="application/json")

    else:
        return HttpResponse("Solo Ajax")


"""
Guarda los colores hexadecimales para el home
"""


def hd_save_hexadecimal(request):
    if request.is_ajax():
        data_list = []
        query_data = json.loads(request.POST["query_data"])
        id_home = query_data["id_home"]
        primary = query_data["primary"]
        second = query_data["second"]
        complementary = query_data["complementary"]
        try:
            obj = get_object_or_404(ManagmentContent, id=id_home)
            data_list.append(obj.url_name)
            colors_form = ManagmentHexadecimalForm(
                {
                    "primary_color": primary,
                    "second_color": second,
                    "complementary_color": complementary,
                },
                instance=obj,
            )
            if colors_form.is_valid():
                colors_form.save()
            return HttpResponse(json.dumps(data_list), content_type="application/json")
        except ManagmentContent.DoesNotExist:
            print("Error No existe el objeto")
            return HttpResponse(json.dumps(data_list), content_type="application/json")
    else:
        return HttpResponse("Solo Ajax")


"""
Si ya existen los colores hexadecimales para el home se muestran
"""


def hd_hexadecimal(request):
    if request.is_ajax():
        data_list = []
        query_data = json.loads(request.POST["query_data"])
        id_home = query_data["id_home"]
        try:
            obj = get_object_or_404(ManagmentContent, id=id_home)
            data_list.append(obj.primary_color)
            data_list.append(obj.second_color)
            data_list.append(obj.complementary_color)
            return HttpResponse(json.dumps(data_list), content_type="application/json")
        except ManagmentContent.DoesNotExist:
            print("Error No existe el objeto")
            return HttpResponse(json.dumps(data_list), content_type="application/json")
    else:
        return HttpResponse("Solo Ajax")
