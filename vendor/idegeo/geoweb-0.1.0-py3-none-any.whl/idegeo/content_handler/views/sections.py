# -*-encoding:utf-8-*-
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.urls import reverse

from idegeo.settings import SITEURL
from django.contrib.auth import get_user_model

User = get_user_model()

from idegeo.content_handler.models import ManagmentContent, Menu, Partner
from idegeo.content_handler.forms import (
    MenuFormSection,
    SectionParentForm,
    MenuFormSectionContent,
    UpdateSectionPartner,
    MenuFormSubsection,
    UpdatePartnerSection,
)


@login_required
def upload_section(request, ch_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    if request.method == "POST":
        ms_form = MenuFormSection(request.POST, request.FILES)
        if ms_form.is_valid():
            instance = ms_form.save(commit=False)
            instance.home = home
            instance.is_section = True
            instance.save()
            return HttpResponseRedirect(
                reverse("header_section_style", args=[ch_id, instance.id])
            )
    else:
        ms_form = MenuFormSection()
    profile = get_object_or_404(User, username=request.user)
    return render(
        request,
        "hd_section_form.html",
        {"form": ms_form, "profile": profile, "home": home, "ch_id": ch_id},
    )


@login_required
def upload_subsection(request, ch_id, menu_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    Menu_parent = get_object_or_404(Menu, id=menu_id)
    if request.method == "POST":
        menu = Menu.objects.filter(home=ch_id).filter(is_section=True).count()
        menu_form = MenuFormSection(request.POST or None, request.FILES or None)
        if menu_form.is_valid():
            temp = menu_form.save(commit=False)
            temp.home = home
            temp.parent_menu = Menu_parent
            temp.stack_order = menu + 1
            temp.save()
            return HttpResponseRedirect(reverse("section_list", args=[ch_id]))
    else:
        menu_form = MenuFormSection()
    profile = get_object_or_404(User, username=request.user)
    return render(
        request,
        "hd_subsection_form.html",
        {"form": menu_form, "profile": profile, "home": home, "menu": Menu_parent},
    )


@login_required
def update_section(request, ch_id, menu_id):
    obj = get_object_or_404(Menu, id=menu_id)
    if not obj.is_institution == True:
        if not obj.is_divisor == True:
            menu_form = SectionParentForm(
                request.POST or None, request.FILES or None, instance=obj
            )
        else:
            menu_form = UpdateSectionPartner(
                request.POST or None, request.FILES or None, instance=obj
            )
    else:
        menu_form = UpdateSectionPartner(
            request.POST or None, request.FILES or None, instance=obj
        )
    profile = get_object_or_404(User, username=request.user)
    if request.method == "POST":
        if menu_form.is_valid():
            menu_form.save()
            return HttpResponseRedirect(reverse("section_list", args=[ch_id]))
    return render(
        request,
        "hd_section_form.html",
        {
            "form": menu_form,
            "profile": profile,
            "obj": obj,
            "ch_id": ch_id,
            "menu_id": menu_id,
        },
    )


@login_required
def section_list(request, ch_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    sections = (
        Menu.objects.filter(home=ch_id).filter(is_section=True).order_by("stack_order")
    )
    partner = Partner.objects.filter(home=ch_id)
    site = SITEURL + "handler/"
    return render(
        request,
        "sections_list.html",
        {"ms": home, "site": site, "partner": partner, "sections": sections},
    )


@login_required
def add_divider(request, ch_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    ms_form = MenuFormSectionContent()
    instance = ms_form.save(commit=False)
    instance.home = home
    instance.is_section = True
    instance.is_divisor = True
    instance.save()

    return HttpResponseRedirect(reverse("section_list", args=[ch_id]))


@login_required
def upload_section_content(request, ch_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    if request.method == "POST":
        ms_form = MenuFormSectionContent(request.POST, request.FILES)
        ms_form.fields["content"].required = True

        if ms_form.is_valid():
            instance = ms_form.save(commit=False)
            instance.home = home
            instance.is_section = True
            instance.save()
            return HttpResponseRedirect(
                reverse("header_section_style", args=[ch_id, instance.id])
            )
    else:
        ms_form = MenuFormSectionContent()
    profile = get_object_or_404(User, username=request.user)
    return render(
        request,
        "content_form.html",
        {"form": ms_form, "profile": profile, "home": home},
    )


@login_required
def update_section_content(request, ch_id, menu_id):
    obj = get_object_or_404(Menu, id=menu_id)
    menu_form = MenuFormSectionContent(
        request.POST or None, request.FILES or None, instance=obj
    )
    profile = get_object_or_404(User, username=request.user)
    if request.method == "POST":
        menu_form.fields["content"].required = True
        if menu_form.is_valid():
            menu_form.save()
            return HttpResponseRedirect(reverse("section_list", args=[ch_id]))
    return render(
        request,
        "hd_section_form.html",
        {
            "form": menu_form,
            "profile": profile,
            "obj": obj,
            "ch_id": ch_id,
            "menu_id": menu_id,
        },
    )


@login_required
def update_block(request, ch_id, menu_id):
    obj = get_object_or_404(Menu, id=menu_id)
    menu = get_object_or_404(Menu, id=obj.parent_menu_id)
    if menu.is_institution != True:
        menu_form = MenuFormSubsection(
            request.POST or None, request.FILES or None, instance=obj
        )
    else:
        menu_form = UpdatePartnerSection(
            request.POST or None, request.FILES or None, instance=obj
        )
    profile = get_object_or_404(User, username=request.user)
    if request.method == "POST":
        if menu_form.is_valid():
            menu_form.save()
            return HttpResponseRedirect(reverse("section_list", args=[ch_id]))
    return render(
        request,
        "hd_menu_form.html",
        {"form": menu_form, "profile": profile, "obj": obj, "menu": menu},
    )
