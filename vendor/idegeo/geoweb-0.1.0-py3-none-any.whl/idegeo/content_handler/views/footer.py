# -*-encoding:utf-8-*-
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse

from idegeo.content_handler.models import ManagmentContent, Footer
from idegeo.content_handler.forms import (
    MenuFormSectionContent,
    FooterForm,
    FooterUpdateForm,
)


@login_required
def upload_footer(request, ch_id):
    obj = get_object_or_404(ManagmentContent, id=ch_id)
    try:
        foot = Footer.objects.get(home=obj.id)
        # no debe de existir más de un footer para un contenido
        if foot:
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    except Footer.DoesNotExist:
        pass

    if request.method == "POST":
        footer_form = FooterForm(request.POST, request.FILES)
        if footer_form.is_valid():
            temp_footer = footer_form.save(commit=False)
            temp_footer.home = obj
            temp_footer.user = request.user
            temp_footer.active = 1
            temp_footer.save()
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))

    else:
        footer_form = FooterUpdateForm()

    return render(request, "hd_footer_form.html", {"form": footer_form})


@login_required
def update_footer(request, ch_id, foo_id):
    obj = get_object_or_404(Footer, id=foo_id)
    footer = FooterUpdateForm(request.POST or None, request.FILES or None, instance=obj)
    if request.method == "POST":
        if footer.is_valid():
            footer.save()
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    return render(request, "hd_footer_form.html", {"form": footer, "obj": obj})


@login_required
def remove_footer(request, foo_id, template="footer_remove.html"):
    try:
        mc = get_object_or_404(Footer, id=foo_id)
        if request.method == "GET":
            return render(request, template, {"mc": mc})
        if request.method == "POST":
            mc.delete()
            return HttpResponseRedirect(reverse("content_handler_list"))
        else:
            return HttpResponse("Not allowed", status=403)

    except PermissionDenied:
        return HttpResponse(
            "You are not allowed to delete this ms_gestor_list",
            mimetype="text/plain",
            status=401,
        )


@login_required
def upload_section_footer(request, ch_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    if request.method == "POST":
        footer_form = MenuFormSectionContent(request.POST, request.FILES)

        if footer_form.is_valid():
            instance = footer_form.save(commit=False)
            instance.home = home
            instance.is_section = True
            instance.is_footer = True
            instance.save()
            return HttpResponseRedirect(
                reverse("header_section_style", args=[ch_id, instance.id])
            )
    else:
        footer_form = MenuFormSectionContent()
    return render(request, "content_form.html", {"form": footer_form, "home": home})
