# -*-encoding:utf-8-*-
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse

from django.contrib.auth import get_user_model

User = get_user_model()

from idegeo.content_handler.models import ManagmentContent, Menu
from idegeo.content_handler.forms import MenuFormCat, MenuFormParent


@login_required
def list_sub_submenu(request, ch_id, menu_id, submenu_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    menu = get_object_or_404(Menu, id=menu_id)
    submenu = get_object_or_404(Menu, id=submenu_id)
    sub_submenus = Menu.objects.filter(home=ch_id, parent_menu=submenu_id).order_by('stack_order')
    
    return render(
        request,
        "list_sub_submenu.html",
        {
            "ms": home,
            "menu": menu,
            "submenu": submenu,
            "sub_submenus": sub_submenus,
            "submenu_id": submenu_id
        }
    )

@login_required
def upload_sub_submenu(request, ch_id, menu_id, submenu_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    menu = get_object_or_404(Menu, id=menu_id)
    submenu = get_object_or_404(Menu, id=submenu_id)
    
    if request.method == "POST":
        menu_form = MenuFormCat(request.POST, request.FILES)
        if menu_form.is_valid():
            instance = menu_form.save(commit=False)
            order = Menu.objects.filter(home=ch_id).filter(is_section=False).count()
            instance.home = home
            instance.parent_menu = submenu
            instance.stack_order = order + 1
            instance.save()
            return HttpResponseRedirect(reverse("list_sub_submenu", args=[ch_id, menu_id, submenu_id]))
    else:
        menu_form = MenuFormCat()
    
    profile = get_object_or_404(User, username=request.user)
    
    return render(
        request,
        "hd_sub_submenu_form.html",
        {
            "form": menu_form,
            "profile": profile,
            "menu": menu,
            "submenu": submenu
        }
    )

@login_required
def submenu_change_style(request, ch_id, menu_id, submenu_id):
    submenu = get_object_or_404(Menu, id=submenu_id)
    if submenu.second_menu_style == True:
        submenu.second_menu_style = False
    else:
        submenu.second_menu_style = True
    submenu.save()
    return HttpResponseRedirect(reverse("list_sub_submenu", args=[ch_id,menu_id,submenu_id]))

@login_required
def update_sub_submenu(request, ch_id, menu_id, submenu_id, sub_submenu_id):
    obj = get_object_or_404(Menu, id=sub_submenu_id)
    
    if obj.parent_menu_id is not None:
        menu_form = MenuFormCat(request.POST or None, request.FILES or None, instance=obj)
    else:
        menu_form = MenuFormParent(request.POST or None, request.FILES or None, instance=obj)
    
    profile = get_object_or_404(User, username=request.user)
    
    if request.method == "POST":
        if menu_form.is_valid():
            menu_form.save()
            return HttpResponseRedirect(reverse("list_sub_submenu", args=[ch_id, menu_id, submenu_id]))
    
    return render(
        request,
        "hd_sub_submenu_form.html",
        {
            "form": menu_form,
            "profile": profile,
            "obj": obj
        }
    )


@login_required
def upload_submenu(request, ch_id, menu_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    menu = get_object_or_404(Menu, id=menu_id)
    if request.method == "POST":
        menu_form = MenuFormCat(request.POST, request.FILES)
        if menu_form.is_valid():
            instance = menu_form.save(commit=False)
            order = Menu.objects.filter(home=ch_id).filter(is_section=False).count()
            instance.home = home
            instance.parent_menu = menu
            instance.stack_order = order + 1
            instance.save()
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    else:
        menu_form = MenuFormCat()
    profile = get_object_or_404(User, username=request.user)
    return render(
        request,
        "hd_submenu_form.html",
        {"form": menu_form, "profile": profile, "home": home, "menu": menu},
    )


@login_required
def upload_menu(request, ch_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    if request.method == "POST":
        ms_form = MenuFormCat(request.POST, request.FILES)
        if ms_form.is_valid():
            instance = ms_form.save(commit=False)
            menu = Menu.objects.filter(home=ch_id).filter(is_section=False).count()
            instance.home = home
            instance.size = "4"
            instance.stack_order = menu + 1
            instance.style_template = "3"
            instance.save()
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    else:
        ms_form = MenuFormCat()
    profile = get_object_or_404(User, username=request.user)
    return render(
        request,
        "hd_menu_form.html",
        {"form": ms_form, "profile": profile, "home": home},
    )


@login_required
def upload_menu_parent(request, ch_id):
    home = get_object_or_404(ManagmentContent, id=ch_id)
    if request.method == "POST":
        ms_form = MenuFormParent(request.POST, request.FILES, initial={"active": True})
        if ms_form.is_valid():
            instance = ms_form.save(commit=False)
            menu = Menu.objects.filter(home=ch_id).filter(is_section=False).count()
            instance.home = home
            instance.size = "4"
            instance.stack_order = menu + 1
            instance.save()
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    else:
        ms_form = MenuFormParent(initial={"active": True})
    profile = get_object_or_404(User, username=request.user)
    return render(
        request,
        "hd_menu_form.html",
        {"form": ms_form, "profile": profile, "home": home},
    )


@login_required
def update_menu(request, ch_id, menu_id):
    obj = get_object_or_404(Menu, id=menu_id)
    if obj.parent_menu_id is not None:
        menu_form = MenuFormCat(
            request.POST or None, request.FILES or None, instance=obj
        )
    else:
        menu_form = MenuFormParent(
            request.POST or None, request.FILES or None, instance=obj
        )
    profile = get_object_or_404(User, username=request.user)
    if request.method == "POST":
        if menu_form.is_valid():
            menu_form.save()
            return HttpResponseRedirect(reverse("content_handler_detail", args=[ch_id]))
    return render(
        request,
        "hd_menu_form.html",
        {"form": menu_form, "profile": profile, "obj": obj},
    )


@login_required
def remove_menu(request, ch_id, menu_id, template="hd_menu_remove.html"):
    try:
        menu = get_object_or_404(Menu, id=menu_id)
        flag = False
        if menu.is_section:
            flag = True
        if request.method == "GET":
            return render(request, template, {"menu": menu, "home": ch_id})
        if request.method == "POST":
            menu.delete()
            if flag:
                return HttpResponseRedirect(reverse("section_list", args=[ch_id]))
            else:
                return HttpResponseRedirect(
                    reverse("content_handler_detail", args=[ch_id])
                )
        else:
            return HttpResponse("Not allowed", status=403)

    except PermissionDenied:
        return HttpResponse(
            "You are not allowed to delete this content_handler_list",
            mimetype="text/plain",
            status=401,
        )
