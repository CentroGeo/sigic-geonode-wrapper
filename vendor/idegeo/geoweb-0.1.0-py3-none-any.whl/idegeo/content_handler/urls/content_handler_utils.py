from django.urls import re_path

from idegeo.content_handler.views.content_handler_utils import *

urlpatterns = [
    re_path(
        r'^multimedia/(?P<msurlname>[^/]+)/(?P<slug>[\w-]+)$',
        content_multimedia,
        name='content_multimedia'
    ),
    re_path(
        r'^upload_content/(?P<ch_id>\d+)$',
        upload_content,
        name='upload_content'
    ),
    re_path(
        r'^update_content/(?P<ch_id>\d+)/(?P<content_id>\d+)$',
        update_content,
        name='update_content'
    ),
    re_path(
        r'^rm_content/(?P<ch_id>\d+)/(?P<content_id>\d+)$',
        remove_content,
        name='remove_content'
    ),
    re_path(r'^grays_managment/$', hd_grays_managment, name='hd_grays_managment'),
    re_path(r'^save_color/$', hd_save_color, name='hd_save_color'),
    re_path(r'^publish/$', hd_publish, name='hd_publish'),
    re_path(
        r'^publish_managment/(?P<ch_id>\d+)$',
        hd_publish_managment,
        name='hd_publish_managment'
    ),
    re_path(
        r'^unpublish_managment/(?P<ch_id>\d+)$',
        hd_unpublish_managment,
        name='hd_unpublish_managment'
    ),
    re_path(
        r'^content_list/(?P<ch_id>\d+)$',
        hd_content_list,
        name='hd_content_list'
    )
]