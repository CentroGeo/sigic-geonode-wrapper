from django.urls import re_path, path

from idegeo.content_handler.views.utils import *

urlpatterns = [
    path('sort_sections_handler/', sort_sections_handler, name='sort_sections_handler'),
    re_path(r'^sort_partner/$', sort_partner, name='sort_partner'),
    re_path(r'^sort_content/$', sort_content, name='sort_content'),
    re_path(
        r'^save_section_type/$',
        hd_save_section_type,
        name='hd_save_section_type'
    ),
    re_path(
        r'^save_hexadecimal/$',
        hd_save_hexadecimal,
        name='hd_save_hexadecimal'
    ),
    re_path(r'^hexadecimal/$', hd_hexadecimal, name='hd_hexadecimal'),
]