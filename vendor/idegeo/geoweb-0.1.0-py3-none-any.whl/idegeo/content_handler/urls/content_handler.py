from django.urls import re_path

from idegeo.content_handler.views.content_handler import *

urlpatterns = [
    # home handler
    re_path(r'^$', content_handler_list, name='content_handler_list'),
    re_path(r'^(?P<msurlname>[^/]+)$', handler_home, name='handler_home'),
    re_path(
        r'^detail/(?P<ch_id>\d+)$',
        content_handler_detail,
        name='content_handler_detail'
    ),
    re_path(
        r'^upload_handler/$', create_or_update_handler, name='upload_handler'
    ),
    re_path(
        r'^update_handler/(?P<ch_id>\d+)$',
        create_or_update_handler,
        name='update_handler'
    ),
    re_path(
        r'^rm_handler/(?P<ch_id>\d+)$', remove_handler, name='remove_handler'
    ),
]
