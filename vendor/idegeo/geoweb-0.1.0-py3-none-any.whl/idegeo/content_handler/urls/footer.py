from django.urls import re_path

from idegeo.content_handler.views.footer import *

urlpatterns = [
    re_path(
        r'^upload_section_footer/(?P<ch_id>\d+)$',
        upload_section_footer,
        name='upload_section_footer'
    ),
    re_path(
        r'^upload_footer/(?P<ch_id>\d+)$',
        upload_footer,
        name='upload_footer'
    ),
    re_path(
        r'^update_footer/(?P<ch_id>\d+)/(?P<foo_id>\d+)$',
        update_footer,
        name='update_footer'
    ),
    re_path(r'^rm_footer/(?P<foo_id>\d+)$', remove_footer, name='remove_footer')
]