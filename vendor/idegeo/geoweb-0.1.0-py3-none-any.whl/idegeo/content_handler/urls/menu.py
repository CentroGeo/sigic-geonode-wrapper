from django.urls import re_path

from idegeo.content_handler.views.menu import *

urlpatterns = [
    re_path(
        r'^upload_menu/(?P<ch_id>\d+)$', 
        upload_menu, name='upload_menu'
    ),
    re_path(
        r'^update_menu/(?P<ch_id>\d+)/(?P<menu_id>\d+)$', 
        update_menu, 
        name='update_menu'
    ),
    re_path(r'^rm_menu/(?P<ch_id>\d+)/(?P<menu_id>\d+)$', remove_menu, name='remove_menu'),
    re_path(r'^upload_submenu/(?P<ch_id>\d+)/(?P<menu_id>\d+)$', upload_submenu, name='upload_submenu'),
    re_path(r'^upload_menu_parent/(?P<ch_id>\d+)$', upload_menu_parent, name='upload_menu_parent'),
    re_path(r'^list_sub_submenu/(?P<ch_id>\d+)/(?P<menu_id>\d+)/(?P<submenu_id>\d+)$', list_sub_submenu, name='list_sub_submenu'),
    re_path(r'^upload_sub_submenu/(?P<ch_id>\d+)/(?P<menu_id>\d+)/(?P<submenu_id>\d+)$', upload_sub_submenu, name='upload_sub_submenu'),
    re_path(r'^submenu_change_style/(?P<ch_id>\d+)/(?P<menu_id>\d+)/(?P<submenu_id>\d+)$', submenu_change_style, name='submenu_change_style'),
    re_path(r'^update_sub_submenu/(?P<ch_id>\d+)/(?P<menu_id>\d+)/(?P<submenu_id>\d+)/(?P<sub_submenu_id>\d+)$', update_sub_submenu, name='update_sub_submenu')
]