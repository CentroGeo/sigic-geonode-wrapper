from . import content_handler
from . import content_handler_utils
from . import footer
from . import header
from . import menu
from . import sections
from . import partner
from . import styles
from . import utils

urlpatterns = [
    *content_handler.urlpatterns,
    *content_handler_utils.urlpatterns,
    *header.urlpatterns,
    *menu.urlpatterns,
    *partner.urlpatterns,
    *sections.urlpatterns,
    *utils.urlpatterns,
    *footer.urlpatterns,
    *styles.urlpatterns,    
]