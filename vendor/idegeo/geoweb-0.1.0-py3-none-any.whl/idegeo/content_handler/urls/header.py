from django.urls import re_path

from idegeo.content_handler.views.header import *

urlpatterns = [
    re_path(
        r'^upload_header/(?P<ch_id>\d+)$',
        upload_header,
        name='upload_header'
    ),
    re_path(
        r'^update_header/(?P<ch_id>\d+)/(?P<h_id>\d+)$',
        update_header,
        name='update_header'
    ), re_path(r'^rm_header/(?P<h_id>\d+)$', remove_header, name='remove_header')
]