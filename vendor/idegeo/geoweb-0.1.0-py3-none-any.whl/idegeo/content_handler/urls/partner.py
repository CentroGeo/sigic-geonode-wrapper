from django.urls import re_path

from idegeo.content_handler.views.partner import *

urlpatterns = [
    re_path(
        r'^upload_partner/(?P<ch_id>\d+)$',
        upload_partner,
        name='upload_partner'
    ),
    re_path(
        r'^upload_institution/(?P<ch_id>\d+)/(?P<menu_id>\d+)$',
        upload_institution,
        name='upload_institution'
    ),
    re_path(
        r'^update_partner/(?P<ch_id>\d+)/(?P<partner_id>\d+)$',
        update_partner,
        name='update_partner'
    ),
    re_path(
        r'^remove_partner/(?P<ch_id>\d+)/(?P<partner_id>\d+)$',
        remove_partner,
        name='remove_partner'
    ),
]