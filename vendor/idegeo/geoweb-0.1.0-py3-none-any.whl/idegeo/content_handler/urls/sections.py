from django.urls import re_path


from idegeo.content_handler.views.sections import *

urlpatterns = [
    re_path(
        r'^upload_section/(?P<ch_id>\d+)$',
        upload_section,
        name='upload_section'
    ),
    re_path(
        r'^upload_subsection/(?P<ch_id>\d+)/(?P<menu_id>\d+)$',
        upload_subsection,
        name='upload_subsection'
    ),
    re_path(
        r'^update_section/(?P<ch_id>\d+)/(?P<menu_id>\d+)$',
        update_section,
        name='update_section'
    ),
    re_path(r'^section_list/(?P<ch_id>\d+)$', section_list, name='section_list'),
    re_path(
        r'^upload_section_content/(?P<ch_id>\d+)$',
        upload_section_content,
        name='upload_section_content'
    ),
    re_path(r'^add_divider/(?P<ch_id>\d+)$', add_divider, name='add_divider'),
    re_path(
        r'^update_section_content/(?P<ch_id>\d+)/(?P<menu_id>\d+)$',
        update_section_content,
        name='update_section_content'
    ),
    re_path(r'^update_block/(?P<ch_id>\d+)/(?P<menu_id>\d+)$', update_block, name='update_block')
]