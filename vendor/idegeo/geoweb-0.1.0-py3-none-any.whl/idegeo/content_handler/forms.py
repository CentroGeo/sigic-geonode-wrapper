# -*-encoding:utf-8-*-
from string import Template
from django.utils.safestring import mark_safe
from django.forms import ModelForm
from django.conf import settings
from django import forms
from ckeditor_uploader.widgets import CKEditorUploadingWidget
from idegeo.middleware import UserMiddleware
from .models import (
    ManagmentContent,
    Header,
    Menu,
    Content,
    Partner,
    Style,
    Footer,
    HeaderSectionStyle,
    HeaderStyle,
)
from .models.menu_item import ALIGN


class ManagmentContentForm(ModelForm):
    cover_image = forms.ImageField(required=True)
    class Meta:
        model = ManagmentContent
        exclude = [
            "home",
            "description",
            "subtitle",
            "object",
            "color",
            "template",
            "public",
            "copyright",
            "primary_color",
            "second_color",
            "complementary_color",
            "gray_colors",
        ]


class ManagmentContentUpdate(ModelForm):
    object = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['object'].widget = CKEditorUploadingWidget(config_name='default')
    class Meta:
        model = ManagmentContent
        exclude = [
            "subtitle",
            "color",
            "template",
            "public",
            "copyright",
            "primary_color",
            "second_color",
            "complementary_color",
            "gray_colors",
        ]



class ManagmentSectionTypeFrom(ModelForm):
    class Meta:
        model = ManagmentContent
        fields = ["template"]


class ManagmentColorsForm(ModelForm):
    class Meta:
        model = ManagmentContent
        fields = ["color"]


class ManagmentHexadecimalForm(ModelForm):
    class Meta:
        model = ManagmentContent
        fields = ["primary_color", "second_color", "complementary_color"]


class HeaderForm(ModelForm):
    class Meta:
        model = Header
        exclude = ["home", "is_hover", "is_burger", "is_search"]




class MenuForm(ModelForm):
    content = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['content'].widget = CKEditorUploadingWidget(config_name='default')
    class Meta:
        model = Menu
        exclude = ["home", "section", "slug"]


class MenuFormCat(ModelForm):
    content = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['content'].widget = CKEditorUploadingWidget(config_name='default')
    class Meta:
        model = Menu
        fields = [
            "name",
            "link",
            "blank",
            "comment_section",
            "content",
            "active",
            "section_template",
            "image",
            "icon",
            "custome_icon"
        ]


# Esta clase es para el menu padre
class MenuFormParent(forms.ModelForm):
    active = forms.BooleanField(label="Mostrar/ocultar menú", required=False)
    content = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['content'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = Menu
        fields = [
            "name",
            "link",
            "blank",
            "comment_section",
            "custome_back",
            "content",
            "active",
            "has_mosaic",
            "style_template",
            "menu_side",
            "icon",
            "custome_icon"
        ]


class SimpleMenuForm(ModelForm):
    class Meta:
        model = Menu
        fields = ["name"]


class MenuFormSection(ModelForm):
    class Meta:
        model = Menu
        fields = ["name", "style_template", "active"]


class MenuFormSubsection(ModelForm):
    content = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['content'].widget = CKEditorUploadingWidget(config_name='default')
    class Meta:
        model = Menu
        fields = [
            "name",
            "link",
            "link_name",
            "link_color_line",
            "link_align",
            "blank",
            "image",
            "content",
            "section_template",
            "active",
        ]


class MenuFormSectionContent(ModelForm):
    content = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['content'].widget = CKEditorUploadingWidget(config_name='default')
    class Meta:
        model = Menu
        fields = ["name", "content", "active"]


class ContentForm(ModelForm):
    content = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['content'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = Content
        fields = "__all__"


class SimpleContent(ModelForm):
    content = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['content'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = Content
        exclude = ["home"]


class SectionForm(ModelForm):
    content = forms.CharField(widget=CKEditorUploadingWidget(config_name='restricted'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        user = UserMiddleware.get_current_user()

        if user and user.is_superuser:
            self.fields['content'].widget = CKEditorUploadingWidget(config_name='default')

    class Meta:
        model = Menu
        exclude = ["home", "parent_menu", "is_section"]


class SectionParentForm(ModelForm):
    class Meta:
        model = Menu
        exclude = [
            "home",
            "is_divisor",
            "is_institution",
            "slug",
            "content",
            "image",
            "description",
            "link",
            "blank",
            "stack_order",
            "parent_menu",
            "section_template",
            "is_section",
            "link_name",
            "link_color_line",
            "link_align",
        ]


class UpdateSectionPartner(ModelForm):
    class Meta:
        model = Menu
        fields = ["name"]


class PictureWidget(forms.widgets.Widget):
    def render(self, name, value, attrs=None, **kwargs):
        html = Template(
            """
            Actualmente: 
            <img src="$media$link" style="width:100px; height: 100px;"/>
            <input type="checkbox" name="image-clear" id="image-clear_id">
            <label for="image-clear_id">Borrar</label><br><br>
            Cambio: 
            <input type="file" name="image" id="id_image">
            """
        )
        return mark_safe(html.substitute(media=settings.MEDIA_URL, link=value))


class PartnerForm(forms.ModelForm):
    class Meta:
        model = Partner
        fields = "__all__"


class PartnerUpdate(forms.ModelForm):
    # image = ImageField(widget=PictureWidget)
    class Meta:
        model = Partner
        exclude = ["home"]


class StyleForm(ModelForm):
    scroll_align = forms.CharField(required=False)

    class Meta:
        model = Style
        fields = "__all__"


class StylUpdateForm(ModelForm):
    class Meta:
        model = Style
        fields = [
            "font",
            "second_color",
            "cover_color",
            "icon_title_color",
            "description_color",
            "primary_color",
            "third_color",
            "logo_alignment",
            "show_title",
            "show_menu",
            "header_type",
            "complementary_color",
            "background",
            "plot",
            "scroll",
            "scroll_image",
            "scroll_align",
            "institutional_headband",
        ]


class FooterForm(ModelForm):
    class Meta:
        model = Footer
        fields = "__all__"


class FooterUpdateForm(ModelForm):
    class Meta:
        model = Footer
        exclude = ["ms", "home", "style", "active"]


class StylFooterForm(ModelForm):
    class Meta:
        model = Style
        fields = ["primary_color", "second_color"]  # ,'all'


class UpdatePartnerSection(ModelForm):
    name = forms.CharField(label="Institución")
    image = forms.ImageField(label="Logo")
    link = forms.URLField(label="URL")

    class Meta:
        model = Menu
        fields = ("name", "image", "link")


class HeaderSectionForm(ModelForm):
    text_align = forms.ChoiceField(
        label="Alineacion del texto", choices=ALIGN, widget=forms.RadioSelect()
    )

    class Meta:
        model = HeaderSectionStyle
        exclude = ["section", "header_style"]


class StyleMainHeaderForm(ModelForm):
    text_align = forms.ChoiceField(
        label="Alineacion del texto", choices=ALIGN, widget=forms.RadioSelect()
    )

    class Meta:
        model = HeaderSectionStyle
        fields = [
            "background",
            "font_color",
            "size_font",
            "text_align",
            "bottom_border_color",
            "bottom_border_thickness",
            "top_border_color",
            "top_border_thickness",
        ]

class HeaderStyleForm(ModelForm):
    text_align=forms.ChoiceField(label="Alineacion del texto", choices=ALIGN, widget=forms.RadioSelect())
    class Meta:
        model = HeaderStyle
        fields = [
            "background",
            "font_color",
            "size_font",
            "text_align",
            "bottom_border_color",
            "bottom_border_thickness",
            "top_border_color",
            "top_border_thickness"
        ]