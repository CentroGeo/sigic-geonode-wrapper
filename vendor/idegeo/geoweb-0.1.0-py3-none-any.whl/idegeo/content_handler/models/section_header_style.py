# encoding:utf-8
from django.db import models

from .menu_item import Menu, ALIGN
from .management_content import ManagmentContent, get_upload_path


IMAGE_POSITION = (
    ("left", "Izquierda"),
    ("right", "Derecha"),
    ("center", "Centrado"),
    ("top", "Arriba"),
    ("bottom", "Abajo"),
)

BORDER = (
    ("solid", "Sólido"),
    ("dotted", "Punteado"),
    ("dashed", "Rayado"),
    ("double", "Doble"),
    ("groove", "Ranura"),
    ("ridge", "Cresta"),
)


class HeaderSectionStyle(models.Model):

    section = models.OneToOneField(
        Menu, verbose_name="Seccion", null=True, blank=True, on_delete=models.CASCADE
    )

    header_style = models.OneToOneField(
        ManagmentContent,
        verbose_name="Estilo para header principal",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
    )

    has_imagebackground = models.BooleanField(
        verbose_name="Imagen de fondo", default=False
    )

    image = models.ImageField(
        verbose_name="Imagen",
        help_text="Nota: reduce la transparencia del color de fondo para poder ver la imagen.",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )

    image_position_fixed = models.BooleanField(
        verbose_name="Posicion fija de imagen", default=True
    )

    image_position = models.CharField(
        verbose_name="Posicion de imagen",
        choices=IMAGE_POSITION,
        max_length=250,
        null=False,
        default="center",
    )

    image_repeat = models.BooleanField(
        verbose_name="Repetir imagen (generar trama)", default=False
    )

    background = models.CharField(
        verbose_name="Color de fondo",
        max_length=250,
        null=True,
        default="rgba(255,255,255,1)",
    )

    font_color = models.CharField(
        verbose_name="Color de texto", max_length=250, null=True, default="#000"
    )

    size_div = models.IntegerField(
        verbose_name="Tamaño de bloque (px)", null=True, default="20"
    )

    width_div = models.BooleanField(verbose_name="Ancho estrecho", default=False)

    top_border = models.BooleanField(verbose_name="Borde superior", default=False)

    top_border_thickness = models.IntegerField(
        verbose_name="Ancho de borde", default=1, null=True
    )

    top_border_style = models.CharField(
        verbose_name="Estilo de borde",
        choices=BORDER,
        max_length=250,
        default="solid",
        null=True,
    )

    top_border_color = models.CharField(
        verbose_name="Color de borde", max_length=250, default="black", null=True
    )

    bottom_border = models.BooleanField(verbose_name="Borde inferior", default=False)

    bottom_border_thickness = models.IntegerField(
        verbose_name="Ancho de borde", default=1, null=True
    )

    bottom_border_color = models.CharField(
        verbose_name="Color de borde", max_length=250, default="black", null=True
    )

    bottom_border_style = models.CharField(
        verbose_name="Estilo de borde",
        choices=BORDER,
        max_length=250,
        default="solid",
        null=True,
    )

    size_font = models.IntegerField(
        verbose_name="Tamaño de fuente (px)", null=True, default="28"
    )

    text_align = models.CharField(
        verbose_name="Alineacion del texto",
        choices=ALIGN,
        max_length=250,
        null=False,
        default="center",
    )

    underline = models.BooleanField(verbose_name="Subrayado", default=True)


class HeaderStyle(models.Model):

    section = models.OneToOneField(
        Menu, verbose_name="Seccion", null=True, blank=True, on_delete=models.CASCADE
    )

    header_style = models.OneToOneField(
        ManagmentContent,
        verbose_name="Estilo para header principal",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
    )

    has_imagebackground = models.BooleanField(
        verbose_name="Imagen de fondo", default=False
    )

    image = models.ImageField(
        verbose_name="Imagen",
        help_text="Nota: reduce la transparencia del color de fondo para poder ver la imagen.",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )

    image_position_fixed = models.BooleanField(
        verbose_name="Posicion fija de imagen", default=True
    )

    image_position = models.CharField(
        verbose_name="Posicion de imagen",
        choices=IMAGE_POSITION,
        max_length=250,
        null=False,
        default="center",
    )

    image_repeat = models.BooleanField(
        verbose_name="Repetir imagen (generar trama)", default=False
    )

    background = models.CharField(
        verbose_name="Color de fondo",
        max_length=250,
        null=True,
        default="rgba(255,255,255,1)",
    )

    font_color = models.CharField(
        verbose_name="Color de texto", max_length=250, null=True, default="#000"
    )

    size_div = models.IntegerField(
        verbose_name="Tamaño de bloque (px)", null=True, default="20"
    )

    width_div = models.BooleanField(verbose_name="Ancho estrecho", default=False)

    top_border = models.BooleanField(verbose_name="Borde superior", default=False)

    top_border_thickness = models.IntegerField(
        verbose_name="Ancho de borde", default=1, null=True
    )

    top_border_style = models.CharField(
        verbose_name="Estilo de borde",
        choices=BORDER,
        max_length=250,
        default="solid",
        null=True,
    )

    top_border_color = models.CharField(
        verbose_name="Color de borde", max_length=250, default="black", null=True
    )

    bottom_border = models.BooleanField(verbose_name="Borde inferior", default=False)

    bottom_border_thickness = models.IntegerField(
        verbose_name="Ancho de borde", default=1, null=True
    )

    bottom_border_color = models.CharField(
        verbose_name="Color de borde", max_length=250, default="black", null=True
    )

    bottom_border_style = models.CharField(
        verbose_name="Estilo de borde",
        choices=BORDER,
        max_length=250,
        default="solid",
        null=True,
    )

    size_font = models.IntegerField(
        verbose_name="Tamaño de fuente (px)", null=True, default="28"
    )

    text_align = models.CharField(
        verbose_name="Alineacion del texto",
        choices=ALIGN,
        max_length=250,
        null=False,
        default="center",
    )

    underline = models.BooleanField(verbose_name="Subrayado", default=True)
