# encoding:utf-8
from django.db import models
from django.urls import reverse

from ckeditor_uploader.fields import RichTextUploadingField

from .management_content import ManagmentContent


# contenido para la página
class Content(models.Model):
    home = models.ForeignKey(
        ManagmentContent,
        verbose_name="Home",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
    )

    content = RichTextUploadingField(verbose_name="Entrada", null=True, blank=True)

    stack_order = models.IntegerField(null=True, blank=True)

    active = models.BooleanField(verbose_name="Activo", default=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def get_absolute_url(self):
        return reverse("content_handler_detail", kwargs={"ch_id": self.home.id})

    class Meta:
        ordering = ["stack_order"]

    def __str__(self):
        return self.home.name
