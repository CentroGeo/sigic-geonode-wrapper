# encoding:utf-8
from django.db import models

from .management_content import get_upload_path
from .header_config import Header
from .footer_config import Footer
from .menu_item import Menu, ALIGN


FONTS = (
    ("Roboto", "Roboto"),
    ("Poppins", "Poppins "),
    ("Poppins SemiBold", "Poppins SemiBold"),
    ("Nunito", "Nunito"),
    ("Lato", "Lato"),
    ("Aleo", "Aleo"),
    ("Muli", "Muli"),
    ("Arapey", "Arapey"),
    ("Assistant", "Assistant"),
    ("Barlow", "Barlow"),
    ("Oswald", "Oswald"),
    ("Bitter", "Bitter"),
    ("Rokkitt", "Rokkitt"),
    ("Carme", "Carme"),
    ("Rubik", "Rubik"),
    ("Gelasio", "Gelasio"),
    ("Spectral", "Spectral"),
    ("Alegreya", "Alegreya"),
    ("Montserrat", "Montserrat"),
    ("Abhaya Libre", "Abhaya Libre"),
    ("Asap Condensed", "Asap Condensed"),
    ("Source Sans Pro", "Source Sans Pro"),
    ("Roboto Mono", "Roboto Mono"),
    ("Merriweather Sans", "Merriweather Sans"),
    ("Merriweather", "Merriweather"),
    ("Architects Daughter", "Architects Daughter"),
)


SIZE = (
    ("s", "Small (150x150)"),
    ("m", "Medium (250x250)"),
    ("l", "Large (250x150)"),
    ("x", "XLarge (497x279)"),
)


HEADER_TYPE = (("1", "Normal"), ("2", "Small"))


class Style(models.Model):
    align = models.CharField(
        verbose_name="Justificado",
        max_length=10,
        choices=ALIGN,
        blank=True,
        null=True,
        default="left",
    )

    font = models.CharField(
        verbose_name="Tipo de letra",
        max_length=40,
        choices=FONTS,
        blank=True,
        null=True,
        default="Times New Roman",
    )

    size = models.CharField(
        verbose_name="Tamaño de letra",
        max_length=1,
        choices=SIZE,
        blank=True,
        null=True,
        default="m",
    )

    color = models.IntegerField(verbose_name="Color", null=True, blank=True, default=0)

    primary_color = models.CharField(
        verbose_name="Color de texto",
        help_text="Este color se aplicará al texto",
        max_length=40,
        blank=True,
        null=True,
    )

    icon_title_color = models.CharField(
        verbose_name="Color del texto en el navegador del menú",
        max_length=40,
        blank=True,
        null=True,
    )

    logo_alignment = models.BooleanField(
        verbose_name="Alinear logos a los extremos",
        help_text="Por defecto los logos se alinean al centro",
        default=False,
    )

    description_color = models.CharField(
        verbose_name="Color de texto para sección de títulos",
        max_length=40,
        blank=True,
        null=True,
    )

    background = models.ImageField(
        verbose_name="Imagen de Header (Opcional)",
        help_text="Esta imagen reeplazará el color del fondo del header",
        upload_to=get_upload_path,
        null=True,
        blank=True,
    )

    second_color = models.CharField(
        verbose_name="Color de fondo",
        help_text="Este color se aplicará al footer",
        max_length=40,
        blank=True,
        null=True,
    )

    third_color = models.CharField(
        verbose_name="Color de fondo para encabezado principal?",
        max_length=40,
        blank=True,
        null=True,
    )

    show_title = models.BooleanField(
        verbose_name="Mostrar titulo en header principal", default=False
    )

    show_menu = models.BooleanField(
        verbose_name="Mostrar menu en header principal", default=True
    )

    header_type = models.CharField(
        verbose_name="Seleccionar el tamaño del header",
        max_length=2,
        choices=HEADER_TYPE,
        blank=True,
        null=True,
        default="1",
    )

    plot = models.ImageField(
        verbose_name="Trama Mosaico (Opcional)",
        help_text="Reemplazará el color de fondo de la descripción.",
        upload_to=get_upload_path,
        null=True,
        blank=True,
    )

    cover_color = models.CharField(
        verbose_name="Color de fondo de encabezado principal al hacer scroll",
        help_text="Este color se aplicará al fondo del encabezado",
        max_length=40,
        blank=True,
        null=True,
    )

    scroll = models.BooleanField(
        verbose_name="Mostrar botón de desplazamiento", default=False
    )

    scroll_image = models.ImageField(
        verbose_name="Imagen para botón de desplazamiento",
        upload_to=get_upload_path,
        null=True,
        blank=True,
    )

    scroll_align = models.CharField(
        verbose_name="Alineacion del botón de desplazamiento",
        choices=ALIGN,
        max_length=250,
        null=False,
        default="right",
    )

    institutional_headband = models.BooleanField(
        verbose_name="Mostrar encabezado y pie de página gobierno de México",
        default=False,
    )

    complementary_color = models.CharField(
        verbose_name="Color complementario", max_length=40, blank=True, null=True
    )

    header = models.ForeignKey(
        Header, verbose_name="Cabecera", null=True, blank=True, on_delete=models.CASCADE
    )

    footer = models.ForeignKey(
        Footer, verbose_name="Footer", null=True, blank=True, on_delete=models.CASCADE
    )

    menu = models.ForeignKey(
        Menu, verbose_name="Cabecera", null=True, blank=True, on_delete=models.CASCADE
    )

    all = models.BooleanField(
        verbose_name="Aplicar este estilo a todo el sitio", default=True
    )

    status = models.BooleanField(verbose_name="Activo", default=True)

    created = models.DateTimeField(auto_now_add=True)

    modified = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.primary_color
