# encoding:utf-8
from django.db import models
from django.urls import reverse

from .management_content import ManagmentContent, get_upload_path


class Footer(models.Model):
    home = models.ForeignKey(
        ManagmentContent,
        verbose_name="Home",
        related_name="home_footer",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
    )

    copyright = models.CharField(
        verbose_name="Copyright", max_length=300, null=True, blank=True
    )

    link_copyright = models.URLField(
        verbose_name="URL de Copyright", blank=True, default=None
    )

    image_1 = models.ImageField(
        verbose_name="Logo 1",
        help_text="Este logo es para la cabecera del home",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )

    link_1 = models.URLField(verbose_name="URL logo 1", blank=True, default=None)

    alt_1 = models.CharField(
        verbose_name="Título 1", max_length=50, blank=True, null=True
    )

    image_2 = models.ImageField(
        verbose_name="Logo 2",
        help_text="Este logo es para la cabecera del home",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )

    link_2 = models.URLField(verbose_name="URL logo 2", blank=True, default=None)

    alt_2 = models.CharField(
        verbose_name="Título 2", max_length=50, blank=True, null=True
    )

    contact_1 = models.CharField(
        verbose_name="Contacto 1", max_length=50, blank=True, null=True
    )

    email_1 = models.CharField(
        verbose_name="Email de contacto 1", max_length=250, blank=True
    )

    link_contanct_1 = models.URLField(
        verbose_name="URL de contacto 1", blank=True, default=None
    )

    contact_2 = models.CharField(
        verbose_name="Contacto 2", max_length=50, blank=True, null=True
    )

    email_2 = models.CharField(
        verbose_name="Email de contacto 2", max_length=250, blank=True
    )

    link_contanct_2 = models.URLField(
        verbose_name="URL de contacto 2", blank=True, default=None
    )

    contact_3 = models.CharField(
        verbose_name="Contacto 3", max_length=50, blank=True, null=True
    )

    email_3 = models.CharField(
        verbose_name="Email de contacto 3", max_length=250, blank=True
    )

    link_contanct_3 = models.URLField(
        verbose_name="URL de contacto 3", blank=True, default=None
    )

    active = models.BooleanField(verbose_name="Activo", default=True)

    created = models.DateTimeField(auto_now_add=True)

    def get_absolute_url(self):
        return reverse("content_handler_list")

    def __str__(self):
        return self.copyright
