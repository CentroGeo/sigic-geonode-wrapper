# encoding:utf-8
from django.db import models
from django.urls import reverse

from .management_content import ManagmentContent, get_upload_path


class Partner(models.Model):
    home = models.ForeignKey(
        ManagmentContent,
        verbose_name="Home",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
    )

    image = models.ImageField(
        verbose_name="Logo",
        help_text="Este logo es para las instituciones participantes",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )

    link = models.URLField(verbose_name="URL de logo", blank=True, default=None)

    alt = models.CharField(verbose_name="Título", max_length=50, blank=True, null=True)

    stack_order = models.IntegerField(
        verbose_name="Posición del logo",
        null=True,
        blank=True,
        help_text="Selecciona un número para el orden de aparición.",
    )

    def get_absolute_url(self):
        return reverse("content_handler_list")

    class Meta:
        ordering = ["stack_order"]

    def __str__(self):
        return self.home.name
