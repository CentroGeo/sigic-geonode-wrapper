# encoding:utf-8
from django.db import models
from django.urls import reverse
from ckeditor_uploader.fields import RichTextUploadingField
from fontawesome_6.fields import IconField

from .management_content import ManagmentContent, get_upload_path, STYLE_TYPE


ALIGN = (
    ("left", "IZQUIERDA"),
    ("center", "CENTRADO"),
    ("justify", "JUSTIFICADO"),
    ("right", "DERECHA"),
)

SIZE_TYPE = (
    ("6", "Small (150x150)"),
    ("5", "Medium (250x250)"),
    ("4", "Large (250x150)"),
    ("3", "XLarge (497x279)"),
    ("2", "Horizontal (851x315)"),
    ("1", "Vertical (1080x608)"),
)

STYLE_TEMP = (
    ("1", "Parallo"),
    ("2", "Bibendum"),
    ("3", "Editorial"),
    ("4", "Blog"),
    ("5", "Carrusel"),
    ("6", "Acordeon simple"),
    ("7", "Carrusel enfásis"),
    ("8", "Bloque viñeta"),
    ("9", "Bloque viñeta invertido"),
    ("10", "Carrusel pantalla completa"),
    ("11", "Bloque viñeta nuevo texto"),
    ("12", "Bloque viñeta simetrica"),
    ("13", "Carrusel Ancho"),
    ("14", "Bloque viñeta solo texto"),
    ("15", "Bloque viñeta solo texto énfasis"),
    ("16", "Carrusel pantalla completa vertical"),
    ("17", "Parallo dark"),
    ("18", "Parallo color"),
    ("19", "Bloque viñeta simetrica invertida"),
)

SIDE_MENU = (
    ('1', 'Primer menú'), 
    ('2', 'Segundo menú')
)


class Menu(models.Model):
    home = models.ForeignKey(
        ManagmentContent,
        verbose_name="Home",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
    )

    parent_menu = models.ForeignKey(
        "self",
        on_delete=models.CASCADE,
        verbose_name="Categoría superior",
        related_name="children",
        null=True,
        blank=True,
    )

    name = models.CharField(verbose_name="Nombre*", max_length=100)

    slug = models.SlugField(
        verbose_name="Slug*",
        help_text="El slug es una palabra sin espacios que identifica a la sección.",
    )

    image = models.ImageField(
        verbose_name="Imagen", upload_to=get_upload_path, null=True, blank=True
    )

    link = models.URLField(verbose_name="Enlace", null=True, blank=True)

    link_name = models.CharField(
        verbose_name="Nombre del botón de enlace", blank=True, null=True, max_length=100
    )

    link_color_line = models.CharField(
        verbose_name="Color de la linea de enlace", max_length=40, blank=True, null=True
    )

    link_align = models.CharField(
        verbose_name="Alineación de contenido",
        max_length=100,
        choices=ALIGN,
        blank=True,
        null=True,
        default="left",
    )

    blank = models.BooleanField(
        verbose_name="Abrir en otra ventana", blank=False, default=False
    )

    custome_back = models.BooleanField(
        verbose_name="Menú de regreso", blank=False, default=False
    )

    description = models.TextField(verbose_name="Descripción", null=True, blank=True)

    content = RichTextUploadingField(verbose_name="Entrada", null=True, blank=True)

    size = models.CharField(
        verbose_name="Tamaño",
        max_length=250,
        choices=SIZE_TYPE,
        blank=True,
        null=True,
        default="4",
    )

    stack_order = models.IntegerField(null=True, blank=True)

    active = models.BooleanField(verbose_name="Activo", default=True)

    is_section = models.BooleanField(verbose_name="Es sección", default=False)

    created_at = models.DateTimeField(auto_now_add=True)

    section_template = models.CharField(
        verbose_name="Estilo de encabezado de Seccion",
        max_length=2,
        choices=STYLE_TYPE,
        blank=True,
        null=True,
        default="2",
    )

    style_template = models.CharField(
        verbose_name="Estilo de seccion",
        max_length=2,
        choices=STYLE_TEMP,
        blank=False,
        null=False,
        default="3",
    )

    is_divisor = models.BooleanField(verbose_name="Es divisor", default=False)

    is_institution = models.BooleanField(verbose_name="Es institucion", default=False)

    comment_section = models.BooleanField(
        verbose_name="Agregar sección de comentarios", blank=False, default=False
    )

    has_mosaic = models.BooleanField(verbose_name="Agregar mosaico", default=False)

    is_footer = models.BooleanField(verbose_name="Es pie de página", default=False)

    menu_side = models.CharField(
        verbose_name="Seleccionar el lugar del menú", 
        max_length=2, 
        choices=SIDE_MENU, 
        blank=True, 
        null=True, 
        default='1'
    )

    icon = IconField(default='', verbose_name="Icono")

    custome_icon = models.ImageField(
        verbose_name= "Icono Personalizado" , 
        upload_to="images/", 
        null=True, 
        blank=True
    )
    second_menu_style = models.BooleanField(verbose_name='Submenus tipo mosaico', default=False)

    def get_absolute_url(self):
        return reverse("content_handler_detail", kwargs={"ch_id": self.home.id})

    def save(self, *args, **kwargs):
        super(Menu, self).save(*args, **kwargs)
        self.slug = "menuSect-" + str(self.home.id) + "-" + str(self.id)
        super(Menu, self).save(*args, **kwargs)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ["name"]
