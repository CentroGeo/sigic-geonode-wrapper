# encoding:utf-8
import os

from django.db import models
from django.core import validators

from ckeditor_uploader.fields import RichTextUploadingField

STYLE_TYPE = (
    ("1", "Parallo"),
    ("2", "Bibendum"),
    ("3", "Editorial"),
    ("4", "Prisma"),
)


def get_upload_path(instance, filename):
    return os.path.join("content_handler", filename)


# clase para poder manejar los homes
class ManagmentContent(models.Model):
    name = models.CharField(verbose_name="Home", max_length=200)

    subtitle = models.CharField(
        verbose_name="Título", max_length=200, null=True, blank=True
    )

    description = models.CharField(
        verbose_name="Descripcion", max_length=300, null=True, blank=True
    )

    object = RichTextUploadingField(verbose_name="Objetivo", null=True, blank=True)

    copyright = models.CharField(
        verbose_name="Copyright", max_length=300, null=True, blank=True
    )

    url_name = models.CharField(
        validators=[validators.validate_slug],
        verbose_name="Complementa la URL del sitio (pagina de inicio de la plataforma/cms/)",
        help_text="El slug no puede tener espacios, caracteres especiales, ni arrobas",
        max_length=20,
        unique=True,
        blank=False,
        null=True,
    )

    color = models.IntegerField(verbose_name="Color", null=True, blank=True, default=0)


    cover_image = models.ImageField(
        verbose_name="Imagen de portada",
        upload_to=get_upload_path,
        null=True,
        blank=True,
    )

    public = models.BooleanField(verbose_name="Publicar", blank=True, default=False)

    template = models.CharField(
        verbose_name="Estilo de Seccion",
        max_length=2,
        choices=STYLE_TYPE,
        blank=True,
        null=True,
        default="2",
    )

    gray_colors = models.BooleanField(
        verbose_name="Utilizar estilos de template", blank=False, default=True
    )

    primary_color = models.CharField(
        verbose_name="Color primario", max_length=8, blank=False, null=True
    )

    second_color = models.CharField(
        verbose_name="Color secundario", max_length=8, blank=False, null=True
    )

    complementary_color = models.CharField(
        verbose_name="Color complementario", max_length=8, blank=False, null=True
    )

    creation_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.name
