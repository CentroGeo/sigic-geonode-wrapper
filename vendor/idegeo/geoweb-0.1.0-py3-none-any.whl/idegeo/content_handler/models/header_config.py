# encoding:utf-8
from django.db import models
from django.urls import reverse

from .management_content import ManagmentContent, get_upload_path


class Header(models.Model):
    home = models.ForeignKey(
        ManagmentContent,
        verbose_name="Home",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
    )

    title = models.CharField(
        verbose_name="Título*",
        max_length=250,
        help_text="Este título aparecerá en la parte central del encabezado del home",
    )

    description = models.CharField(
        verbose_name="Descripción",
        max_length=300,
        blank=True,
        help_text="Dependiendo del template que se ocupe la descripción puede aparecer abajo del título del encabezado o al pasar el puntero",
    )

    is_hover = models.BooleanField(
        verbose_name="Apagar la descripción y que aparezca al pasar el puntero al título",
        default=False,
    )

    image_1 = models.ImageField(
        verbose_name="Logo 1",
        help_text="Este logo es para la cabecera del home",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )

    link_1 = models.URLField(verbose_name="URL logo 1", blank=True, default=None)

    new_tab_1 = models.BooleanField(
        verbose_name="Abrir URL en nueva pestaña", default=False
    )

    alt_1 = models.CharField(
        verbose_name="Título 1", max_length=50, blank=True, null=True
    )

    image_1_aling = models.BooleanField(
        verbose_name="Alinear logo a la derecha", default=False
    )

    image_2 = models.ImageField(
        verbose_name="Logo 2",
        help_text="Este logo es para la cabecera del home",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )

    link_2 = models.URLField(verbose_name="URL Logo 2", blank=True, default=None)

    new_tab_2 = models.BooleanField(
        verbose_name="Abrir URL en nueva pestaña", default=False
    )

    alt_2 = models.CharField(
        verbose_name="Título 2", max_length=50, blank=True, null=True
    )

    image_2_aling = models.BooleanField(
        verbose_name="Alinear logo a la derecha", default=False
    )

    image_3 = models.ImageField(
        verbose_name="Logo 3",
        help_text="Este logo es para la cabecera del home",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )

    link_3 = models.URLField(verbose_name="URL logo 3", blank=True, default=None)

    new_tab_3 = models.BooleanField(
        verbose_name="Abrir URL en nueva pestaña", default=False
    )

    alt_3 = models.CharField(
        verbose_name="Título 3", max_length=50, blank=True, null=True
    )

    image_3_aling = models.BooleanField(
        verbose_name="Alinear logo a la derecha", default=False
    )

    image_4 = models.ImageField(
        verbose_name="Logo 4",
        help_text="Este logo es para la cabecera del home",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )

    link_4 = models.URLField(verbose_name="URL logo 4", blank=True, default=None)

    new_tab_4 = models.BooleanField(
        verbose_name="Abrir URL en nueva pestaña", default=False
    )

    alt_4 = models.CharField(
        verbose_name="Título 4", max_length=50, blank=True, null=True
    )

    image_4_aling = models.BooleanField(
        verbose_name="Alinear logo a la derecha", default=False
    )

    image_5 = models.ImageField(
        verbose_name="Logo 5",
        help_text="Este logo es para la cabecera del home",
        upload_to=get_upload_path,
        blank=True,
        null=True,
        default=None,
    )

    link_5 = models.URLField(verbose_name="URL logo 5", blank=True, default=None)
    new_tab_5 = models.BooleanField(
        verbose_name="Abrir URL en nueva pestaña", default=False
    )

    alt_5 = models.CharField(
        verbose_name="Título 5", max_length=50, blank=True, null=True
    )

    image_5_aling = models.BooleanField(
        verbose_name="Alinear logo a la derecha", default=False
    )

    is_login = models.BooleanField(verbose_name="Acceso con usuario", default=False)

    is_burger = models.BooleanField(verbose_name="Menu", default=False)

    is_search = models.BooleanField(verbose_name="Buscar", default=False)

    def get_absolute_url(self):
        return reverse("content_handler_list")

    def __str__(self):
        return self.home.name
